package eu.reply.academy.lesson15;

public final class C {
    public  void afisareMesaj2(){
        System.out.println("Ana are mere");
    }
}
