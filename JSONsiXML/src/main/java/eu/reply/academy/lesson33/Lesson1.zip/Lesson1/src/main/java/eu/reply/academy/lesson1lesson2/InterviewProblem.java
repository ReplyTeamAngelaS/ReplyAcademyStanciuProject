package eu.reply.academy.lesson1lesson2;

public class InterviewProblem {

    public static void main (String[] args) {
       /*
        System.out.println("Test" + args[0] + " " + args[1] + " " args[2] + " " + args[3]);
        System.out.println("Test" + args[args.length-1]);
        System.out.println(args[0]);
       compile in cmd jvac si java
       java 1 2 ; java 1 2 3 ; X3 ; java 1+2; java 1;2;3
       indexoutofbounds exception daca avem mai multe elemente in decat avem noi
       sau daca nu avem nici un element dar noi vrem sa afisam cateva elemente !!!!
       args.length-1 afiseaza ultimul element , nu penultimul
       args.length  indexoutofbounds exception
       args[n] elementul din vector cu indexul n
       tabel de valori de facut ca sa nu ne pacalim
       la matrice se executa linia i si apoi coloana j cu mai multe valori pana devine fals !!!!
        vectori, se afiseaza inmutirea elementului cu 2, matrice patrata cu coloana principala si coloana secundara
       in care sa o afisam cu doua for-uri sau cu un singur for

       */


    }
}
