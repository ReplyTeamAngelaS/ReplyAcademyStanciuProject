package eu.reply.academy.lesson28.Main;

import java.io.*;
import java.security.SecureRandom;
import java.util.Vector;

import static eu.reply.academy.lesson28.Main.RunMe.PATH;

public class CoreDisk extends Core {

    private static int COUNTER_FILE_NAME = 0;

    protected CoreDisk() {
        super();
        this.Type = "Core Disk";
    }

    @Override
    protected void action(String application) {
        String nameFileCreated = "FisierCoreDisk" + CoreDisk.COUNTER_FILE_NAME;
        CoreDisk.COUNTER_FILE_NAME++;
        Vector<String> lines = Core.readFile(application);
        try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(PATH + "\\" + nameFileCreated))) {
            for (String line : lines) {
                bufferedWriter.write(line);
                bufferedWriter.write("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Core: ID- #" + this.Id + ", Tip- " + this.Type + "\n");
        return stringBuilder.toString();
    }
}
