package eu.reply.academy.lesson6;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class RisenOrFallenTest {

    @Test
    public void test01() {assertEquals(1, RisenOrFallen.incDec(0));}

    @Test
    public void test02() {assertEquals(10, RisenOrFallen.incDec(1));}

    @Test
    public void test03() {assertEquals(100, RisenOrFallen.incDec(2));}

    @Test
    public void test04() {assertEquals(475, RisenOrFallen.incDec(3));}

    @Test
    public void test05() {assertEquals(1675, RisenOrFallen.incDec(4));}

    @Test
    public void test06() {assertEquals(4954, RisenOrFallen.incDec(5));}

    @Test
    public void test07() {assertEquals(12952, RisenOrFallen.incDec(6));}
}
