package eu.reply.academy.lesson26;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Hypervisor {

    protected final static String CALE_FISIER = "C:\\Users\\Angela Stanciu\\IdeaProjects\\Lesson1\\src\\main\\java\\eu\\reply\\academy\\lesson26";
    protected static final int INDEX_NUME_OS = 0;
    protected static final int INDEX_TIP_OS = 1;
    protected static final int INDEX_NR_CPU = 2;
    protected static final int INDEX_APP = 3;
    protected static List<VirtualMachine> listaVirtualMachineCreate = new ArrayList<>();
    protected static List<VirtualMachine> listaVirtualMachineIncarcate = new ArrayList<>();
    protected static List<ProcesorFizic> listaProcesoareFizice = new ArrayList<>();

    protected static VirtualMachine CreateVMachine(String numeFisier, int prioritate) {
        VirtualMachine virtualMachineRezultat = null;
        try {
            String absolutePath = CALE_FISIER + "\\" + numeFisier;
            FileReader fileReader = new FileReader(absolutePath);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String listaColoane = bufferedReader.readLine();
            VirtualMachine.IdUnic += 1;
            int i = 0;
            while (i < VirtualMachine.IdUnic) {
                if (i == VirtualMachine.IdUnic - 1) {
                    String linie = bufferedReader.readLine();
                    if (linie != null) {
                        String[] lista = linie.split(",");
                        if (Hypervisor.getTipOS(lista).equals(LinuxOS.TIP_OS) && prioritate != 0) {
                            VirtualMachine virtualMachine = new LinuxOS(lista, prioritate);
                            if (virtualMachine.numarPrioritate != 0) {
                                Hypervisor.listaVirtualMachineCreate.add(virtualMachine);
                                virtualMachineRezultat = virtualMachine;
                            } else if (virtualMachine.numarPrioritate == 0) {
                                LinuxOS.listaLinuxOS.remove(virtualMachine);
                                virtualMachine = null;
                                System.out.println("Prioritatea coincide cu o alta masina virtuala. Dati alta valoare.");
                            }
                        } else if (Hypervisor.getTipOS(lista).equals(WindowsOS.TIP_OS) && prioritate != 0) {
                            VirtualMachine virtualMachine = new WindowsOS(lista, prioritate);
                            if (virtualMachine.numarPrioritate != 0) {
                                Hypervisor.listaVirtualMachineCreate.add(virtualMachine);
                                virtualMachineRezultat = virtualMachine;
                            } else if (virtualMachine.numarPrioritate == 0) {
                                WindowsOS.listaWindowsOS.remove(virtualMachine);
                                virtualMachine = null;
                                System.out.println("Prioritatea coincide cu o alta masina virtuala. Dati alta valoare.");
                            }
                        } else {
                            System.out.println("Prioritatea incepe de la 1.");
                        }
                    } else {
                        System.out.println("Nu mai exista nici o masina virtuala in fisierul dat.");
                    }
                } else {
                    bufferedReader.readLine();
                }
                i++;
            }
            bufferedReader.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return virtualMachineRezultat;
    }

    protected static String getNumeOS(String[] lista) {
        String nume = lista[INDEX_NUME_OS];
        return nume;
    }

    protected static String getTipOS(String[] lista) {
        String tip = lista[INDEX_TIP_OS];
        return tip;
    }

    protected static int getNrCPU(String[] lista) {
        int nr = Integer.parseInt(lista[INDEX_NR_CPU]);
        return nr;
    }

    protected static List<String> getListaApp(String[] lista) {
        List<String> listaApp = new ArrayList<>(Arrays.asList(lista[INDEX_APP].split(",")));
        return listaApp;
    }

    protected static void LoadVMachine(VirtualMachine virtualMachine) {
        if (virtualMachine != null) {
            List<ProcesorVirtual> listaCPU = ProcesorVirtual.creareCPUptVMachine(virtualMachine.numarVirtualCPU);
            int numarNuclee = virtualMachine.numarVirtualCPU;
            ProcesorFizic procesorFizic = new ProcesorFizic(numarNuclee);
            ProcesorFizic.mapareCPU(procesorFizic, listaCPU);
            virtualMachine.listaProcesoareAlocate = listaCPU;
            virtualMachine.setID();
            listaVirtualMachineIncarcate.add(virtualMachine);
            System.out.println("Masina virtuala a fost incarcata.");
        } else {
            System.out.println("Nu exista masina virtuala in sistem. Creati o noua masina virtuala.");
        }
    }

    protected static void listareVMachineExistente() {
        System.out.println("\n");
        System.out.println("Lista Masinilor Virtuale Incarcate In Sistem:");
        for (VirtualMachine virtualMachine : Hypervisor.listaVirtualMachineIncarcate) {
            System.out.println(virtualMachine);
        }
    }

    protected static VirtualMachine CreateVMachineBasedOnVMachine(VirtualMachine virtualMachine, int numarPrioritate) {
        VirtualMachine virtualMachine10 = null;
        boolean esteLinux = LinuxOS.existaInLista(virtualMachine);
        boolean esteWindows = WindowsOS.existaInLista(virtualMachine);
        if (!Hypervisor.listaVirtualMachineIncarcate.contains(virtualMachine)) {
            System.out.println("Masina virtuala data ca parametru nu este incarcata.");
        } else if (virtualMachine == null) {
            System.out.println("Masina virtuala nu s-a creat.");
        } else if (numarPrioritate == 0) {
            System.out.println("Prioritatea incepe de la 1.");
        } else if (esteLinux && !esteWindows) {
            LinuxOS linuxOS = (LinuxOS) virtualMachine;
            LinuxOS linuxNou = new LinuxOS(linuxOS, numarPrioritate);
            if (linuxNou.numarPrioritate != 0) {
                virtualMachine10 = linuxNou;
                Hypervisor.listaVirtualMachineCreate.add(virtualMachine10);
                System.out.println("Masina virtuala a fost creata.");
            } else if (linuxNou.numarPrioritate == 0) {
                System.out.println("Prioritatea este deja luata. Dati alta valoare.");
                LinuxOS.listaLinuxOS.remove(linuxNou);
            }
        } else if (!esteLinux && esteWindows) {
            WindowsOS windowsOS = (WindowsOS) virtualMachine;
            WindowsOS windowsNou = new WindowsOS(windowsOS, numarPrioritate);
            if (windowsNou.numarPrioritate != 0) {
                virtualMachine10 = windowsNou;
                Hypervisor.listaVirtualMachineCreate.add(virtualMachine10);
                System.out.println("Masina virtuala a fost creata.");
            } else if (windowsNou.numarPrioritate == 0) {
                System.out.println("Prioritatea este deja luata. Dati alta valoare.");
                WindowsOS.listaWindowsOS.remove(windowsNou);
            }
        }
        return virtualMachine10;
    }

    protected static void AddApplication(VirtualMachine virtualMachine, String... numeFisiere) {
        boolean esteLinux = LinuxOS.existaInLista(virtualMachine);
        boolean esteWindows = WindowsOS.existaInLista(virtualMachine);
        if (!Hypervisor.listaVirtualMachineCreate.contains(virtualMachine)) {
            System.out.println("Masina virtuala data ca parametru nu a fost creata.");
        } else if (!Hypervisor.listaVirtualMachineIncarcate.contains(virtualMachine)) {
            System.out.println("Masina virtuala data ca parametru a fost creata, dar nu incarcata.");
        } else if (esteLinux && !esteWindows) {
            LinuxOS linuxOS = (LinuxOS) virtualMachine;
            boolean esteAdaugat = linuxOS.setListaAplicatii(numeFisiere);
            if (esteAdaugat)
                System.out.println("S-au adaugat cu succes fisierele.");
        } else if (!esteLinux && esteWindows) {
            WindowsOS windowsOS = (WindowsOS) virtualMachine;
            boolean esteAdaugat = windowsOS.setListaAplicatii(numeFisiere);
            if (esteAdaugat)
                System.out.println("S-au adaugat cu succes fisierele.");
        }
    }

    protected static void AddResource_Processor(VirtualMachine virtualMachine) {
        boolean esteLinux = LinuxOS.existaInLista(virtualMachine);
        boolean esteWindows = WindowsOS.existaInLista(virtualMachine);
        if (!Hypervisor.listaVirtualMachineCreate.contains(virtualMachine)) {
            System.out.println("Masina virtuala data ca parametru nu a fost creata.");
        } else if (!Hypervisor.listaVirtualMachineIncarcate.contains(virtualMachine)) {
            System.out.println("Masina virtuala data ca parametru a fost creata, dar nu incarcata.");
        } else if (esteLinux && !esteWindows) {
            LinuxOS linuxOS = (LinuxOS) virtualMachine;
            ProcesorVirtual procesorVirtual = linuxOS.listaProcesoareAlocate.get(0);
            Hypervisor.listaProcesoareFizice.add(procesorVirtual.procesorFizic);
            System.out.println("S-a adaugat cu succes procesorul fizic asignat masinii virtuale.");
        } else if (!esteLinux && esteWindows) {
            WindowsOS windowsOS = (WindowsOS) virtualMachine;
            ProcesorVirtual procesorVirtual = windowsOS.listaProcesoareAlocate.get(0);
            Hypervisor.listaProcesoareFizice.add(procesorVirtual.procesorFizic);
            System.out.println("S-a adaugat cu succes procesorul fizic asignat masinii virtuale.");
        } else {
            System.out.println("Nu s-a putut adauga procesorul virtual in lista.");
        }
    }

    protected static void UnloadVMachine(String numeFisier, VirtualMachine virtualMachine){

    }

    protected void Run() {

    }


}
