package eu.reply.academy.lesson28.Main;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Vector;

import static eu.reply.academy.lesson28.Main.RunMe.PATH;

public abstract class Core {

    protected int Id;
    protected String Type;
    private static int RANDOM_NUMBER = 513;
    private static final int COUNTER = 59;

    protected Core(){
        this.createUniqueId();
    }

    protected abstract void action(String application);

    protected static Vector<String> readFile(String application) {
        Vector<String> linii = new Vector<>();
        String linie;
        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(PATH + "\\" + application))) {
            while ((linie = bufferedReader.readLine()) != null) {
                linii.add(linie);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return linii;
    }

    private void createUniqueId() {
        this.Id = Core.RANDOM_NUMBER + Core.COUNTER;
        Core.RANDOM_NUMBER += Core.COUNTER;
    }
}
