package eu.reply.academy.lesson23.beans;

public class UAT {

    public int id;
    public String nume;
    public String codtara;
    public int idtipuat;
    public String resedinta;
    public String codauto;
}
