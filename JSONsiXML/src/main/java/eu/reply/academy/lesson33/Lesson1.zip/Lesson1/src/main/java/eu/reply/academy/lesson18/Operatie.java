package eu.reply.academy.lesson18;

public interface Operatie {

    public void areOperatie();
}
