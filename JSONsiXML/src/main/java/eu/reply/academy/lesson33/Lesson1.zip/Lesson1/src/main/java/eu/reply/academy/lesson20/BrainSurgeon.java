package eu.reply.academy.lesson20;

import java.util.ArrayList;

public class BrainSurgeon extends Surgeon {

    @Override
    public void operatie(Operatie operatie) {
        for (Operatie operatie1 : listaOperatii) {
            if (operatie == operatie1) {
                operatie.operatie();
            }
        }
    }

    @Override
    public void tipChirurg() {
        System.out.println("Chirurgul este specialist pe creier.");
    }
}
