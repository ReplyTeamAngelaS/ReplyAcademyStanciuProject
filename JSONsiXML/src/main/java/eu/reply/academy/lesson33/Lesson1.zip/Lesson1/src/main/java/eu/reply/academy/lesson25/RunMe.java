package eu.reply.academy.lesson25;

public class RunMe {

    public static void main(String[] args) {

        Procesor procesor = new Procesor();
        String cale = "C:\\Users\\Angela Stanciu\\IdeaProjects\\Lesson1\\src\\main\\java\\eu\\reply\\academy\\lesson25";
        String denumireFisier = "text";
        procesor.citireDinFisier(cale, denumireFisier);
    }
}
