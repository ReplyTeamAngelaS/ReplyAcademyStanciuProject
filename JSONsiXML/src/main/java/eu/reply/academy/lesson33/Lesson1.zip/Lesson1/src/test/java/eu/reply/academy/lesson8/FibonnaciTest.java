package eu.reply.academy.lesson8;

import junit.framework.TestCase;
import org.junit.Assert;
import org.junit.Test;

public class FibonnaciTest extends TestCase {

    @Test
    public void test01(){Assert.assertEquals(0,Fibonnaci.sirFibonnaciRecursiv(0));}

    @Test
    public void test02(){Assert.assertEquals(1,Fibonnaci.sirFibonnaciRecursiv(1));}

    @Test
    public void test03(){Assert.assertEquals(1,Fibonnaci.sirFibonnaciRecursiv(2));}

    @Test
    public void test04(){Assert.assertEquals(2,Fibonnaci.sirFibonnaciRecursiv(3));}

    @Test
    public void test05(){Assert.assertEquals(3,Fibonnaci.sirFibonnaciRecursiv(4));}

    @Test
    public void test06(){Assert.assertEquals(5,Fibonnaci.sirFibonnaciRecursiv(5));}

    @Test
    public void test07(){Assert.assertEquals(8,Fibonnaci.sirFibonnaciRecursiv(6));}

    @Test
    public void test08(){Assert.assertEquals(13,Fibonnaci.sirFibonnaciRecursiv(7));}

    @Test
    public void test09(){Assert.assertEquals(21,Fibonnaci.sirFibonnaciRecursiv(8));}

}