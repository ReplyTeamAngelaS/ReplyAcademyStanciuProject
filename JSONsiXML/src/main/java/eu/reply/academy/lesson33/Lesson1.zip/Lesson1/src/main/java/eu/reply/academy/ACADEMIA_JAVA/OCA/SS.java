package eu.reply.academy.ACADEMIA_JAVA.OCA;

public class SS {
}
