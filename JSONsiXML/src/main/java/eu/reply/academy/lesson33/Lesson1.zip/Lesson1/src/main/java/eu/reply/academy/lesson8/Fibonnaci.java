package eu.reply.academy.lesson8;

public class Fibonnaci {

    public static void main(String[] args) {
        int rezultat = Fibonnaci.sirFibonnaciRecursiv(5);
        System.out.println(rezultat);
    }

    public static int sirFibonnaci(int numar) {
        if (numar == 0) {
            System.out.println("Rezultatul este: " + 0);
            return 0;
        } else if (numar == 1) {
            System.out.println("Rezultatul este: " + 1);
            return 1;
        } else {
            int[] vector = new int[numar + 1];
            vector[0] = 0;
            vector[1] = 1;
            for (int i = 2; i < vector.length; i++) {
                vector[i] = vector[i - 1] + vector[i - 2];
            }
            System.out.println("Rezultatul este: " + vector[vector.length - 1]);
            return vector[vector.length - 1];
        }
    }

    public static int sirFibonnaciRecursiv(int numar) {
        if (numar == 0) {
            return 0;
        } else if (numar == 1) {
            return 1;
        } else {
            return sirFibonnaciRecursiv(numar - 1) + sirFibonnaciRecursiv(numar - 2);
        }
    }

    public static int sirFibonnaciRecursivCuStackOverflow(int numar) {
            return sirFibonnaciRecursivCuStackOverflow(numar - 1) + sirFibonnaciRecursivCuStackOverflow(numar - 2);
    }
}
