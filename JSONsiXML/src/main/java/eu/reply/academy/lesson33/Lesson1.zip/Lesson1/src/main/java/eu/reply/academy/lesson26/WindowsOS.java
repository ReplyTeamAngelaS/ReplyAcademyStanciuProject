package eu.reply.academy.lesson26;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class WindowsOS extends VirtualMachine {

    protected static final String TIP_OS = "Windows OS";
    protected static List<WindowsOS> listaWindowsOS = new ArrayList<>();

    protected WindowsOS(String[] lista, int numarPrioritate) {
        this.numeOS = Hypervisor.getNumeOS(lista);
        this.numarVirtualCPU = Hypervisor.getNrCPU(lista);
        this.listaAplicatii = Hypervisor.getListaApp(lista);
        this.setNumarPrioritate(numarPrioritate);
        this.setID();
        WindowsOS.listaWindowsOS.add(this);
    }

    protected WindowsOS(WindowsOS windowsOS, int numarPrioritate) {
        this.numeOS = windowsOS.numeOS;
        this.numarVirtualCPU = windowsOS.numarVirtualCPU;
        this.listaAplicatii = windowsOS.listaAplicatii;
        this.setID();
        this.setNumarPrioritate(numarPrioritate);
        WindowsOS.listaWindowsOS.add(this);
    }

    protected void setNumarPrioritate(int prioritate) {
        this.numarPrioritate = prioritate;
        for (VirtualMachine virtualMachine : Hypervisor.listaVirtualMachineCreate) {
            if (virtualMachine.numarPrioritate == prioritate) {
                this.numarPrioritate = 0;
            }
        }
    }

    protected boolean setListaAplicatii(String... numeFisiere) {
        boolean esteAdaugat = false;
        if (numeFisiere == null) {
            System.out.println("Nu ati dat nici o valoare la nume fisier.");
        } else {
            boolean esteGol = WindowsOS.esteListaCuStringGol(numeFisiere);
            if (!this.listaAplicatii.isEmpty() && !esteGol) {
                Collections.addAll(this.listaAplicatii, numeFisiere);
                esteAdaugat = true;
            } else {
                System.out.println("Numele pentru fisier este scris gresit. Dati alta valoare.");
            }
        }
        return esteAdaugat;
    }

    private static boolean esteListaCuStringGol(String... numeFisier) {
        boolean esteGol = false;
        for (String valoare : numeFisier) {
            if (valoare.isBlank()) {
                esteGol = true;
            }
        }
        return esteGol;
    }

    public String toString() {
        int contor = WindowsOS.NR_VM++;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(contor + ") " + "Masina Virtuala\n ID Unic- " +
                this.ID + ";\n Nume SO- " + this.numeOS + ";\n Tip SO- "
                + WindowsOS.TIP_OS
                + ";\n Numar Prioritate- " + this.numarPrioritate
                + ";\n Lista Aplicatii- "
                + Arrays.toString(this.listaAplicatii.toArray()).replace('[', ' ')
                .replace(']', ' ').trim()
                + ";\n Lista Procesoare Virtuale:\n "
                + Arrays.toString(this.listaProcesoareAlocate.toArray()).replace('[', ' ')
                .replace(']', ' ').replace(',', ' '));
        return stringBuilder.toString();
    }

    protected static boolean existaInLista(VirtualMachine virtualMachine) {
        boolean este = false;
        for (VirtualMachine virtualMachine1 : WindowsOS.listaWindowsOS) {
            if (virtualMachine1.equals(virtualMachine)) {
                este = true;
            }
        }
        return este;
    }

}
