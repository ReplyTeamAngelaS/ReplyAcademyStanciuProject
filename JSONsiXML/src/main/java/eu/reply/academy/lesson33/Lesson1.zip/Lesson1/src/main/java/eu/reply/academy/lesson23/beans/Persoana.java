package eu.reply.academy.lesson23.beans;

import java.util.GregorianCalendar;

public class Persoana {

    public int id;
    public int idUtilizator;
    public String nume;
    public String prenume;
    public int idAdresa;
    public GregorianCalendar datanasterii;
    public String sex;
}
