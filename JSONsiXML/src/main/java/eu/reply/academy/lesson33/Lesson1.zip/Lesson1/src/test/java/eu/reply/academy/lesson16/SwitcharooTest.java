package eu.reply.academy.lesson16;

import eu.reply.academy.lesson10.DigitsSumRoot;
import junit.framework.TestCase;
import org.junit.Assert;
import org.junit.Test;

public class SwitcharooTest extends TestCase {

    @Test
    public void test01() {Assert.assertEquals(".at, dog, and mouseC", Switcharoo.flipEndChars("Cat, dog, and mouse."));}

    @Test
    public void test02() {
        Assert.assertEquals("anna, BananA", Switcharoo.flipEndChars("Anna, Banana"));
    }

    @Test
    public void test03() {
        Assert.assertEquals("][", Switcharoo.flipEndChars("[]"));
    }

    @Test
    public void test04() {Assert.assertEquals("Incompatible.", Switcharoo.flipEndChars(""));}

    @Test
    public void test05() {
        Assert.assertEquals("Two's a pair.", Switcharoo.flipEndChars("dfdkf49824fdfdfjhd"));
    }

    @Test
    public void test06() {
        Assert.assertEquals("Two's a pair.", Switcharoo.flipEndChars("#343473847#"));
    }

}