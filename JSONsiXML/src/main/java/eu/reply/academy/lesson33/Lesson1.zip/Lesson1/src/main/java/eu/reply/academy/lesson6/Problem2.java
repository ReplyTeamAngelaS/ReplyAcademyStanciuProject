package eu.reply.academy.lesson6;

import java.lang.reflect.Array;
import java.util.Arrays;

public class Problem2 {

    public static void main(String[] args) {
        //int[] vector = Problem2.DesparteNumarul(10);
        // System.out.println(Arrays.toString(vector));
        //System.out.println(Problem2.MaxPrimu(vector));
        System.out.println(Problem2.countIncreasingNumbers(3));

    }

    public static int countIncreasingNumbers(int nr) {
        int count = 0;
        // int number = 10 ^ nr;
        int number = (int) Math.pow(10, nr);
        /*if (nr == 0) {
            nr++;
        }*/
        /*for (int i = 1; i <= nr; i++) {
            for (int j = ((int) Math.pow(10, i)) / 10; j < (int) Math.pow(10, i); j++) {*/
        //System.out.println("printeaza j:" + j);
        for (int j = 1; j <= number; j++) {
            if (j < 10) {
                //System.out.println("Numarul este valid" + j);
                count += 1;
            } else {
                int[] vector = Problem2.DesparteNumarul(j);
                if (Problem2.MaxPrimu(vector) == true) {
                   //System.out.println("Numarul este valid" + j);
                    count += 1;
                } else if (Problem2.MinPrimu(vector) == true) {
                  //  System.out.println("Numarul este valid" + j);
                    count += 1;
                }
            }
            /*for (int j = ((int) Math.pow(10, i)) / 10; j <= (int) Math.pow(10, i); j++) {
                int[] vector = Problem2.DesparteNumarul(j);
                if ((Problem2.MaxPrimu(vector) == true)) {
                    //System.out.println("Numarul este increasing" + j);
                    count += 1;
                }
            }*/
            // }
            //}
        }
        System.out.println("Rezultatul este: "+ count);
        return count;
    }

    public static int[] DesparteNumarul(int n) {
        int lungime = 0;
        int nr2 = n;
        while (nr2 != 0) {
            nr2 = nr2 / 10;
            lungime++;
        }
        int[] vector = new int[lungime];
        for (int i = 0; i < vector.length; i++) {
            vector[vector.length - i - 1] = n % 10;
            n = n / 10;
        }
        return vector;
    }

   /* public static boolean MaximPrimu(int[] vector) {
        boolean bol = false;
        for (int max = 0; max < vector.length; max++) {
            for (int i = max + 1; i < vector.length; i++) {
                max = vector[max];
                if (max >= vector[i]) {
                    bol = true;
                } else if (max < vector[i]) {
                    bol = false;
                }
            }
        }
        return bol;
    }*/

    public static boolean MinPrimu(int[] vector) {
        boolean[] vectorBoolean = new boolean[vector.length];
        boolean bol = false;
        for (int min = 0; min < vector.length; min++) {
            int minim = vector[min];
            if (min != vector.length - 1) {
                for (int i = min + 1; i < min + 2; i++) {
                    if (minim <= vector[i]) {
                        bol = true;
                        vectorBoolean[min] = bol;
                    } else if (minim > vector[i]) {
                        bol = false;
                        vectorBoolean[min] = bol;
                    }
                }
            } else {
                bol = true;
                vectorBoolean[min] = bol;
            }
        }
        //System.out.println(Arrays.toString(vectorBoolean));
        for (int k = 0; k < vectorBoolean.length; k++) {
            if (vectorBoolean[k] == false) {
                bol = false;
            }
        }
        //System.out.println(bol);
        return bol;
    }

    public static boolean MaxPrimu(int[] vector) {
        boolean[] vectorBoolean = new boolean[vector.length];
        boolean bol = false;
        for (int min = 0; min < vector.length; min++) {
            int minim = vector[min];
            if (min != vector.length - 1) {
                for (int i = min + 1; i < min + 2; i++) {
                    if (minim >= vector[i]) {
                        bol = true;
                        vectorBoolean[min] = bol;
                    } else if (minim < vector[i]) {
                        bol = false;
                        vectorBoolean[min] = bol;
                    }
                }
            } else {
                bol = true;
                vectorBoolean[min] = bol;
            }
        }
        //System.out.println(Arrays.toString(vectorBoolean));
        for (int k = 0; k < vectorBoolean.length; k++) {
            if (vectorBoolean[k] == false) {
                bol = false;
            }
        }
        //System.out.println(bol);
        return bol;
    }
}
