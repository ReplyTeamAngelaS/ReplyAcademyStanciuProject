package eu.reply.academy.lesson17;

public class Punct {

    public int x;
    public int y;

    public Punct(int x, int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public String toString() {
        StringBuilder str = new StringBuilder();
        str.append("(" + x + "," + y + ")");
        return str.toString();
    }
}
