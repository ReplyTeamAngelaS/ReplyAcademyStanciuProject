package eu.reply.academy.lesson26;

public class CoreDisk extends Core {

    protected final static String TIP_CORE = "CoreDisk";
    protected static final int INDEX_COREDISK = 1;
    protected static int CONTOR_CORE = 1;

    protected CoreDisk() {
        this.setID();
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Core: ID- #" + this.ID + "; Tip Core- " + CoreDisk.TIP_CORE + ";\n");
        return stringBuilder.toString();
    }
}
