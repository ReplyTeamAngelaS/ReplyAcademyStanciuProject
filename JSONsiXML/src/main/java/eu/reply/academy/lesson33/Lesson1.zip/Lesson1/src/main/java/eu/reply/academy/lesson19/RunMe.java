package eu.reply.academy.lesson19;

import java.util.Arrays;

public class RunMe {

    public static void main(String[] args) {

        Array nume = new Array();
        System.out.println(Arrays.toString(nume.vector));
        int nr = 10, nr2 = 5, nr3 = 7, nr4 = 8, nr5 = 9;
        nume.adaugaElement(nr);
        System.out.println(Arrays.toString(nume.vector));
        nume.adaugaElement(nr2);
        nume.adaugaElement(nr3);
        nume.adaugaElement(nr4);
        System.out.println(Arrays.toString(nume.vector));
        int pozitie1 = nume.cautaElementFirst(nr4);
        System.out.println(pozitie1);
        int pozitie2 = nume.cautaElementFirst(nr5);
        System.out.println(pozitie2);
        int poz = 1;
        nume.stergeElement(poz);
        System.out.println(Arrays.toString(nume.vector));
       /* int poz2 = 1;
        nume.stergeElement(poz2);
        System.out.println(Arrays.toString(nume.vector));
        int poz3 = 0;
        nume.stergeElement(poz3);
        System.out.println(Arrays.toString(nume.vector));*/
    }
}
