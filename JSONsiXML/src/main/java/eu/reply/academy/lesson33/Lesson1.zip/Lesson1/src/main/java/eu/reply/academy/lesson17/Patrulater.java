package eu.reply.academy.lesson17;

public class Patrulater {

    public Punct a;
    public Punct b;
    public Punct c;
    public Punct d;

    public Patrulater(){

    }

    public Patrulater(Punct a, Punct b, Punct c, Punct d) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }

    @Override
    public String toString() {
        StringBuilder str = new StringBuilder();
        str.append("Patrulaterul are urmatoarele puncte: " + a + "," + b + "," + c + "," + d);
        return str.toString();
    }
}
