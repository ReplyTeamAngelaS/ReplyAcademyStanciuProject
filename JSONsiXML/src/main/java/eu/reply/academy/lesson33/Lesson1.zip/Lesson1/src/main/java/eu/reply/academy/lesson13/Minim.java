package eu.reply.academy.lesson13;

public class Minim {

    public static void main(String[] args) {
        int a, b, c;
        a = 20;
        b = 15;
        c = 5;
        int minim = Minim.MinimulATreiNumereNaturale(a, b, c);
        System.out.println("Primul numar este: " + a);
        System.out.println("Al doilea numar este: " + b);
        System.out.println("Al treilea numar este: " + c);
        System.out.println("Minimul dintre cele trei numere naturale este: " + minim);
    }

    public static int MinimulATreiNumereNaturale(int a, int b, int c) {
        int minim = a;
        if (minim > b) {
            minim = b;
        }
        if (minim > c) {
            minim = c;
        }
        return minim;
    }
}
