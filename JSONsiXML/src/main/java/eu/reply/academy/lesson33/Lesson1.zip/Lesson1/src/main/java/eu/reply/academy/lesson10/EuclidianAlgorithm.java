package eu.reply.academy.lesson10;

public class EuclidianAlgorithm {

    public static void main(String[] args) {

        int rezultat = EuclidianAlgorithm.calculeazaEuclidianAlgorithmRecursiv(64, 52);
        System.out.print(rezultat);
    }

    public static int calculeazaEuclidianAlgorithm(int a, int b) {
        if (a < b) {
            int temp = a;
            a = b;
            b = temp;
        } else {
            while (a % b != 0) {
                int temp = a;
                a = b;
                b = temp % b;
            }
        }
        return b;
    }

    public static int calculeazaEuclidianAlgorithmRecursiv(int a, int b) {
        if (a < b) {
            return b;
        }
        if (a % b != 0) {
            int temp = a;
            a = b;
            b = temp % b;
            return calculeazaEuclidianAlgorithmRecursiv(a, b);
        }
        return b;
    }
}
