package eu.reply.academy.lesson22;

import eu.reply.academy.lesson8.Fibonnaci;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Locale;

public class Utilitar {
    public final static char ch = '=';

    public static String transformaPrimaLitera(String cuvant) {
        String litera = String.valueOf(cuvant.charAt(0)).toUpperCase();
        String rezultat = litera + cuvant.substring(1);
        return rezultat;
    }

    public static int numarSpatii(String cuvant) {
        int rezultat = 0;
        for (int i = 0; i < cuvant.length(); i++) {
            if (cuvant.charAt(i) == ' ') {
                rezultat++;
            }
        }
        return rezultat;
    }

    public static String stergeSpatii(String cuvant) {
        boolean bol = true;
        int count = 0;
        for (int i = 0; i < cuvant.length() && bol; i++) {
            if (cuvant.charAt(i) == ' ') {
                count++;
            } else {
                bol = false;
            }
        }
        String rezultat = cuvant.substring(count);
        return rezultat;
    }

    public static ArrayList<String> pereche(String cuvant) {
        ArrayList<String> arrayList = new ArrayList<>();
        String cheie = cuvant.substring(0, cuvant.indexOf(ch));
        String valoare = cuvant.substring(cuvant.indexOf(ch) + 1);
        arrayList.add(cheie);
        arrayList.add(valoare);
        return arrayList;
    }
}
