package eu.reply.academy.lesson20;

public class OperatiePeInima02 extends Operatie {

    @Override
    public void operatie() {
        System.out.println("Doctorul chirurg face o operatie pe inima, numita CMHO.");
    }
}
