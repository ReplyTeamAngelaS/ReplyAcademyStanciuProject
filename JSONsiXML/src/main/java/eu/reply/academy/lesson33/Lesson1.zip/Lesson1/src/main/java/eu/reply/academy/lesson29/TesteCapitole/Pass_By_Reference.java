package eu.reply.academy.lesson29.TesteCapitole;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Pass_By_Reference {

    private List<Integer> list = Arrays.asList(0, 4, 3);

    public String a = "stringValue";
    public StringBuilder b = new StringBuilder("stringBuilderValue");
    public Character c = new Character('a');
    List<Integer> d = new ArrayList<>(list);
    public Integer e = 7;
    public int f = 9;

    public void schimbaA() {
        a = "string3";
    }

    public void schimbaC() {
        c = 'G';
    }

    public void schimbaE() {
        e = 15;
    }

    public void schimbaF() {
        f = 15;
    }

    public static void main(String[] args) {
        Pass_By_Reference m = new Pass_By_Reference(); //SE INITIALIZEAZA PROPRIETATILE
        passByReference(m.a, m.b, m.c, m.d, m.e, m.f); // NU SE MODIFICA VALORILE, PENTRU CA NU AM PASAT OBIECTUL, CI TIPURI DE DATE, FACANDU-SE O COPIE A LOR
        System.out.println(m.a + " " + m.b + " " + m.c + " " + m.d + " " + m.e + " " + m.f);
        passByReferenceWithObjectMethods(m); // SE MODIFICA VALORILE, PENTRU CA AI PASAT OBIECTUL SI LA FIECARE PROPRIETATE AI FOLOSIT METODE SPECIFICE OBIECTULUI !!!
        System.out.println(m.a + " " + m.b + " " + m.c + " " + m.d + " " + m.e + " " + m.f);
        m = returnByReference(); // SE MODIFICA VALORILE, PENTRU CA LA FINAL AI PUS TIP DE RETURNARE
        System.out.println(m.a + " " + m.b + " " + m.c + " " + m.d + " " + m.e + " " + m.f);
        Pass_By_Reference n=new Pass_By_Reference();
        passByReference3(n); // NU SE MODIFICA REFERINTA, PENTRU CA JAVA E PASS-BY-VALUE => CA SE LUCREAZA CU O COPIE A OBIECTULUI
        System.out.println(n.a + " " + n.b + " " + n.c + " " + n.d + " " + n.e + " " + n.f);
        System.out.println(n);
        passByReference2(n);//SE MODIFICA VALORILE OBIECTULUI. CHIAR DACA NU AM FOLOSIT METODE, SE FACE O COPIE A OBIECTULUI (CU ACEEASI REFERINTA!!!) SI SE ACCESEAZA FIECARE CAMP DE UNDE SE MODIFICA VALORILE
        System.out.println(n.a + " " + n.b + " " + n.c + " " + n.d + " " + n.e + " " + n.f);
    }

    public static void passByReference(String a, StringBuilder b, Character c, List<Integer> d, Integer e, int f) {
        a = "string2";
        b = new StringBuilder("stringBuilder2");
        c = 'A';
        d = Arrays.asList(0, 2, 2);
        e = 10;
        f = 10;
    }

    public static void passByReferenceWithObjectMethods(Pass_By_Reference m) {
        m.schimbaA();
        m.b.append("cccc");
        m.schimbaC();
        m.d.add(10);
        m.schimbaE();
        m.schimbaF();
    }

    public static Pass_By_Reference returnByReference() {
        Pass_By_Reference m = new Pass_By_Reference();
        m.a = "string2";
        m.b = new StringBuilder("stringBuilder2");
        m.c = 'C';
        m.d = Arrays.asList(0, 9, 10);
        m.e = 10;
        m.f = 10;
        return m;
    }

    public static void passByReference2(Pass_By_Reference m) {
        m.a = "string4";
        m.b = new StringBuilder("stringBuilder4");
        m.c = 'b';
        m.d = null;
        m.e = 20;
        m.f = 20;
    }

    public static void passByReference3(Pass_By_Reference m) {
        m = null;
    }
}
