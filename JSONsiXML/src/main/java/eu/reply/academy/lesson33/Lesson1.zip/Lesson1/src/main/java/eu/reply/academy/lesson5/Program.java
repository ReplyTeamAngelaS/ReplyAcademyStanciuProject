package eu.reply.academy.lesson5;

public class Program {

    public static void main(String[] args) {
        String word = "Just an example here move along";
        int numarCuvinte = Program.countWords(word);
    }

    public static int countWords(String word) {
        int count = 0;
        try {
            String[] cuvinte = word.split(" ");
            int i = 0;
            if ((word.length() != 0)) {
                System.out.println("Exista cuvinte in vectorul de string-uri.");
                while (i < cuvinte.length) {
                    count += 1;
                    i++;
                }
            } else {
                System.out.println("Nu exista cuvinte in vectorul de string-uri.");
            }
        } catch(NullPointerException e) {
            System.out.println("Stringul este null.");
        }
        System.out.println("Sunt in total un numar de cuvinte:" + count);
        return count;
    }
}
