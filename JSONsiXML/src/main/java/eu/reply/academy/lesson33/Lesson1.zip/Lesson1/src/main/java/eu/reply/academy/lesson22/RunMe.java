package eu.reply.academy.lesson22;

public class RunMe {

    public static void main(String[] args) {
        String cuvant = "cuvant";
        String cuvant2 = "cuvant cuvant cuvant";
        String cuvant3 = "   cuvant ";
        String cuvant5="id=romb";
        String cuvant6="class=\"dreptunghi\"";

        System.out.println(Utilitar.transformaPrimaLitera(cuvant));
        System.out.println(Utilitar.numarSpatii(cuvant2));
        System.out.println(Utilitar.stergeSpatii(cuvant3));
        System.out.println(Utilitar.pereche(cuvant5));
        System.out.println(Utilitar.pereche(cuvant6));

        StringBuilder s=new StringBuilder("abcd");
        
    }
}
