package eu.reply.academy.lesson5;

import java.math.RoundingMode;
import java.text.DecimalFormat;

public class Sales {

    public static void main(String[] args) {
        int price = 1500;
        int discount = 75;
        double finalPrice = Sales.discount(price, discount);
        System.out.println("Pretul final in urma discount-ului este:" + finalPrice);
        System.out.println(1/3d);
        double finalPriceTwoDecimal=Sales.discountTwoDecimal(1/3d);
        System.out.println("Pretul final in urma discount-ului cu doua zecimale este:" + finalPriceTwoDecimal);
    }

    public static double discount(int price, int discount) {
        double finalPrice;
        System.out.println("Price:" + price);
        if (discount != 0) {
            double discountNumber = (double) price*discount / 100;
            System.out.println("Discount number:" + discountNumber);
            finalPrice = (double) price - discountNumber;
        } else {
            System.out.println("Discount number:" + discount);
            finalPrice = price;
        }
        double finalPrice2=Sales.discountTwoDecimal(finalPrice);
        System.out.println("Final price:" + finalPrice2);
        return finalPrice2;
    }

    public static double discountTwoDecimal(double finalPrice) {
        DecimalFormat df = new DecimalFormat("0.00");
        df.setRoundingMode(RoundingMode.DOWN);
        double priceTwoDecimal= Double.parseDouble(df.format(finalPrice));
        return priceTwoDecimal;
    }

}
