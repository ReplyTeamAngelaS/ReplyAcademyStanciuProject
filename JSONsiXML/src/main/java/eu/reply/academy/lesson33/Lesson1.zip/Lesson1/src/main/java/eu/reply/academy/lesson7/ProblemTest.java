package eu.reply.academy.lesson7;
import eu.reply.academy.lesson6.Problem2;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class ProblemTest {

    @Test
    public void test01() {assertEquals(6, Problem.sumDigProd(8, 16, 89, 3));}

    @Test
    public void test02() {assertEquals(6, Problem.sumDigProd(16, 28));}

    @Test
    public void test03() {assertEquals(9, Problem.sumDigProd(9));}

    @Test
    public void test04() {assertEquals(6, Problem.sumDigProd(26, 497, 62, 841));}

    @Test
    public void test05() {assertEquals(0, Problem.sumDigProd(0));}

    @Test
    public void test06() {assertEquals(6, Problem.sumDigProd(17737, 98723, 2));}

    @Test
    public void test07() {assertEquals(8, Problem.sumDigProd(123, -99));}

    @Test
    public void test08() {assertEquals(7, Problem.sumDigProd(9, 8));}

    @Test
    public void test09() {assertEquals(8, Problem.sumDigProd(167, 167, 167, 167, 167, 3));}

    @Test
    public void test10() {assertEquals(1, Problem.sumDigProd(111111111));}

    @Test
    public void test11() {assertEquals(2, Problem.sumDigProd(98526, 54, 863, 156489, 45, 6156));}

    @Test
    public void test12() {assertEquals(8, Problem.sumDigProd(999, 999));}

    @Test
    public void test13() {assertEquals(2, Problem.sumDigProd(1, 2, 3, 4, 5, 6));}

    @Test
    public void test14() {assertEquals(2, Problem.sumDigProd(999, 2222));}

    @Test
    public void test15() {assertEquals(6, Problem.sumDigProd(8618, -2));}


}
