package eu.reply.academy.lesson29;

public class Main {

    public static void main(String[] args) {

        Patrulater patrat = new Patrat(5);
        Patrulater dreptunghi = new Dreptunghi(4, 2);
        double ariePatrat = patrat.calculeazaAria();
        double arieDreptunghi = dreptunghi.calculeazaAria();
        System.out.println(ariePatrat);
        System.out.println(arieDreptunghi);
        Patrulater patrulater = new Patrulater() {
            @Override
            protected double calculeazaAria() {
                return 0;
            }
        }; //inline declaration (obiectul este abstract si nu merge daca nu facem override la metodele abstracte neimplementate);
        //anonymous class - creeaza o noua clasa anonymous care extinde clasa Patrulater si face override metodei abstracte
        //=> obiectul patrulater , defapt nu este de tipul clasei Patrulater => nu se poate instantia o clasa abstracta

    }
}
