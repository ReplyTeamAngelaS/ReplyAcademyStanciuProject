package eu.reply.academy.lesson15;

public class A {

    public int x=20;

    public final void afisareMesaj(){
        System.out.println("Ana are mere");
    }
}
