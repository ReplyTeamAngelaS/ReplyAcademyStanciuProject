package eu.reply.academy.lesson7;

public class Problem {

    public static void main(String[] args) {
        int rezultat = Problem.sumDigProd(0);
        System.out.println(rezultat);
    }

    public static int sumDigProd(int... valori) {
        int sum = Problem.sumaValorilor(valori);
        int inmultire = Problem.inmultireNumar(sum);
        while (inmultire / 10 != 0) {
            inmultire = Problem.inmultireNumar(inmultire);
        }
        System.out.println("Rezultatul este " + inmultire);
        return inmultire;
    }

    public static int sumaValorilor(int... valori) {
        int sum = 0;
        for (int i = 0; i < valori.length; i++) {
            sum += valori[i];
        }
        return sum;
    }

    public static int inmultireNumar(int numar) {
        if (numar == 0) {
            return 0;
        }
        int inmultire = 1;

        while (numar != 0) {
            inmultire *= numar % 10;
            numar = numar / 10;
        }
        return inmultire;

    }

}
