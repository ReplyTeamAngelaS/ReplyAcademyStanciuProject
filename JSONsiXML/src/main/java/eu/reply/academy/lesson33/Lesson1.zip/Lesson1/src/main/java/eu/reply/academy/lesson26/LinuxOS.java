package eu.reply.academy.lesson26;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class LinuxOS extends VirtualMachine {

    protected static final String TIP_OS = "Linux OS";
    protected static List<LinuxOS> listaLinuxOS = new ArrayList<>();

    protected LinuxOS(String[] lista, int numarPrioritate) {
        this.numeOS = Hypervisor.getNumeOS(lista);
        this.numarVirtualCPU = Hypervisor.getNrCPU(lista);
        this.listaAplicatii = Hypervisor.getListaApp(lista);
        this.setNumarPrioritate(numarPrioritate);
        this.setID();
        LinuxOS.listaLinuxOS.add(this);
    }

    protected LinuxOS(LinuxOS linuxOS, int numarPrioritate) {
        this.numeOS = linuxOS.numeOS;
        this.numarVirtualCPU = linuxOS.numarVirtualCPU;
        this.listaAplicatii = linuxOS.listaAplicatii;
        this.setID();
        this.setNumarPrioritate(numarPrioritate);
        LinuxOS.listaLinuxOS.add(this);
    }

    protected void setNumarPrioritate(int numarPrioritate) {
        this.numarPrioritate = numarPrioritate;
        for (VirtualMachine virtualMachine : Hypervisor.listaVirtualMachineCreate) {
            if (virtualMachine.numarPrioritate == numarPrioritate) {
                this.numarPrioritate = 0;
            }
        }
    }

    protected boolean setListaAplicatii(String... numeFisiere) {
        boolean esteAdaugat = false;
        if (numeFisiere == null) {
            System.out.println("Nu ati dat nici o valoare la nume fisier.");
        } else {
            boolean esteGol = LinuxOS.esteListaCuStringGol(numeFisiere);
            if (!this.listaAplicatii.isEmpty() && !esteGol) {
                Collections.addAll(this.listaAplicatii, numeFisiere);
                esteAdaugat = true;
            } else {
                System.out.println("Numele pentru fisier este scris gresit. Dati alta valoare.");
            }
        }
        return esteAdaugat;
    }

    private static boolean esteListaCuStringGol(String... numeFisier) {
        boolean esteGol = false;
        for (String valoare : numeFisier) {
            if (valoare.isBlank()) {
                esteGol = true;
            }
        }
        return esteGol;
    }

    public String toString() {
        int contor = LinuxOS.NR_VM++;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(contor + ") " + "Masina Virtuala\n ID Unic- "
                + this.ID + ";\n Nume SO- " + this.numeOS
                + ";\n Tip SO- " + LinuxOS.TIP_OS
                + ";\n Numar Prioritate- " + this.numarPrioritate + ";\n Lista Aplicatii- "
                + Arrays.toString(this.listaAplicatii.toArray()).replace('[', ' ')
                .replace(']', ' ').trim()
                + ";\n Lista Procesoare Virtuale:\n "
                + Arrays.toString(this.listaProcesoareAlocate.toArray()).replace('[', ' ')
                .replace(']', ' ').replace(',', ' '));
        return stringBuilder.toString();
    }

    protected static boolean existaInLista(VirtualMachine virtualMachine) {
        boolean este = false;
        for (VirtualMachine virtualMachine1 : LinuxOS.listaLinuxOS) {
            if (virtualMachine1.equals(virtualMachine)) {
                este = true;
            }
        }
        return este;
    }
}
