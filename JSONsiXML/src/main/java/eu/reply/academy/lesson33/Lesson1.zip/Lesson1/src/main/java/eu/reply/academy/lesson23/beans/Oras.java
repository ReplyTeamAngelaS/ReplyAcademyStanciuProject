package eu.reply.academy.lesson23.beans;

public class Oras {

    public int id;
    public int iduat;
    public double X;
    public double Y;
    public String nume;
    public String judet;
    public String judetauto;
    public long populatie;
    public String regiune;

    public Oras(String[] valori) {
        this.X = Double.parseDouble(valori[0]);
        this.Y = Double.parseDouble(valori[1]);
        this.nume = valori[2];
        this.judet = valori[3];
        this.judetauto = valori[4];
        this.setPopulatie(valori[5]);
        this.regiune = valori[6];
    }

    public void setPopulatie(String populatie) {
        if (populatie.equals("")) {
            this.populatie = 0;
        } else {
            this.populatie = Long.parseLong(populatie);
        }
    }

    public String toString() {
        StringBuilder str = new StringBuilder();
        str.append("Oras: " + this.X + "," + this.Y + "," + this.nume + "," + this.judet
                + "," + this.judetauto + "," + this.populatie + "," + this.regiune + "\n");
        return str.toString();
    }


}
