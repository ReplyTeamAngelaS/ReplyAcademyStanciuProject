package eu.reply.academy.lesson26;

import java.util.ArrayList;
import java.util.List;

public class ProcesorVirtual {

    protected long ID;
    protected Core core;
    protected ProcesorFizic procesorFizic;
    private static final long CONTOR = 48;
    private static long numarRandom = 4875;

    protected ProcesorVirtual(Core core, ProcesorFizic procesorFizic) {
        this.core = core;
        this.procesorFizic = procesorFizic;
        this.setID();
    }

    protected void setID() {
        this.ID = ProcesorVirtual.numarRandom + ProcesorVirtual.CONTOR;
        ProcesorVirtual.numarRandom += ProcesorVirtual.CONTOR;
    }

    protected ProcesorVirtual() {

    }

    protected static List<ProcesorVirtual> creareCPUptVMachine(int numarCPUNecesare) {
        List<ProcesorVirtual> listaCPU = new ArrayList<>();
        while (numarCPUNecesare > 0) {
            ProcesorVirtual procesorVirtual = new ProcesorVirtual();
            listaCPU.add(procesorVirtual);
            numarCPUNecesare--;
        }
        return listaCPU;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Procesor Virtual cu ID #" + this.ID + " este asignat unui " + this.core
                + " al procesorului fizic cu ID #" + this.procesorFizic.ID + "\n");
        return stringBuilder.toString();
    }
}
