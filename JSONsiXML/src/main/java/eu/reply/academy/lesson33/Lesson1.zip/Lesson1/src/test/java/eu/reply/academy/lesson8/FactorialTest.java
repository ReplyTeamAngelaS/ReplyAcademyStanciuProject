package eu.reply.academy.lesson8;

import junit.framework.TestCase;
import org.junit.Assert;
import org.junit.Test;

public class FactorialTest extends TestCase {

    @Test
    public void test01(){Assert.assertEquals(2,Factorial.calculeazaFactorial(2));}

    @Test
    public void test02(){Assert.assertEquals(720,Factorial.calculeazaFactorial(6));}

    @Test
    public void test03(){Assert.assertEquals(6,Factorial.calculeazaFactorial(3));}

    @Test
    public void test04(){Assert.assertEquals(479001600,Factorial.calculeazaFactorial(12));}

    @Test
    public void test05(){Assert.assertEquals(120,Factorial.calculeazaFactorial(5));}

    @Test
    public void test06(){Assert.assertEquals(2,Factorial.calculeazaFactorialRecursiv(2));}

    @Test
    public void test07(){Assert.assertEquals(720,Factorial.calculeazaFactorialRecursiv(6));}

    @Test
    public void test08(){Assert.assertEquals(6,Factorial.calculeazaFactorialRecursiv(3));}

    @Test
    public void test09(){Assert.assertEquals(479001600,Factorial.calculeazaFactorialRecursiv(12));}

    @Test
    public void test10(){Assert.assertEquals(120,Factorial.calculeazaFactorialRecursiv(5));}
}