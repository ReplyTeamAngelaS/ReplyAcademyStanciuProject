package eu.reply.academy.lesson24;

public abstract class ManagerDeListe<T> {


    protected abstract void adaugareElement(T valoare);

    protected abstract void stergerePrimulElementCuValoareaData(T valoare);

    protected abstract void stergereElementCuIndexulDat(int index);

    protected abstract void listareElemente();

    protected abstract void comparareDouaListe(ManagerDeListe obiect2);

    protected abstract long calculareSumaElemente();
}
