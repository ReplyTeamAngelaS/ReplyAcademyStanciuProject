package eu.reply.academy.lesson15;


public class CapitolulIV {

    public static int count = 1;
    public int x = 9;

    public static void numeMetoda() {
        System.out.println("ccccccccccccc");
    }

    public void numeM(){

    }

    public void nume(){
        this.numeMetoda();
        CapitolulIV.numeMetoda();
        numeMetoda();
        this.count++;
        count++;
        CapitolulIV.count++;
    }

    public static void ss(){
        count++;
        CapitolulIV.count++;
        numeMetoda();
        CapitolulIV.numeMetoda();
    }

    public static void main(String[] args) {
        CapitolulIV capitolulIV = null;
        capitolulIV.numeMetoda();
        System.out.println(capitolulIV.count);
        System.out.println(capitolulIV.count);

    }
}
