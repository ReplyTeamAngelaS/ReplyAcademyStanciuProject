package eu.reply.academy.lesson26;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class ProcesorFizic {

    protected long ID;
    protected int numarCoreuri;
    protected List<Core> listaCore = new ArrayList<>();
    private static final long contor = 13;
    private static long numarRandom = 7597;

    protected void setID() {
        this.ID = ProcesorFizic.numarRandom + ProcesorFizic.contor;
        ProcesorFizic.numarRandom += ProcesorFizic.contor;
    }

    protected ProcesorFizic(int numarCPUNecesare) {
        this.setID();
        this.numarCoreuri = numarCPUNecesare;
        while (numarCPUNecesare > 0) {
            Random random = new Random();
            int numarRandom = random.nextInt(Core.NumarTotalSubclase) + 1;
            if (numarRandom == CoreDisk.INDEX_COREDISK) {
                Core core = new CoreDisk();
                listaCore.add(core);
            } else if (numarRandom == CoreScreen.INDEX_CORESCREEN) {
                Core core = new CoreScreen();
                listaCore.add(core);
            }
            numarCPUNecesare--;
        }
    }

    protected static void mapareCPU(ProcesorFizic procesorFizic, List<ProcesorVirtual> listaCPU) {
        int contor = 0;
        while (contor < listaCPU.size()) {
            ProcesorVirtual procesorVirtual = new ProcesorVirtual(procesorFizic.listaCore.get(contor), procesorFizic);
            listaCPU.set(contor, procesorVirtual);
            contor++;
        }
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Procesor fizic: \n ID- #" + this.ID + ";\n Numar Core- " + this.numarCoreuri
                + ";\n Lista Core:\n "
                + Arrays.toString(this.listaCore.toArray()).replace('[', ' ').replace(']', ' ')
                .replace(',', ' '));
        return stringBuilder.toString();
    }
}
