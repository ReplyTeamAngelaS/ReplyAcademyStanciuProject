package eu.reply.academy.classes;

import eu.reply.academy.classes.child.Child;
import eu.reply.academy.classes.grandparent.GrandParent;
import eu.reply.academy.classes.parent.Parent;

public class MainClass{

    public static void main(String args[]) {

        //Child child = new GrandParent();
//        Parent parent = new Child();
//        GrandParent grandParent = new Child();
//        Child child = new Parent();
//        GrandParent grandParent = new Child();
//        System.out.println(grandParent.privateAge);
//        System.out.println(grandParent.getDefaultAge());
//        System.out.println(grandParent.defaultAge);
//        System.out.println(grandParent.publicAge);
//        System.out.println(grandParent.getPublicAge());
//        System.out.println(grandParent.getPrivateAge());
//        System.out.println(grandParent.protectedAge);
//        System.out.println(grandParent.getProtectedAge());
//        System.out.println(grandParent.getPublicAge(10));
//        System.out.println(grandParent.getPublicAge(10,15));
//        System.out.println(grandParent.getProtectedAge(10));
//        System.out.println(grandParent.getProtectedAge(10,15));
//
//
//        GrandParent grandParent = new Parent();
//        System.out.println(grandParent.privateAge);
//        System.out.println(grandParent.getDefaultAge());
//        System.out.println(grandParent.defaultAge);
//        System.out.println(grandParent.publicAge);
//        System.out.println(grandParent.getPublicAge());
//        System.out.println(grandParent.getPrivateAge());
//        System.out.println(grandParent.protectedAge);
//        System.out.println(grandParent.getProtectedAge());
//        System.out.println(grandParent.getPublicAge(10));
//        System.out.println(grandParent.getPublicAge(10,15));
//        System.out.println(grandParent.getProtectedAge(10));
//        System.out.println(grandParent.getProtectedAge(10,15));
//
//        Parent parent = new Parent();
//        System.out.println(parent.privateAge);
//        System.out.println(parent.getDefaultAge());
//        System.out.println(parent.defaultAge);
//        System.out.println(parent.publicAge);
//        System.out.println(parent.getPublicAge());
//        System.out.println(parent.getPrivateAge());
//        System.out.println(parent.protectedAge);
//        System.out.println(parent.getProtectedAge());
//        System.out.println(parent.getPublicAge(10));
//        System.out.println(parent.getPublicAge(10,15));
//        System.out.println(parent.getProtectedAge(10));
//        System.out.println(parent.getProtectedAge(10,15));
//
//        Parent parent = new Child();
//        System.out.println(parent.privateAge);
//        System.out.println(parent.getDefaultAge());
//        System.out.println(parent.defaultAge);
//        System.out.println(parent.publicAge);
//        System.out.println(parent.getPublicAge());
//        System.out.println(parent.getPrivateAge());
//        System.out.println(parent.protectedAge);
//        System.out.println(parent.getProtectedAge());
//        System.out.println(parent.getPublicAge(10));
//        System.out.println(parent.getPublicAge(10,15));
//        System.out.println(parent.getProtectedAge(10));
//        System.out.println(parent.getProtectedAge(10,15));
//
//        Child child = new Child();
//        System.out.println(child.privateAge);
//        System.out.println(child.getDefaultAge());
//        System.out.println(child.defaultAge);
//        System.out.println(child.publicAge);
//        System.out.println(child.getPublicAge());
//        System.out.println(child.getPrivateAge());
//        System.out.println(child.protectedAge);
//        System.out.println(child.getProtectedAge());
//        System.out.println(child.getPublicAge(10));
//        System.out.println(child.getPublicAge(10,15));

    }

}
