package eu.reply.academy.lesson14;

import java.util.Arrays;
import java.util.Scanner;

public class MultipluSir {

    public static void main(String[] args) {
        int n = MultipluSir.daNumarN();
        int[] vector = MultipluSir.citireSir(n);
        MultipluSir.calculeazaMultiplul(vector);
    }

    public static int daNumarN() {
        Scanner scan = new Scanner(System.in);
        System.out.print("Numarul natural reprezentand dimensiunea sirului este: ");
        int n = scan.nextInt();
        if (!((n >= 1) && (n <= 1000))) {
            System.out.println("Numarul trebuie sa fie in intervalul 1 si 1000.");
            return daNumarN();
        }
        return n;
    }

    public static int daNumarSir() {
        Scanner scan = new Scanner(System.in);
        System.out.print("Scrie un numar natural: ");
        int n = scan.nextInt();
        if (!(n <= 1000000000)) {
            System.out.println("Numarul trebuie sa fie mai mic decat 1.000.000.000");
            return daNumarSir();
        }
        return n;
    }

    public static int[] citireSir(int n) {
        int[] vector = new int[n];
        for (int i = 0; i < vector.length; i++) {
            vector[i] = MultipluSir.daNumarSir();
            if (vector[i] == vector[vector.length - 1]) {
                while (vector[i] == 0) {
                    System.out.println("Ultimul element este nul!");
                    vector[i] = MultipluSir.daNumarSir();
                }
            }
        }
        System.out.println("-----------------------------------------------");
        System.out.println("Numerele din sir sunt: " + Arrays.toString(vector));
        return vector;
    }

    public static void calculeazaMultiplul(int[] vector) {
        System.out.println("Rezultatul este: ");
        int indiceUlimul = vector.length - 1; //se face 2+(n-1) ori, de asta am pus aici
        for (int i = 0; i < indiceUlimul; i++) {
            if (vector[i] % vector[indiceUlimul] == 0) {
                System.out.print(vector[i] + " ");
            }
        }
    }
}
