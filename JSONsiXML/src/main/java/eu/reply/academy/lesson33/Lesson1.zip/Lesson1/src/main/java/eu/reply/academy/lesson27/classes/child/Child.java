package eu.reply.academy.classes.child;

import eu.reply.academy.classes.parent.Parent;

public class Child extends Parent {

    private String privateAge = "Private Age Child";
    String defaultAge = "Default Age Child";
    protected String protectedAge = "Protected Age Child";
    public String publicAge = "Public Age Child";

//    private String getPrivateAge() {
//        return this.privateAge;
//    }

    protected String getProtectedAge() {
        return super.getProtectedAge();
    }

    public String getPublicAge() {
        return this.publicAge;
    }

    public String getPublicAge(int age1, int age2) {
        return privateAge + " " + age1 + " " + age2;
    }

    public void test() {}

}
