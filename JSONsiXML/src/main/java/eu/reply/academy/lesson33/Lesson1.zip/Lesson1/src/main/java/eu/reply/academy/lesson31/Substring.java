package eu.reply.academy.lesson31;

public interface Substring<T, U, R> {

    R printSubstrig(T numar, U cuvant);
}
