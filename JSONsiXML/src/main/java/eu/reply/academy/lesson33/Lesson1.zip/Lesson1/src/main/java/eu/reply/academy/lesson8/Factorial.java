package eu.reply.academy.lesson8;

public class Factorial {

    public static void main(String[] args) {
        int rezultat = Factorial.calculeazaFactorial(4);
        System.out.println(rezultat);
    }

    public static int calculeazaFactorial(int numar) {
        if (numar == 0) {
            System.out.println("Rezultatul este: " + 1);
            return 1;
        } else {
            int inmultire = 1;
            for (int i = 1; i <= numar; i++) {
                inmultire *= i;
            }
            System.out.println("Rezultatul este: " + inmultire);
            return inmultire;
        }
    }

    public static long calculeazaFactorialRecursiv(int numar) {
        if (numar == 0) {
            return 1;
        } else {
            return numar*calculeazaFactorialRecursiv(numar-1);
        }
    }
}
