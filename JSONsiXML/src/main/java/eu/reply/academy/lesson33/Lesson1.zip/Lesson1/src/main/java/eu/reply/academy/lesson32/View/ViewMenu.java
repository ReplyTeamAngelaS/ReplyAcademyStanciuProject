package eu.reply.academy.lesson32.View;

import eu.reply.academy.lesson32.Model.Menu;

import java.util.List;

public class ViewMenu {

    public void printMenu(List<Menu> lista) {

    }
}
