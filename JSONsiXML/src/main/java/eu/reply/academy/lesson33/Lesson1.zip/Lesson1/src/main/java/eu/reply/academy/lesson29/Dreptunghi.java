package eu.reply.academy.lesson29;

public class Dreptunghi extends Patrulater {

    protected Dreptunghi(double lungime, double latime) {
        super(lungime, latime);
    }

    protected Dreptunghi() {

    }

    @Override
    protected double calculeazaAria() {
        double arie = this.getLungime() * this.getLatime();
        return arie;
    }
}
