package eu.reply.academy.lesson14;

import java.util.Scanner;

public class NumarMaxim {

    public static void main(String[] args) {
        int a = NumarMaxim.daNumar();
        int b = NumarMaxim.daNumar();
        int c = NumarMaxim.daNumar();
        System.out.println("-----------------------------------------------");
        System.out.println("Cele trei numere sunt: " + a + "," + b + "," + c);
        NumarMaxim.calculeazaMaximul(a, b, c);

    }

    public static int daNumar() {
        Scanner scan = new Scanner(System.in);
        System.out.print("Scrie un numar natural: ");
        int n = scan.nextInt();
        if (!((n >= 10) && (n <= 99))) {
            System.out.println("Numarul trebuie sa fie in intervalul 10 si 99");
            return daNumar();
        }
        return n;
    }

    public static void calculeazaMaximul(int a, int b, int c) {
        int suma1 = 0, suma2 = 0, suma3 = 0;
        suma1 += a % 10 + a / 10;
        suma2 += b % 10 + b / 10;
        suma3 += c % 10 + c / 10;
        int maxim = suma1;
        if (maxim < suma2) {
            maxim = suma2;
        }
        if (maxim < suma3) {
            maxim = suma3;
        }
        System.out.println("Suma cifrelor maxima este: " + maxim);
        if (maxim == suma1) {
            if ((suma1 == suma2) && (suma1 == suma3)) {
                System.out.println("Numerele corecte sunt: " + a + "," + b + "," + c + ". Sunt trei numere.");
            } else if (suma1 == suma2) {
                System.out.println("Numerele corecte sunt: " + a + "," + b + ". Sunt doua numere.");
            } else if (suma1 == suma3) {
                System.out.println("Numerele corecte sunt: " + a + "," + c + ". Sunt doua numere.");
            } else {
                System.out.println("Numarul corect este: " + a);
            }
        } else if (maxim == suma2) {
            if ((suma2 == suma1) && (suma2 == suma3)) {
                System.out.println("Numerele corecte sunt: " + a + "," + b + "," + c + ". Sunt trei numere.");
            } else if (suma2 == suma1) {
                System.out.println("Numerele corecte sunt: " + b + "," + a + ". Sunt doua numere.");
            } else if (suma2 == suma3) {
                System.out.println("Numerele corecte sunt: " + b + "," + c + ". Sunt doua numere.");
            } else {
                System.out.println("Numarul corect este: " + b);
            }
        } else if (maxim == suma3) {
            if ((suma3 == suma1) && (suma3 == suma2)) {
                System.out.println("Numerele corecte sunt: " + a + "," + b + "," + c + ". Sunt trei numere.");
            } else if (suma3 == suma1) {
                System.out.println("Numerele corecte sunt: " + c + "," + a + ". Sunt doua numere.");
            } else if (suma3 == suma2) {
                System.out.println("Numerele corecte sunt: " + c + "," + b + ". Sunt doua numere.");
            } else {
                System.out.println("Numarul corect este: " + c);
            }
        }
    }
}
