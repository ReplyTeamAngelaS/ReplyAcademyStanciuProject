package eu.reply.academy.lesson26;

import java.util.Arrays;
import java.util.UUID;

public class RunMe {

    public static void main(String[] args) {
        final String numeFisier = "imagineSO";
        VirtualMachine VM = Hypervisor.CreateVMachine(numeFisier, 2);
        Hypervisor.LoadVMachine(VM);
        VirtualMachine VM2 = Hypervisor.CreateVMachine(numeFisier, 3);
        Hypervisor.LoadVMachine(VM2);
        VirtualMachine VM3 = Hypervisor.CreateVMachine(numeFisier, 6);
        Hypervisor.LoadVMachine(VM3);
        VirtualMachine VM4 = Hypervisor.CreateVMachine(numeFisier, 2);
        Hypervisor.listareVMachineExistente();
        VirtualMachine VM5 = Hypervisor.CreateVMachineBasedOnVMachine(VM2, 4);
        Hypervisor.LoadVMachine(VM5);
        Hypervisor.AddApplication(VM5, "fisier3", "fisier4");
        System.out.println(VM5);
        Hypervisor.AddResource_Processor(VM);
        System.out.println(Hypervisor.listaProcesoareFizice);

    }
}
