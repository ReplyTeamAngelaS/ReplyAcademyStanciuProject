package eu.reply.academy.lesson1lesson2;

import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

public class Problema {
    // O metoda care primeste un numar int ca parametru si intoarce inapoi suma divizorilor numarului impartita
    // la numarul de divizori (media = float)

    public static void main (String[] args)
    {
        float medie=Medie(10);
    }

    @Contract(pure = true)
    public static float Medie(int number)
    {
        int[] vector =new int[number];
        int c=0;
        for(int i=1; i<=number/2; i++)
        {
            if(number%i==0)
            {
                vector[c]=i;
                c++;
            }
        }
        vector[c]=number;
        int nrDiv=0;
        float suma=0;
        float medie;
        for (int i=0;i<vector.length;i++)
        {
            suma+=vector[i];
            if(vector[i]!=0)
            {
                nrDiv++;
            }
        }
        medie=suma/nrDiv;
        return medie;
    }

    public static void AfiseazaMedia(int @NotNull [] vector)
    {
        int nrDiv=0;
        float suma=0;
        float medie;
        for (int i=0;i<vector.length;i++)
        {
            suma+=vector[i];
            if(vector[i]!=0)
            {
                nrDiv++;
            }
        }
        medie=suma/nrDiv;
        System.out.print(medie);
    }
}
