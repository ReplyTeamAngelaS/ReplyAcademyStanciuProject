package eu.reply.academy.lesson18;

public class Chirurg implements Operatie {


    @Override
    public void areOperatie() {
        System.out.println("Chirurgul are operatie de apendicita.");
    }
}
