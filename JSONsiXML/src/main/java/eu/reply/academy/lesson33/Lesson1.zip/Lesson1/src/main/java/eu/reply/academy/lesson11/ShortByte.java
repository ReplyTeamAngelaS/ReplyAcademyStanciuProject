package eu.reply.academy.lesson11;

public class ShortByte {

    public static void main(String[] args) {
        byte day = 31;
        System.out.println(day);
        byte sumday = (byte) (31 + 120);
        System.out.println(sumday);
        byte minusday = 120 - 30;
        System.out.println(minusday);
        byte minusday2 = (byte) (450 - 50);
        System.out.println(minusday2);
    }
}
