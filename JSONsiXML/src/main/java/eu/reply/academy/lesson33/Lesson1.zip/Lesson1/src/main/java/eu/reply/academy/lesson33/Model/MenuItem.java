package eu.reply.academy.lesson33.Model;

public class MenuItem {
}
