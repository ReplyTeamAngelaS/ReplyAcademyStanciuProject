package eu.reply.academy.lesson21;

import java.util.Scanner;

public class Program {

    public static void main(String[] args) {
        int number = Program.citireNumar();
        long produs = Program.calculeazaProdusul(number);
        System.out.println("Rezultatul este: " + produs);
    }

    public static int citireNumar() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter number: ");
        int number = scanner.nextInt();
        if (number >= Math.pow(2, 31)) {
            return citireNumar();
        } else {
            return number;
        }
    }

    public static long calculeazaProdusul(int number) {
        long produs = 1;
        while (number / 10 != 0) {
            int cifra = number % 10;
            if (cifra % 2 != 0) {
                produs *= cifra;
            }
            number = number / 10;
        }
        if (produs == 1) {
            return -1;
        } else {
            return produs;
        }
    }
}
