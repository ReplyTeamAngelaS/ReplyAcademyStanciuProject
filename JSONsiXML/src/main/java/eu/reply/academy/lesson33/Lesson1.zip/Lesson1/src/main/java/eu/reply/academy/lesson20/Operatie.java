package eu.reply.academy.lesson20;

public abstract class Operatie {

    public abstract void operatie();
}
