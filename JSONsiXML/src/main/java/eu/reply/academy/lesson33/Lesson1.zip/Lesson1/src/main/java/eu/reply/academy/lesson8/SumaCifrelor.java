package eu.reply.academy.lesson8;

import java.lang.reflect.Array;
import java.util.Arrays;

public class SumaCifrelor {

    public static void main(String[] args) {
       /* int rezultat = SumaCifrelor.calculeazaSumaCifrelor(151);
        System.out.println(rezultat);*/

        /*int rezultat2 = SumaCifrelor.calculeazaSumaCifrelorRecursiv(11);
        System.out.println("Rezultatul este: " + rezultat2);*/

       /* int count = SumaCifrelor.calculeazaNumarulDeCifreRecursiv(101321);
        System.out.println("Rezultatul este: " + count);*/

        /*int[] vector = {2, 3, 4, 5};
        int[] vectorInvers = SumaCifrelor.calculeazaInversulVectorului(vector);
        System.out.println("Rezultatul este: " + Arrays.toString(vectorInvers));*/

        /*int[] vector = {9, 3};
        // System.out.println(Arrays.toString(SumaCifrelor.calculeazaInversulVectoruluiRecursiv(vector)));

        int number = 12;
        System.out.println(Integer.bitCount(number));*/

        /*int i = 0;
        int[] vector = {3, 4, 5, 6};
        int[] vectorInversat = new int[vector.length];
        vectorInversat = SumaCifrelor.inversareVectorRecursiv(i, vector, vectorInversat);
        System.out.println(Arrays.toString(vectorInversat));*/

        /*int n = 10;
        int p = 3;
        int result = SumaCifrelor.powRecursiv(p, n);
        System.out.println("Rezultatul este: " + result);*/

        int[] vector = {1, 2, 9, 2, 1};
        int i = 0;
        int[] vectorR = new int[vector.length];
        vectorR = SumaCifrelor.problemaRecursiv(vector, i, vectorR);
        System.out.println("Rezultatul este: " + Arrays.toString(vectorR));
    }

    public static int calculeazaSumaCifrelor(int numar) {
        int sum = 0;
        if (numar / 10 == 0) {
            sum += numar;
        } else {
            while (numar != 0) {
                sum += numar % 10;
                numar = numar / 10;
            }
        }
        System.out.println("Rezultatul este: " + sum);
        return sum;
    }

    public static int calculeazaSumaCifrelorRecursiv(int numar) {
        if (numar >= 0) {
            if (numar / 10 == 0) {
                return numar;
            } else {
                return numar % 10 + calculeazaSumaCifrelorRecursiv(numar / 10);
            }
        } else
            return 0;
    }

    public static int calculeazaNumarulDeCifreRecursiv(int numar) {
        if (numar >= 0) {
            if (numar / 10 == 0) {
                return 1;
            } else {
                return 1 + calculeazaNumarulDeCifreRecursiv(numar / 10);
            }
        } else
            return 0;
    }

    public static int[] calculeazaInversulVectorului(int[] vector) {
        if (vector == null) {
            return new int[]{0};
        }
        int[] vectorInvers = new int[vector.length];
        for (int i = 0; i < vector.length; i++) {
            vectorInvers[i] = vector[vector.length - 1 - i];
        }
        return vectorInvers;
    }

    /*public static int[] calculeazaInversulVectoruluiRecursiv(int[] vector) {
        if (vector == null) {
            return new int[]{0};
        }
        if (vector.length == 1 || vector.length == 0) {
            return vector;
        } else {
           // return Arrays.copyOf(Arrays.copyOfRange(vector,vector.length-1,vector.length-2),calculeazaInversulVectoruluiRecursiv(Arrays.copyOfRange(vector, 0, vector.length - 1)));
      // Array.ne
        }

return vector;
    }*/

    public static int[] inversareVectorRecursiv(int i, int[] vector, int[] vectorInvers) {
        if (i == vector.length) {
            return vectorInvers;
        } else {
            vectorInvers[i] = vector[vector.length - i - 1];
            i++;
            return inversareVectorRecursiv(i, vector, vectorInvers);
        }
    }

    public static int powRecursiv(int p, int n) {
        if (p == 0)
            return 1;
        else
            return n * powRecursiv(p - 1, n);
    }

    public static boolean estePalindrom(int[] vector) {
        boolean bol = true;
        if (vector.length == 1) {
            return true;
        }
        for (int i = 0; i < vector.length / 2; i++) {
            if (vector[i] != vector[vector.length - 1 - i]) {
                bol = false;
                break;
            }
        }
        return bol;
    }

    public static boolean estePalindromRecursiv(int[] vector, int i) {
        if (vector.length == 1) {
            return true;
        }
        if (i < vector.length / 2) {
            if (vector[i] != vector[vector.length - 1 - i]) {
                return false;
            }
        }
        if (i == vector.length / 2) {
            return true;
        }
        return estePalindromRecursiv(vector, i + 1);
    }

    public static int[] problemaRecursiv(int[] vector, int i, int[] vectorR) {
        if (vector.length == 1) {
            return new int[]{2 * vector[0]};
        }
        if (i < vector.length) {
            if (i == 0) {
                vectorR[i] = 2 * vector[i] + vector[i + 1];
            } else if (i == vector.length - 1) {
                vectorR[i] = 2 * vector[i] + vector[i - 1];
            } else {
                vectorR[i] = 2 * vector[i] + vector[i - 1] + vector[i + 1];
            }
        }
        if (i == vector.length) {
            return vectorR;
        }
        return problemaRecursiv(vector, i + 1, vectorR);
    }
}
