package eu.reply.academy.lesson13;

import java.util.Scanner;

public class Problema {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int count = 0;
        System.out.println("Primul numar este: ");
        int numar1 = Integer.parseInt(scan.nextLine());
        System.out.println("Al doilea numar este: ");
        int numar2 = Integer.parseInt(scan.nextLine());
        System.out.println("Al treilea numar este: ");
        int numar3 = Integer.parseInt(scan.nextLine());
        int[] numere = new int[]{numar1, numar2, numar3};
        int sum = 0;
        for (int i = 0; i < numere.length; i++) {
            sum += numere[i];
        }
        float media = sum / numere.length;
        System.out.println("Media este: " + media);


    }
}
