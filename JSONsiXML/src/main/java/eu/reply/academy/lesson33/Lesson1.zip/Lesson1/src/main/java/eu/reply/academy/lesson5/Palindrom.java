package eu.reply.academy.lesson5;

import java.util.Scanner;

public class Palindrom {

    public static void main(String[] args) {

    }

    public static String citireTastatura() {
        Scanner sc = new Scanner(System.in);
        String rezultat = sc.nextLine();
        return rezultat;
    }

    public static boolean estePalindrom(String linie) {
        boolean rezultat = false;
        return rezultat;
    }
}
