package eu.reply.academy.lesson14;

import java.util.Arrays;
import java.util.Scanner;

public class SirMaxMin {

    public static void main(String[] args) {
        int n = SirMaxMin.daNumarN();
        int[] vector = SirMaxMin.citireSir(n);
        SirMaxMin.afiseazaSir(vector);
    }

    public static int daNumarN() {
        Scanner scan = new Scanner(System.in);
        System.out.print("Numarul natural reprezentand dimensiunea sirului este: ");
        int n = scan.nextInt();
        if (!((n >= 1) && (n <= 1000))) {
            System.out.println("Numarul trebuie sa fie in intervalul 1 si 1000.");
            return daNumarN();
        }
        return n;
    }

    public static int daNumarSir() {
        Scanner scan = new Scanner(System.in);
        System.out.print("Scrie un numar natural: ");
        int n = scan.nextInt();
        if (!(n <= 100000)) {
            System.out.println("Numarul trebuie sa fie mai mic decat 100.000");
            return daNumarSir();
        }
        return n;
    }

    public static int[] citireSir(int n) {
        int[] vector = new int[n];
        for (int i = 0; i < vector.length; i++) {
            vector[i] = ValoareaAbsoluta.daNumarSir();
        }
        System.out.println("-----------------------------------------------");
        System.out.println("Numerele din sir sunt: " + Arrays.toString(vector));
        return vector;
    }

    public static void afiseazaSir(int[] vector) {
        int minim = vector[0];
        int maxim = vector[0];
        int pozitiaMin = 0;
        int pozitiaMax = 0;
        for (int i = 1; i < vector.length; i++) {
            if (minim > vector[i]) {
                minim = vector[i];
                pozitiaMin = i;
            }
            if (maxim < vector[i]) {
                maxim = vector[i];
                pozitiaMax = i;
            }
        }
        System.out.print("Rezultatul este: ");
        if (pozitiaMax < pozitiaMin) {
            int aux = pozitiaMax;
            pozitiaMax = pozitiaMin;
            pozitiaMin = aux;
        }
        for (int i = pozitiaMin; i <= pozitiaMax; i++) {
            System.out.print(vector[i] + " ");
        }
    }
}
