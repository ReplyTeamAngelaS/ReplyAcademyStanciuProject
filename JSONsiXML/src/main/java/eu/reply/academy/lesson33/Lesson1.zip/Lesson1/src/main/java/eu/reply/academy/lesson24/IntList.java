package eu.reply.academy.lesson24;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class IntList extends ManagerDeListe<Integer> {

    public List<Integer> listaOrdonataDeInteger = new ArrayList<>();

    @Override
    protected void adaugareElement(Integer valoare) {
        if (this.listaOrdonataDeInteger.isEmpty()) {
            this.listaOrdonataDeInteger.add(valoare);
        } else {
            this.listaOrdonataDeInteger.add(valoare);
            Collections.sort(this.listaOrdonataDeInteger);
        }
        System.out.println("S-a adaugat cu succes elementul!");
    }

    @Override
    protected void stergerePrimulElementCuValoareaData(Integer valoare) {
        if (this.listaOrdonataDeInteger.isEmpty()) {
            System.out.println("Lista De Integer este goala!");
        } else {
            boolean bol = this.listaOrdonataDeInteger.remove(valoare);
            if (bol == false) {
                System.out.println("Nu exista valoarea data in lista!");
            } else {
                Collections.sort(this.listaOrdonataDeInteger);
                System.out.println("S-a sters cu succes elementul dat!");
            }
        }
    }

    @Override
    protected void stergereElementCuIndexulDat(int index) {
        if (this.listaOrdonataDeInteger.isEmpty()) {
            System.out.println("Lista de Integer este goala!");
        } else {
            if (index < this.listaOrdonataDeInteger.size()) {
                this.listaOrdonataDeInteger.remove(index);
            } else {
                System.out.println("Indexul este mult prea mare!");
            }
        }
    }

    @Override
    protected void listareElemente() {
        if (!this.listaOrdonataDeInteger.isEmpty()) {
            System.out.print("Lista de Integer este urmatoarea:");
            for (Integer val : this.listaOrdonataDeInteger) {
                System.out.print(val + " ");
            }
        }
        System.out.println(" ");
    }

    @Override
    protected void comparareDouaListe(ManagerDeListe obiect2) {
        long suma1 = this.calculareSumaElemente();
        long suma2 = obiect2.calculareSumaElemente();
        System.out.println("Suma pentru prima lista este: " + suma1);
        System.out.println("Suma pentru a doua lista este: " + suma2);
        if (suma1 == suma2) {
            System.out.println("Cele doua liste sunt egale!");
        } else if (suma1 > suma2) {
            System.out.println("Prima lista este mai mare!");
        } else {
            System.out.println("A doua lista este mai mare!");
        }
    }

    @Override
    protected long calculareSumaElemente() {
        long suma = 0;
        if (!this.listaOrdonataDeInteger.isEmpty()) {
            for (Integer val : this.listaOrdonataDeInteger) {
                suma += val;
            }
        }
        return suma;
    }
}
