package eu.reply.academy.lesson4;

import java.util.Arrays;
import java.util.Optional;
import java.util.OptionalInt;

public class Tema2 {

    public static void main(String[] args) {
        //O metoda care primeste un vector de m elemente si sa se afiseze numerele pare si pozitia pe care se afla
        int[] vector = new int[]{2, 5, 7, 3, 5, 4, 0};
        Tema2.calculeaza(vector);
        Tema2.calculeazaCuWhile(vector);
    }

    public static void calculeaza(int[] vector) {
        try {
            int[][] matrice = new int[2][vector.length];
            int c = 0;
            for (int i = 0; i < vector.length; i++) {
                if (vector[i] % 2 == 0) {
                    matrice[0][c] = vector[i];
                    matrice[1][c] = i;
                    c++;
                }
            }
            for (int j = 0; j < matrice.length; j++) {
                int[] vectorLinie = Arrays.stream(matrice[j]).limit(c).toArray();
                if (j == 0) {
                    System.out.println("Valorile pare sunt:" + Arrays.toString(vectorLinie));
                } else {
                    System.out.println("Pozitiile respective valorilor de mai sus sunt:" + Arrays.toString(vectorLinie));
                }
            }
        } catch (NullPointerException e) {
            System.out.println("NullPointerException");
        }
    }

    public static void calculeazaCuWhile(int[] vector) {
        try {
            int[][] matrice = new int[2][vector.length];
            int i = 0;
            int j = 0;
            int c = 0;
            while (i < vector.length) {
                if (vector[i] % 2 == 0) {
                    matrice[0][c] = vector[i];
                    matrice[1][c] = i;
                    c++;
                }
                i++;
            }
            while (j < matrice.length) {
                int[] vectorLinie = Arrays.stream(matrice[j]).limit(c).toArray();
                if (j == 0) {
                    System.out.println("Numerele pare din vector sunt: " + Arrays.toString(vectorLinie));
                } else {
                    System.out.println("Pozitiile numerelor pare sunt urmatoarele:" + Arrays.toString(vectorLinie));
                }
                j++;
            }
        } catch (NullPointerException e) {
            System.out.println("NullPointerException");
        }
    }
}
