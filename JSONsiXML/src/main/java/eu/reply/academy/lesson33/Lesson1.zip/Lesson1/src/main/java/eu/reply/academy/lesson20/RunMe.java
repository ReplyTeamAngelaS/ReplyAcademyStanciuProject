package eu.reply.academy.lesson20;

public class RunMe {

    public static void main(String[] args) {

        Operatie operatie01 = new OperatiePeCreier01();
        Operatie operatie02 = new OperatiePeCreier02();
        Surgeon d1 = new BrainSurgeon();
        d1.tipChirurg();
        d1.addOperatie(operatie01);
        d1.addOperatie(operatie02);
        d1.operatie(operatie01);
        d1.operatie(operatie02);
        System.out.println("");

        Operatie operatie03 = new OperatiePeInima01();
        Operatie operatie04 = new OperatiePeInima02();
        Surgeon d2 = new HeartSurgeon();
        d2.tipChirurg();
        d2.addOperatie(operatie03);
        d2.addOperatie(operatie04);
        d2.operatie(operatie03);
        d2.operatie(operatie04);
    }

}
