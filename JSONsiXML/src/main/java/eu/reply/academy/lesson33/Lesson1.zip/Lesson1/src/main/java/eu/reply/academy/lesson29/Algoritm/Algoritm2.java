package eu.reply.academy.lesson29.Algoritm;

import static java.lang.Integer.parseInt;

public class Algoritm2 {

    String original;

    Algoritm2(String original) {
        this.original = original;
    }

    public static void main(String[] args) {


        Algoritm2 original1 = new Algoritm2("1");
        Algoritm2 original2 = new Algoritm2("2");
        swapByReference(original1, original2);
        System.out.println(original1.original); // 2 (not in Java)
        System.out.println(original2.original); // 1 (not in Java)

parseInt("0");
Integer.valueOf(0);
int x=Integer.parseInt("5");
        System.out.println(x);
        Integer y=Integer.parseInt("5");
        System.out.println(y);
    }

    static void swapByReference(Algoritm2 a, Algoritm2 b) {
        // Algoritm2 temp = a;
        // a = b;
        //  b = temp;
        a.original = "2";
        b.original = "1";
    }
}
