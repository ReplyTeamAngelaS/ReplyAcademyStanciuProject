package eu.reply.academy.lesson16;

import junit.framework.TestCase;
import org.junit.Assert;
import org.junit.Test;

public class EmailValidationTest extends TestCase {

    @Test
    public void test01() { Assert.assertEquals(false, EmailValidation.validateEmail("@edabit.com")); }

    @Test
    public void test02() {
        Assert.assertEquals(false, EmailValidation.validateEmail("@edabit"));
    }

    @Test
    public void test03() {
        Assert.assertEquals(true, EmailValidation.validateEmail("matt@edabit.com"));
    }

    @Test
    public void test04() { Assert.assertEquals(false, EmailValidation.validateEmail("")); }

    @Test
    public void test05() {
        Assert.assertEquals(false, EmailValidation.validateEmail("hello.gmail@com"));
    }

    @Test
    public void test06() { Assert.assertEquals(true, EmailValidation.validateEmail("bill.gates@microsoft.com")); }

    @Test
    public void test07() {
        Assert.assertEquals(false, EmailValidation.validateEmail("hello@email"));
    }

    @Test
    public void test08() {
        Assert.assertEquals(false, EmailValidation.validateEmail("%^%$#%^%"));
    }

    @Test
    public void test09() { Assert.assertEquals(false, EmailValidation.validateEmail("www.email.com")); }

    @Test
    public void test10() {
        Assert.assertEquals(false, EmailValidation.validateEmail("email"));
    }

}