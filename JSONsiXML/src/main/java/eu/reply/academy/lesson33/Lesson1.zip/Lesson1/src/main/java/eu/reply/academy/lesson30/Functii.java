package eu.reply.academy.lesson30;

import java.util.Arrays;
import java.util.Scanner;

public class Functii {

    public int[] vector;

    public void citesteVector(int numar) {
        Scanner scanner = new Scanner(System.in);
        this.vector = new int[numar];
        System.out.println("Dati " + numar + " numere:");
        int contor = 0;
        while (contor < numar) {
            int element = scanner.nextInt();
            this.vector[contor] = element;
            contor++;
        }
    }

    private int aflareMaxim() {
        int maxim = 0;
        for (int i = 0; i < vector.length; i++) {
            if (maxim < vector[i]) {
                maxim = vector[i];
            }
        }
        return maxim;
    }

    private void stergereNumar(int numar) {
        int[] vector2 = new int[vector.length - 1];
        boolean isTrue = false;
        for (int i = 0; i < vector.length - 1; i++) {
            if (vector[i] == numar) {
                vector[i] = vector[i + 1];
                isTrue = true;
            }
            if (isTrue) {
                vector[i] = vector[i + 1];
            }
        }
        for (int j = 0; j < vector2.length; j++) {
            vector2[j] = vector[j];
        }
        this.vector = vector2;
    }

    public void stergerePrimeleDouaNumereMari() {
        int primulMaxim = aflareMaxim();
        this.stergereNumar(primulMaxim);
        int alDoileaMaxim = aflareMaxim();
        this.stergereNumar(alDoileaMaxim);
    }

    public void stergeNNumere(int numar) {
        while (numar > 0) {
            int maxim = aflareMaxim();
            this.stergereNumar(maxim);
            numar--;
        }
    }
}
