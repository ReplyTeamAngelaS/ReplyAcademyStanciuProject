package eu.reply.academy.lesson24;

import eu.reply.academy.lesson24.ManagerDeListe;
import eu.reply.academy.lesson24.StringList;

public class RunMe {

    public static void main(String[] args) {

        ManagerDeListe<String> lista1 = new StringList();
        ManagerDeListe<String> lista2 = new StringList();

        ManagerDeListe<Integer> lista3 = new IntList();
        ManagerDeListe<Integer> lista4 = new IntList();

        lista1.adaugareElement("1");
        lista1.listareElemente();
        lista1.adaugareElement("5");
        lista1.adaugareElement("3");
        lista1.adaugareElement("5");
        lista1.listareElemente();
        lista1.adaugareElement("2");
        lista1.adaugareElement("8");
        lista1.listareElemente();
        lista1.stergerePrimulElementCuValoareaData("5");
        lista1.listareElemente();
        lista1.stergereElementCuIndexulDat(3);
        lista1.listareElemente();
        System.out.println("------------");
        lista2.adaugareElement("10");
        lista2.adaugareElement("50");
        lista2.adaugareElement("31");
        lista2.adaugareElement("51");
        lista2.listareElemente();
        System.out.println("------------");
        lista1.listareElemente();
        lista2.listareElemente();
        lista1.comparareDouaListe(lista2);
        System.out.println("--------------");
        lista3.adaugareElement(1);
        lista3.listareElemente();
        lista3.adaugareElement(5);
        lista3.adaugareElement(3);
        lista3.adaugareElement(5);
        lista3.listareElemente();
        lista3.adaugareElement(2);
        lista3.adaugareElement(8);
        lista3.listareElemente();
        lista3.stergerePrimulElementCuValoareaData(5);
        lista3.listareElemente();
        lista3.stergereElementCuIndexulDat(3);
        lista3.listareElemente();
        System.out.println("------------");
        lista4.adaugareElement(10);
        lista4.adaugareElement(50);
        lista4.adaugareElement(31);
        lista4.adaugareElement(51);
        lista4.listareElemente();
        System.out.println("------------");
        lista3.listareElemente();
        lista4.listareElemente();
        lista3.comparareDouaListe(lista4);
    }
}
