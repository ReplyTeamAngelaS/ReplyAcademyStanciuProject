package eu.reply.academy.ACADEMIA_JAVA.sss;

public class B {

    protected String a;

    public B(String a){
        this.a=a;
    }

}
