package eu.reply.academy.lesson12;

public class Person {

    public int varsta;
    public String culoareOchi;
    public float inaltime;

    @Override
    public String toString() {
        return "Person{" +
                "varsta=" + varsta +
                ", culoareOchi='" + culoareOchi + '\'' +
                ", inaltime=" + inaltime +
                '}';
    }
}
