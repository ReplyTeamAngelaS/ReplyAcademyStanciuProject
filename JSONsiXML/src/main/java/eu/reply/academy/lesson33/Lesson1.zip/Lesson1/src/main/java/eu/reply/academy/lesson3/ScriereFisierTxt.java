package eu.reply.academy.lesson3;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ScriereFisierTxt {

    //Scrieti intr-un fisier suma numerolor pare de pe diagonala principala si secundara

    public static void main(String[] args) throws FileNotFoundException {
        File file=new File("C:\\Users\\Angela Stanciu\\IdeaProjects\\Lesson1\\src\\main\\java\\eu\\reply\\academy\\lesson3\\fisierTxtProb2");
        CitireFisTxt(file);

    }

    public static void CitireFisTxt(File file) throws FileNotFoundException {
        Scanner sc = new Scanner(file);
        int nrLinii=0;
        int nrColoane=0;

        while (sc.hasNextLine())
        {
            String[] linie=sc.nextLine().trim().split(" ");
            nrLinii++;
            for(int i=0; i<linie.length;i++)
            {
                nrColoane++;
            }
        }
    }

    public static void parcurgereMatrice()
    {
        //for(int i=0; i<)
    }

}
