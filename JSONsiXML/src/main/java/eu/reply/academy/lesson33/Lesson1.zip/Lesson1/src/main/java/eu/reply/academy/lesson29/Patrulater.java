package eu.reply.academy.lesson29;

public abstract class Patrulater{

    private double lungime;
    private double latime;

    protected Patrulater(double lungime, double latime) {
        this.lungime = lungime;
        this.latime = latime;
    }

    protected Patrulater() {

    }

    protected double getLungime() {
        return this.lungime;
    }

    protected double getLatime() {
        return this.latime;
    }

    protected void setLungime(double lungime) {
        this.lungime = lungime;
    }

    protected void setLatime(double latime) {
        this.latime = latime;
    }

    protected abstract double calculeazaAria();
}
