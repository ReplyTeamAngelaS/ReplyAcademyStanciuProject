package eu.reply.academy.lesson14;

public class Problema {

    int roomInBelly = 5;

    public void eatCheese(int bitesOfCheese) {
        while (bitesOfCheese > 0 && roomInBelly > 0) {
            bitesOfCheese--;
            roomInBelly--;
        }
        System.out.println(bitesOfCheese + " pieces of cheese left");
    }
}

class Prib {
    public static void main(String[] args) {
        Problema problema = new Problema();
        problema.eatCheese(7);
        boolean bol=false;
        if(bol = true) { // DOES NOT COMPILE

        }
    }
}
