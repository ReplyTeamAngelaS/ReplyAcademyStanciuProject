package eu.reply.academy.lesson20;

public class OperatiePeCreier02 extends Operatie {

    @Override
    public void operatie() {
        System.out.println("Doctorul chirurg face o operatie pe creier in emisfera dreapta.");
    }
}
