package eu.reply.academy.lesson23.beans;

public class Tara {

    public String codtara;
    public String nume;
}
