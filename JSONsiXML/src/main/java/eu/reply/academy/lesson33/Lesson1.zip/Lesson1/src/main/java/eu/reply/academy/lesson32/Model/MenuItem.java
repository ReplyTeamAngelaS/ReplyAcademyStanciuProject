package eu.reply.academy.lesson32.Model;

import java.util.ArrayList;
import java.util.List;

public class MenuItem {

}
