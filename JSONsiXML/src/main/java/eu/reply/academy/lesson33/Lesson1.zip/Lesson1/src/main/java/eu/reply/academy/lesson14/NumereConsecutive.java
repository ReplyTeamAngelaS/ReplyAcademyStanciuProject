package eu.reply.academy.lesson14;

import eu.reply.academy.lesson13.NumarMinim;

import java.util.Scanner;

public class NumereConsecutive {

    public static void main(String[] args) {
        int suma = NumereConsecutive.citireNumereSiCacluleazaSuma();
        if (suma < 1000000000) {
            System.out.println("Suma numerelor naturale mai mici decat 1.000.000.000 este: " + suma);
        } else {
            System.out.println("Suma numerelor naturale depaseste 1.000.000.000.");
        }

    }

    public static int citireNumereSiCacluleazaSuma() {
        Scanner scan = new Scanner(System.in);
        int sum = 0;
        System.out.println("Scrie un sir de numere naturale:");
        int a = scan.nextInt();
        int b = scan.nextInt();
        if (a < 1000000 && b < 1000000) {
            sum = sum + a + b;
            while (a != b) {
                int c = scan.nextInt();
                if (c < 1000000) {
                    sum = sum + c;
                    a = b;
                    b = c;
                }
            }
        }
        return sum;
    }
}
