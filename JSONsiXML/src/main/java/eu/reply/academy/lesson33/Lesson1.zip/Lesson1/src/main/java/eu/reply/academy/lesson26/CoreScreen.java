package eu.reply.academy.lesson26;

public class CoreScreen extends Core {

    protected final static String TIP_CORE = "CoreScreen";
    protected static final int INDEX_CORESCREEN = 2;
    protected static int CONTOR_CORE = 1;

    protected CoreScreen() {
        this.setID();
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Core: ID- #" + this.ID + "; Tip Core- " + CoreScreen.TIP_CORE + ";\n");
        return stringBuilder.toString();
    }
}
