package eu.reply.academy.lesson28.Main;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Vector;

public class CoreScreen extends Core {

    protected CoreScreen() {
        super();
        this.Type = "Core Screen";
    }

    @Override
    protected void action(String application) {
        Vector<String> lines = Core.readFile(application);
        for (String line : lines) {
            System.out.println(line);
        }
        System.out.println("\n");
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Core: ID- #" + this.Id + ", Tip- " + this.Type + "\n");
        return stringBuilder.toString();
    }

}
