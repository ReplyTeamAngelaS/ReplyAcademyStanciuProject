package eu.reply.academy.lesson31;

public interface StringMic<T, U, R> {

    R findStringMic(T nume, U nume2);
}
