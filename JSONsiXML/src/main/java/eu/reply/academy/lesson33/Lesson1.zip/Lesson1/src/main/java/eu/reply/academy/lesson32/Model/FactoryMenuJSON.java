/*
package eu.reply.academy.lesson32.Model;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.util.ArrayList;
import java.util.List;


public class FactoryMenuJSON extends FactoryMenu {

    public List<MenuItem> createMenuItem(String path, String fileName) {
        List<MenuItem> menuItemList = new ArrayList<>();
        try {
            StringBuilder stringBuilder = readFileText(path, fileName + ".json");
            JSONObject jsonObject = (JSONObject) new JSONParser().parse(stringBuilder.toString());
            JSONArray jsonArray = (JSONArray) jsonObject.get("Menu");
            for (int i = 0; i < jsonArray.size(); i++) {
                Menu menu = createObjectMenuJSON((JSONObject) jsonArray.get(i));
                menuItemList.add(menu);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return menuItemList;
    }

    private Menu createObjectMenu(JSONObject jsonObject) {
        List<MenuItem> menuItemList = new ArrayList<>();
        JSONArray jsonArray = (JSONArray) jsonObject.get("popupList");
        for (int i = 0; i < jsonArray.size(); i++) {
            this.createObjectItemJSON((JSONObject) jsonArray.get(i), menuItemList);
        }
        Menu menu = new Menu((String) jsonObject.get("idMenu"), (String) jsonObject.get("valueMenu"), menuItemList);
        return menu;
    }

    private void createObjectItemJSON(JSONObject jsonObject, List<MenuItem> menuItemList) {
        Item item = new Item((String) jsonObject.get("idItem"), (String) jsonObject.get("labelItem"), (String) jsonObject.get("valueItem"), (String) jsonObject.get("onClick"));
        menuItemList.add(item);
    }
}
*/
