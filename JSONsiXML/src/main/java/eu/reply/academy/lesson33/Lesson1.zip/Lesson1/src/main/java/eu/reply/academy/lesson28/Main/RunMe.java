package eu.reply.academy.lesson28.Main;

import java.util.Arrays;

public class RunMe {
    public static final String PATH = "C:\\Users\\Angela Stanciu\\IdeaProjects\\Lesson1\\src\\main\\java\\eu\\reply\\academy\\lesson28\\listaFisiere";

    public static void main(String[] args) {
        String name1 = "VirtualMachine01.txt";
        String name2 = "VirtualMachine02.txt";
        String name3 = "VirtualMachine03.txt";
        VirtualMachine virtualMachine1 = Hypervisor.createVMachine(PATH, name1, 1);
        VirtualMachine virtualMachine2 = Hypervisor.createVMachine(PATH, name2, 2);
        VirtualMachine virtualMachine3 = Hypervisor.createVMachine(PATH, name3, 3);
        Hypervisor.printVMachinesCreated();
        Core coreDisk = new CoreDisk();
        Core coreDisk2 = new CoreDisk();
        Core coreScreen = new CoreScreen();
        Processor processor1 = new Processor();
        processor1.addCore(coreDisk);
        Processor processor2 = new Processor();
        processor2.addCore(coreDisk2);
        processor2.addCore(coreScreen);
        Hypervisor.addProcessor(processor1);
        Hypervisor.addProcessor(processor2);
        Hypervisor.printProcessors();
        Hypervisor.addApplication(virtualMachine1, "fisier3.txt");
        System.out.println(virtualMachine1);
        coreDisk.action(virtualMachine1.getListAplications().get(0));
        coreScreen.action(virtualMachine1.getListAplications().get(1));
        Hypervisor.dischargeVMachine(virtualMachine1, "ListApplications01");
        Hypervisor.load(virtualMachine1, coreDisk);
        Hypervisor.load(virtualMachine1, coreDisk2);
        Hypervisor.load(virtualMachine1, coreScreen);
        Hypervisor.load(virtualMachine1, coreDisk);
        Hypervisor.load(virtualMachine1, coreDisk2);
        Hypervisor.load(virtualMachine1, coreScreen);
        ////////////////////////////////////////////////////////////////////////////
        VirtualMachine vm = Hypervisor.createVMachine(PATH, name1, 5);
        Hypervisor.addApplication(vm, "fisier10.txt");
        System.out.println(vm);
        Hypervisor.dischargeVMachine(vm, "ListaAplicatii03.txt");
        VirtualMachine vm1 = Hypervisor.createVMachine(PATH, name1, 5);
        System.out.println(vm1);
        VirtualMachine vm2 = Hypervisor.createVMachineBasedOnAnotherMachine(vm1, 6);
        System.out.println(vm2);
    }
}
