package eu.reply.academy.lesson16;

public class Switcharoo {

    public static void main(String[] args) {
        String str5 = "";
        String str = "[]";
        String str1 = "ada";
        String str2 = "Ada";
        String str3 = "z";
        String str4 = "Cat, dog, and mouse.";
        String rezultat5 = Switcharoo.flipEndChars(str5);
        String rezultat = Switcharoo.flipEndChars(str);
        String rezultat1 = Switcharoo.flipEndChars(str1);
        String rezultat2 = Switcharoo.flipEndChars(str2);
        String rezultat3 = Switcharoo.flipEndChars(str3);
        String rezultat4 = Switcharoo.flipEndChars(str4);
        System.out.println(rezultat5);
        System.out.println(rezultat);
        System.out.println(rezultat1);
        System.out.println(rezultat2);
        System.out.println(rezultat3);
        System.out.println(rezultat4);
    }

    public static String flipEndChars(String str) {
        String rezultat;
        if (str.length() < 2) {
            rezultat = "Incompatible.";
            System.out.println(rezultat);
            return rezultat;
        } else {
            char primu = str.charAt(0);
            char ultimu = str.charAt(str.length() - 1);
            if (primu == ultimu) {
                rezultat = "Two's a pair.";
                System.out.println(rezultat);
                return rezultat;
            } else {
                if (str.length() == 2) {
                    rezultat = String.valueOf(ultimu) + String.valueOf(primu);
                    System.out.println(rezultat);
                    return rezultat;
                } else {
                    rezultat = str.substring(0, str.length() - 1);
                    rezultat = rezultat.replaceFirst(String.valueOf(primu), String.valueOf(ultimu));
                    rezultat = rezultat.concat(String.valueOf(primu));
                    System.out.println(rezultat);
                    return rezultat;
                }
            }
        }
    }
}
