package eu.reply.academy.lesson23.beans;

public class TipUAT {

    public int id;
    public String tip;

}
