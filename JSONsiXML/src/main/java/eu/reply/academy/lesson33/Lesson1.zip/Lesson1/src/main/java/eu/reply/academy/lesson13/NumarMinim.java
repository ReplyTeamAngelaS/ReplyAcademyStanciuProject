package eu.reply.academy.lesson13;

import java.util.Scanner;

public class NumarMinim {

    public static void main(String[] args) {
        long n, c, r;
        n = NumarMinim.daNumarulN();
        c = NumarMinim.daNumarulC();
        r = daNumarulR(c);
        long rezultat = NumarMinim.calculeazaMinimul(n, c, r);
        System.out.println("Minimul este: " + rezultat);
    }

    public static long daNumarulN() {
        Scanner scan = new Scanner(System.in);
        System.out.print("Scrie un numar natural: ");
        long n = scan.nextLong();
        if (!((n >= 1) && (n <= 1000000000000L))) {
            System.out.println("Numarul trebuie sa fie in intervalul 1 si 1.000.000.000.000");
            return daNumarulN();
        }
        return n;
    }

    public static long daNumarulC() {
        Scanner scan = new Scanner(System.in);
        System.out.print("Scrie un numar natural, reprezentand catul impartirii: ");
        long c = scan.nextLong();
        if (!((c >= 0) && (c <= 1000000000000L))) {
            System.out.println("Numarul trebuie sa fie in intervalul 1 si 1.000.000.000.000");
            return daNumarulC();
        }
        return c;
    }

    public static long daNumarulR(long c) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Scrie un numar natural, reprezentand restul impartirii: ");
        long r = scan.nextLong();
        if (!((r >= 0) && (r <= 1000000000000L))) {
            System.out.println("Numarul trebuie sa fie in intervalul 1 si 1.000.000.000.000");
            return daNumarulR(c);
        }
        if (r >= c) {
            System.out.println("Numarul reprezentand restul, nu este valid. Este mai mare decat catul.");
            return daNumarulR(c);
        }
        return r;
    }

    public static long calculeazaMinimul(long n, long c, long r) {
        long numar = n / c + 1;
        long rezultat = numar * c + r;
        return rezultat;
    }
}
