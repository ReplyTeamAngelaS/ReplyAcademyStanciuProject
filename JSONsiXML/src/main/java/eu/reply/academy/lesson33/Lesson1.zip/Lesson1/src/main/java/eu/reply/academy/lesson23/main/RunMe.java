package eu.reply.academy.lesson23.main;

import eu.reply.academy.lesson23.beans.Oras;
import eu.reply.academy.lesson23.beans.Orase;

import java.util.ArrayList;

public class RunMe {

    public static void main(String[] args) {

        String calea = "C:\\Users\\Angela Stanciu\\IdeaProjects\\Lesson1\\src\\main\\java\\eu\\reply\\academy\\lesson23\\beans";
        String numeFisier = "orase.csv";
        Orase.load(calea, numeFisier);
        System.out.println(Orase.listaOrase.size());
        System.out.println(Orase.listaOrase.toString());
        System.out.println("-------------");
        System.out.println("Populatia cea mai mare:");
        ArrayList<Oras> lista1 = Orase.gasesteOrasulCuPopulatiaMare();
        Orase.citesteLista(lista1);
        System.out.println("Lista cu populatie zero:");
        ArrayList<Oras> lista2 = Orase.creeazaListaOrasePopulatieZero();
        Orase.citesteLista(lista2);
        System.out.println("Media populatiei este");
        long medie = Orase.calculeazaMediaPopulatiei();
        System.out.println(medie);
        System.out.println("-----------");
        ArrayList<Oras> lista3 = Orase.selectionSortDupaPopulatie();
        Orase.citesteLista(lista3);
        System.out.println("------------");
        String nume = "test.csv";
        Orase.save(lista3, calea, nume);
        System.out.println("S-a creat cu succes fisierul.");

    }
}
