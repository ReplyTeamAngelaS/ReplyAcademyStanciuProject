package eu.reply.academy.lesson31;

public class Exercitiu2 {

    public String printSubstring(int numar, String cuvant) {
        return cuvant.substring(0, numar);
    }
}
