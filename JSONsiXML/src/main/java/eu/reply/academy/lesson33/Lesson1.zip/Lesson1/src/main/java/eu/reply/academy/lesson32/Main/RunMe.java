/*
package eu.reply.academy.lesson32.Main;

import eu.reply.academy.lesson32.Model.FactoryMenuJSON;
import eu.reply.academy.lesson32.Model.FactoryMenuXML;
import eu.reply.academy.lesson32.Model.Menu;
import eu.reply.academy.lesson32.Model.MenuItem;

import java.util.List;

import static eu.reply.academy.lesson32.Model.FactoryMenu.*;


public class RunMe {

    public static void main(String[] args) {
        //CREARE OBIECTE
        Menu menuItem = new Menu();
        FactoryMenuJSON factoryMenuJSON = new FactoryMenuJSON();
        FactoryMenuXML factoryMenuXML = new FactoryMenuXML();
        //CITIRE SI AFISARE JSON
        List<MenuItem> menuItemList = factoryMenuJSON.createMenuItemJSON(PATH, NAME_FILE_JSON);
        menuItem.printMenu();
        //CITIRE SI AFISARE XML
        List<MenuItem> menuItemList1 = factoryMenuXML.createMenuItemXML(PATH, NAME_FILE_XML);
        menuItem.printMenu(menuItemList1);
    }
}
*/
