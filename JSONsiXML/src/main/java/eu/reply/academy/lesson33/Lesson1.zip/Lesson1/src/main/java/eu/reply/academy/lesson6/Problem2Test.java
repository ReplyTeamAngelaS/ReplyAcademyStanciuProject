package eu.reply.academy.lesson6;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

import static org.junit.Assert.assertEquals;

public class Problem2Test {

    @Test
    public void test01() {assertEquals(1, Problem2.countIncreasingNumbers(0));}

    @Test
    public void test02() {assertEquals(10, Problem2.countIncreasingNumbers(1));}

    @Test
    public void test03() {assertEquals(100, Problem2.countIncreasingNumbers(2));}

    @Test
    public void test04() {assertEquals(475, Problem2.countIncreasingNumbers(3));}

    @Test
    public void test05() {assertEquals(1675, Problem2.countIncreasingNumbers(4));}

    @Test
    public void test06() {assertEquals(4954, Problem2.countIncreasingNumbers(5));}

    @Test
    public void test07() {assertEquals(12952, Problem2.countIncreasingNumbers(6));}
}
