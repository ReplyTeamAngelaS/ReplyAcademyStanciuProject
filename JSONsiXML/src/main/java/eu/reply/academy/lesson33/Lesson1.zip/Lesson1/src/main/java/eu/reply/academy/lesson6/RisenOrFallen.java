package eu.reply.academy.lesson6;

import java.util.Arrays;

public class RisenOrFallen {

    public static void main(String[] args) {
        /*int[] vector = RisenOrFallen.desparteNumarul(145);
        System.out.println(Arrays.toString(vector));
        System.out.println(RisenOrFallen.esteIncreasingNumber(vector));*/

        /*int[] vector = RisenOrFallen.desparteNumarul(651);
        System.out.println(Arrays.toString(vector));
        System.out.println(RisenOrFallen.esteDecreasingNumber(vector));*/

        System.out.println(RisenOrFallen.incDec(3));
    }

    public static int incDec(int nr) {
        int count = 0;
        int number = (int) Math.pow(10, nr);
        for (int i = 1; i <= number; i++) {
            if (i < 10) {
                count += 1;
            } else {
                int[] vector = Problem2.DesparteNumarul(i);
                if (RisenOrFallen.esteIncreasingNumber(vector) == true) {
                    count += 1;
                } else if (RisenOrFallen.esteDecreasingNumber(vector) == true) {
                    count += 1;
                }
            }
        }
        System.out.println("Rezultatul este: " + count);
        return count;
    }

    public static int aflareLungimeFixa(int n) {
        int lungime = 0;
        int nr2 = n;
        while (nr2 != 0) {
            nr2 = nr2 / 10;
            lungime++;
        }
        return lungime;
    }

    public static int[] desparteNumarul(int n) {
        int[] vector = new int[RisenOrFallen.aflareLungimeFixa(n)];
        for (int i = 0; i < vector.length; i++) {
            vector[vector.length - i - 1] = n % 10;
            n = n / 10;
        }
        return vector;
    }

    public static boolean esteIncreasingNumber(int[] vector) {
        boolean[] vectorBoolean = new boolean[vector.length];
        boolean bol = true;
        for (int i = 0; i < vector.length; i++) {
            int minim = vector[i];
            if (i != vector.length - 1) {
                int j = i + 1;
                if (minim <= vector[j]) {
                    vectorBoolean[i] = true;
                } else if (minim > vector[j]) {
                    vectorBoolean[i] = false;
                }
            } else {
                vectorBoolean[i] = true;
            }
        }
        //System.out.println(Arrays.toString(vectorBoolean));
        for (int k = 0; k < vectorBoolean.length; k++) {
            if (vectorBoolean[k] == false) {
                bol = false;
            }
        }
        return bol;
    }

    public static boolean esteDecreasingNumber(int[] vector) {
        boolean[] vectorBoolean = new boolean[vector.length];
        boolean bol = true;
        for (int i = 0; i < vector.length; i++) {
            int maxim = vector[i];
            if (i != vector.length - 1) {
                int j = i + 1;
                if (maxim >= vector[j]) {
                    vectorBoolean[i] = true;
                } else if (maxim < vector[j]) {
                    vectorBoolean[i] = false;
                }
            } else {
                vectorBoolean[i] = true;
            }
        }
        //System.out.println(Arrays.toString(vectorBoolean));
        for (int k = 0; k < vectorBoolean.length; k++) {
            if (vectorBoolean[k] == false) {
                bol = false;
            }
        }
        return bol;
    }
}
