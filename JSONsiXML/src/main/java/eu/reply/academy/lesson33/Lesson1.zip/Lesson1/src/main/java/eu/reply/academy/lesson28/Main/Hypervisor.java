package eu.reply.academy.lesson28.Main;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Vector;

import static eu.reply.academy.lesson28.Main.RunMe.PATH;

public class Hypervisor {
    protected static List<VirtualMachine> listVMachineCreated = new ArrayList<>();
    protected static List<Processor> listProcessors = new ArrayList<>();
    private static final String NAME = "Nume";
    private static final String TYPE = "Tip";
    private static final String CPU_NUMBER = "NumarCPU";
    private static final String APPLICATION_LIST = "ListaAplicatii";
    private static final String APP01 = "App01";
    private static final String APP02 = "App02";
    private static int COUNTER_NAME = 1;
    private static String APP_NAME;


    protected static VirtualMachine createVMachine(String path, String name, int priority) {
        VirtualMachine virtualMachine = new VirtualMachine();
        String linie;
        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(path + "\\" + name))) {
            while ((linie = bufferedReader.readLine()) != null) {
                if (NAME.equals(Utilitar.getKey(linie))) {
                    virtualMachine.setOsName(Utilitar.getValue(linie));
                } else if (TYPE.equals(Utilitar.getKey(linie))) {
                    virtualMachine.setType(Utilitar.getValue(linie));
                } else if (CPU_NUMBER.equals(Utilitar.getKey(linie))) {
                    virtualMachine.setCpuNumber(Utilitar.getValue(linie));
                } else if (APP01.equals(Utilitar.getKey(linie))) {
                    virtualMachine.setListAplications(Utilitar.getValue(linie));
                } else if (APP02.equals(Utilitar.getKey(linie))) {
                    virtualMachine.setListAplications(Utilitar.getValue(linie));
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        virtualMachine.setPriorityNumber(priority);
        Hypervisor.listVMachineCreated.add(virtualMachine);
        return Hypervisor.validationObject(virtualMachine);
    }

    private static VirtualMachine validationObject(VirtualMachine virtualMachine) {
        if (virtualMachine.getOsName() == null && virtualMachine.getType() == null
                && virtualMachine.getCpuNumber() == 0 && virtualMachine.getListAplications() == null) {
            System.out.println("Masina virtuala nu s-a creat.");
            return null;
        } else {
            System.out.println("Masina virtuala s-a creat cu succes.");
            return virtualMachine;
        }
    }

    protected static void printVMachinesCreated() {
        for (VirtualMachine virtualMachine : Hypervisor.listVMachineCreated) {
            System.out.println(virtualMachine);
        }
    }

    protected static void addProcessors(Processor... processor) {
        List<Processor> list = Arrays.asList(processor);
        Hypervisor.listProcessors.addAll(list);
    }

    protected static void addProcessor(Processor processor) {
        Hypervisor.listProcessors.add(processor);
    }

    protected static void printProcessors() {
        for (Processor processor : Hypervisor.listProcessors) {
            System.out.println(processor);
        }
    }

    protected static void addApplications(VirtualMachine virtualMachine, String... vector) {
        virtualMachine.addListApplications(vector);
    }

    protected static void addApplication(VirtualMachine virtualMachine, String name) {
        virtualMachine.addListApplication(name);
    }

    protected static void dischargeVMachine(VirtualMachine virtualMachine, String nameFile) {
        try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(PATH + "\\" + nameFile))) {
            List<String> aplications = virtualMachine.getListAplications();
            for (String element : aplications) {
                APP_NAME = Hypervisor.createName();
                bufferedWriter.write(APP_NAME + element);
                bufferedWriter.write("\n");
            }
            Hypervisor.clear();
            Hypervisor.listVMachineCreated.remove(virtualMachine);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    protected static VirtualMachine createVMachineBasedOnAnotherMachine(VirtualMachine virtualMachine, int priority) {
        VirtualMachine virtualMachine1 = new VirtualMachine(virtualMachine.getOsName(), virtualMachine.getCpuNumber(),
                virtualMachine.getListAplications(), virtualMachine.getType());
        virtualMachine1.setPriorityNumber(priority);
        Hypervisor.listVMachineCreated.add(virtualMachine);
        Hypervisor.validationObject(virtualMachine1);
        return virtualMachine1;
    }

    private static String createName() {
        if (COUNTER_NAME < 10) {
            APP_NAME = "App00" + COUNTER_NAME + "=";
        } else if (COUNTER_NAME < 100) {
            APP_NAME = "App0" + COUNTER_NAME + "=";
        } else {
            APP_NAME = "App" + COUNTER_NAME + "=";
        }
        COUNTER_NAME++;
        return APP_NAME;
    }

    private static void clear() {
        COUNTER_NAME = 1;
    }

    protected static void load(VirtualMachine virtualMachine, Core core) {
        boolean isOccupied = Hypervisor.coreIsOccupied(core);
        boolean isContained = Hypervisor.coreIsContainedByAProcessor(core);
        if (isContained && !isOccupied) {
            virtualMachine.setListCore(core);
            System.out.println("Core-ul a fost mapat cu succes.");
        }
    }

    private static boolean coreIsOccupied(Core core) {
        boolean isOccupied = false;
        for (VirtualMachine virtualMachine : Hypervisor.listVMachineCreated) {
            for (Core core1 : virtualMachine.listCore) {
                if (core1.equals(core) && !isOccupied) {
                    isOccupied = true;
                    System.out.println("Core-ul este ocupat.");
                }
            }
        }
        return isOccupied;
    }

    private static boolean coreIsContainedByAProcessor(Core core) {
        boolean isContained = false;
        for (Processor processor : Hypervisor.listProcessors) {
            if (processor.listCore.contains(core) && !isContained) {
                isContained = true;
            }
        }
        if (!isContained) {
            System.out.println("Nici un procesor nu contine acest core.");
        }
        return isContained;
    }
}
