package eu.reply.academy.lesson3;

import java.io.*;
import java.util.Scanner;

public class CitireFisierTxt {
    int[][] matrice;
    int nrLinii;
    int nrColoane;
    //Cititi o matrie dintr-un fisier txt. Pe prima linie sunt nr de liniii si coloane apoi matricea.
    public static void main(String[] args) {
        File file = new File("C:\\Users\\Angela Stanciu\\IdeaProjects\\Lesson1\\src\\main\\java\\eu\\reply\\academy\\lesson3\\fisierTxt123");
        CitireFisierTxt prog = new CitireFisierTxt();
        prog.incarcaMatrice(file);

        prog.printMatrice();
        int sumaDiagPrinc=prog.calculateDiagonalaPrincipala();
        int sumaDiagonalaSecundara=prog.sumaDiagSec();
        int sumaTotala=sumaDiagPrinc + sumaDiagonalaSecundara;
        System.out.println("Suma totala este:" + sumaTotala);
        prog.scriereFisier(sumaTotala, sumaDiagPrinc, sumaDiagonalaSecundara);
    }

    public void incarcaMatrice(File file) {
        Scanner sc = null;

        try {
            sc = new Scanner(file);
            String[] linie = sc.nextLine().trim().split(" ");
            nrLinii = Integer.parseInt(linie[0]);
            nrColoane = Integer.parseInt(linie[1]);
            matrice = new int[nrLinii][nrColoane];
            while (sc.hasNextLine()) {
                for (int i = 0; i < nrLinii; i++) {
                    String[] vector = sc.nextLine().trim().split(" ");
                    for (int j = 0; j < nrColoane; j++) {
                        matrice[i][j] = Integer.parseInt(vector[j]);
                    }
                }
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        /*while (sc.hasNextLine())
        {
            //System.out.println(sc.nextLine());
        }*/
    }

    private void scriereFisier(int sumaTotala, int sumaPrinc, int sumaSec)  {
        try (FileWriter myWriter = new FileWriter("ScriereFisier.txt");
             BufferedWriter printwrite = new BufferedWriter(myWriter);) {

            printwrite.write(sumaPrinc + "\n");
            printwrite.write(sumaSec + "\n");
            printwrite.write(sumaTotala + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private int sumaDiagSec() {
        int sumaSec=0;
        for(int i = 0; i< nrLinii; i++)
        {
            if(matrice[i][matrice.length-1-i]%2==0) {
                sumaSec += matrice[i][matrice.length - 1 - i];
           }
       }
        System.out.println("Suma de pe diagonala secundara:" + sumaSec);
        return  sumaSec;
    }

    private int calculateDiagonalaPrincipala() {
        int sumaPrinc=0;
        for(int i = 0; i< nrLinii; i++)
        {
            for(int j = 0; j< nrColoane; j++)
            {
                if((i==j) && (matrice[i][j]%2==0))
                {
                    sumaPrinc+= matrice[i][j];
                }
            }
       }
        System.out.println("Suma de pe diagonala principala:" + sumaPrinc);
        return  sumaPrinc;
    }

    public void printMatrice() {
        System.out.println("===========================PrintMatrice===================");
        for (int i = 0; i < matrice.length; i++) {
            int[] linie = matrice[i];
            for (int j = 0; j < linie.length; j++) {
                System.out.print(linie[j] + " ");
            }
            System.out.println("");
        }
    }

   /* public int AdunareDiagPrincipala(int[][] matrice, int nrLinii, int nrColoane)
    {
        int suma=0;
        for(int i=0;i<nrLinii; i++)
        {
            for(int j=0; j<nrColoane; j++)
            {
                if(i==j)
                {
                    suma+=matrice[i][j];
                }
            }
        }
        return suma;
    }*/

}
