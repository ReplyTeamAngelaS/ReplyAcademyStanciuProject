package eu.reply.academy.lesson16;

public class EmailValidation {

    public static void main(String[] args) {
        String cuvant1 = "@gmail.com";
        String cuvant2 = "hello.gmail@com";
        String cuvant3 = "gmail";
        String cuvant4 = "hello@gmail";
        String cuvant5 = "hello@edabit.com";
        System.out.println(EmailValidation.validateEmail(cuvant1));
        System.out.println(EmailValidation.validateEmail(cuvant2));
        System.out.println(EmailValidation.validateEmail(cuvant3));
        System.out.println(EmailValidation.validateEmail(cuvant4));
        System.out.println(EmailValidation.validateEmail(cuvant5));
    }

    public static boolean validateEmail(String str) {
        int bol1 = EmailValidation.contineUnSingurCaracter('@', str);
        int bol2 = EmailValidation.contineUnSingurCaracter('.', str);
        if (bol1 == 1 && bol2 > 0) {
            if (str.indexOf("@") < str.indexOf('.', str.indexOf('@'))) {
                if ((str.substring(0, str.indexOf("@")).length() > 0)
                        && (str.substring(str.indexOf("@"), str.indexOf('.', str.indexOf('@'))).length() > 0)
                        && (str.substring(str.indexOf('.', str.indexOf('@'))).length() > 1)) {
                    return true;
                }
            }
        }
        return false;
    }

    public static int contineUnSingurCaracter(char ch, String cuvant) {
        int count = 0;
        for (int i = 0; i < cuvant.length(); i++) {
            if (cuvant.charAt(i) == ch) {
                count++;
            }
        }
        if (count == 1) {
            return 1;
        } else if (count == 0) {
            return 0;
        } else {
            return 2;
        }
    }
}
