package eu.reply.academy.classes.parent;

import eu.reply.academy.classes.grandparent.GrandParent;

public class Parent extends GrandParent {

    private String privateAge = "Private Age Parent";
    String defaultAge = "Default Age Parent";
    protected String protectedAge = "Protected Age Parent";
    public String publicAge = "Public Age Parent";

    private String getPrivateAge() {
        return this.privateAge;
    }

    String getDefaultAge() {
        return this.defaultAge;
    }

    public String getPublicAge() {
        return this.getProtectedAge();
    }

    protected String getProtectedAge(int age) {
        return protectedAge + " " + age;
    }

    public String getProtectedAge(int age1, int age2) {
        return protectedAge + " " + age1 + " " + age2;
    }

}
