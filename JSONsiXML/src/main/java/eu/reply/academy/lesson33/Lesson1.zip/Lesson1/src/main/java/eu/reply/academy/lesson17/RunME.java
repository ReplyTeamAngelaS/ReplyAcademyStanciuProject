package eu.reply.academy.lesson17;

public class RunME {

    public static void main(String[] args) {

        Punct a = new Punct(1, 1);
        Punct b = new Punct(3, 1);
        Punct c = new Punct(1, 3);
        Punct d = new Punct(3, 3);
        Patrulater patru = new Patrulater(a, b, c, d);
        System.out.println(patru);
        int lungime1 = 4;
        int latime1 = 2;
        Punct origine1 = new Punct(2, 1);
        Dreptunghi drept1 = new Dreptunghi(origine1, lungime1, latime1);
        System.out.println(drept1.toString());
        int perimetru1 = drept1.calculeazaPerimetrul();
        System.out.println("Perimetrul dreptunghiului este: " + perimetru1);
        int lungime2 = 4;
        int latime2 = 2;
        Punct origine2 = new Punct(4, 2);
        Dreptunghi drept2 = new Dreptunghi(origine2, lungime2, latime2);
        System.out.println(drept2.toString());
        int perimetru2 = drept2.calculeazaPerimetrul();
        System.out.println("Perimetrul dreptunghiului este: " + perimetru2);
        Punct origine3 = new Punct(4, 3);
        int latura = 4;
        Patrat patr = new Patrat(origine3, latura);
        System.out.println(patr.toString());
        int perimetru3 = patr.calculeazaPerimetrul();
        System.out.println("Perimetrul patratului este: " + perimetru3);
    }
}
