package eu.reply.academy.lesson25;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Procesor {

    public UnitateSpecializataDeCalcul unitate = new UnitateSpecializataDeCalcul();
    public List<Registru> listaRegistrii = new ArrayList<>();
    private final static int INDEX_OF_REGISTER_NAME   = 3;
    private final static int INDEX_OF_REGISTER_VALUE  = 2;
    private final static int INDEX_OF_REGISTER_METHOD = 1;

    public void citireDinFisier(String cale, String denumire) {
        try {
            String caleAbsoluta = cale + "\\" + denumire;
            FileReader fileReader = new FileReader(caleAbsoluta);
            Scanner scan = new Scanner(fileReader);
            scan.useDelimiter(",");
            while (scan.hasNext()) {
                String[] valori = scan.next().split(" ");
                if (Procesor.getDenumireMetoda(valori).equals("put")) {
                    listaRegistrii.add(unitate.put(valori));
                } else if (Procesor.getDenumireMetoda(valori).equals("add")) {
                    metodaAdd(valori);
                } else if (Procesor.getDenumireMetoda(valori).equals("mul")) {
                    metodaMul(valori);
                } else if (Procesor.getDenumireMetoda(valori).equals("div")) {
                    metodaDiv(valori);
                } else if (Procesor.getDenumireMetoda(valori).equals("mov")) {
                    metodaMov(valori);
                } else if (Procesor.getDenumireMetoda(valori).equals("sub")) {
                    metodaSub(valori);
                }
            }
            Procesor.afisareLista(this.listaRegistrii);
            scan.close();
        } catch (FileNotFoundException e) {

        }

    }

    private void metodaSub(String[] valori) {
        boolean esteRegistrulInitializat = Exceptii.tratareRegistriiNeinitializati(this.listaRegistrii, Procesor.getDenumireRegistru(valori));
        if (esteRegistrulInitializat) {
            for (Registru reg : listaRegistrii) {
                if (reg.denumire.equals(Procesor.getDenumireRegistru(valori)))
                    unitate.sub(reg, Procesor.getValoareRegistru(valori));
            }
        }
    }

    private void metodaMov(String[] valori) {
        boolean esteRegistrulInitializat = Exceptii.tratareRegistriiNeinitializati(this.listaRegistrii, Procesor.getDenumireRegistru(valori));
        if (esteRegistrulInitializat) {
            for (Registru reg : listaRegistrii) {
                if (reg.denumire.equals(Procesor.getDenumireRegistru(valori)))
                    unitate.mov(reg, Procesor.getValoareRegistru(valori));
            }
        }
    }

    private void metodaDiv(String[] valori) {
        boolean esteRegistrulInitializat = Exceptii.tratareRegistriiNeinitializati(this.listaRegistrii, Procesor.getDenumireRegistru(valori));
        if (esteRegistrulInitializat) {
            for (Registru reg : listaRegistrii) {
                if (reg.denumire.equals(Procesor.getDenumireRegistru(valori)))
                    unitate.div(reg, Procesor.getValoareRegistru(valori));
            }
        }
    }

    private void metodaMul(String[] valori) {
        boolean esteRegistrulInitializat = Exceptii.tratareRegistriiNeinitializati(this.listaRegistrii, Procesor.getDenumireRegistru(valori));
        if (esteRegistrulInitializat) {
            for (Registru reg : listaRegistrii) {
                if (reg.denumire.equals(Procesor.getDenumireRegistru(valori)))
                    unitate.mul(reg, Procesor.getValoareRegistru(valori));
            }
        }
    }

    private void metodaAdd(String[] valori) {
        boolean esteRegistrulInitializat = Exceptii.tratareRegistriiNeinitializati(this.listaRegistrii, Procesor.getDenumireRegistru(valori));
        if (esteRegistrulInitializat) {
            for (Registru reg : listaRegistrii) {
                if (reg.denumire.equals(Procesor.getDenumireRegistru(valori)))
                    unitate.add(reg, Procesor.getValoareRegistru(valori));
            }
        }
    }

    public static void afisareLista(List<Registru> lista) {
        System.out.println("Registrii sunt urmatorii: " + "\n");
        for (Registru reg : lista) {
            System.out.println(reg.toString());
        }
    }

    public static String getDenumireRegistru(String[] valori) {
        final String denumire = valori[INDEX_OF_REGISTER_NAME];
        return denumire;
    }

    public static int getValoareRegistru(String[] valori) {
        int valoare = Integer.parseInt(valori[INDEX_OF_REGISTER_VALUE]);
        return valoare;
    }

    public static String getDenumireMetoda(String[] valori) {
        String denumire = valori[INDEX_OF_REGISTER_METHOD];
        return denumire;
    }

}
