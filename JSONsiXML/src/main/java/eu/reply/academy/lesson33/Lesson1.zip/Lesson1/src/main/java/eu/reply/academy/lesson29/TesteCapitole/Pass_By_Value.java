package eu.reply.academy.lesson29.TesteCapitole;

public class Pass_By_Value {


    public static void main(String[] args) {

        byte a = (byte) 100;
        short b = (short) 1000;
        int c = 100000;
        long d = 3000000000L;
        float e = 30.20f;
        double f = 64.20;
        boolean g = true;
        char h = 'a';
        passByValue(a, b, c, d, e, f, g, h);
        System.out.println(a + " " + b + " " + c + " " + d + " " + e + " " + f + " " + g + " " + h + " ");
        c = returnByValue(c);
        System.out.println(c);
    }

    public static void passByValue(byte a, short b, int c, long d, float e, double f, boolean g, char h) {
        a = 101;
        b = 1001;
        c = 100001;
        d = 3000000001L;
        e = 40.20f;
        f = 77.20;
        g = false;
        h = 'A';
    }

    public static int returnByValue(int c) {
        return c = 100001;
    }

}
