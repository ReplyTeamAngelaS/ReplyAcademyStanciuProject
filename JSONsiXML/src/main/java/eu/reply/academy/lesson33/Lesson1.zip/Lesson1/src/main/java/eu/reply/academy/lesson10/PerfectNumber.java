package eu.reply.academy.lesson10;

public class PerfectNumber {

    public static void main(String[] args) {
        int i = 1;
        int sum = 0;
        boolean rezultat = PerfectNumber.calculeazaPerfectNumberRecursiv(97, i, sum);
        System.out.println(rezultat);
    }

    public static boolean calculeazaPerfectNumber(int number) {
        int sum = 0;
        for (int i = 1; i <= number / 2; i++) {
            if (number % i == 0) {
                sum += i;
            }
        }
        if (sum == number) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean calculeazaPerfectNumberRecursiv(int number, int i, int sum) {
        if (i <= number / 2) {
            if (number % i == 0) {
                sum += i;
            }
            return calculeazaPerfectNumberRecursiv(number, i + 1, sum);
        }
        if (sum == number) {
            return true;
        } else {
            return false;
        }
    }
}
