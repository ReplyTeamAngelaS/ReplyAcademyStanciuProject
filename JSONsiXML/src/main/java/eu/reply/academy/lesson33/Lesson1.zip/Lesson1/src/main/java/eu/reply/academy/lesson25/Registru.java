package eu.reply.academy.lesson25;

public class Registru {

    public String denumire;
    public int valoare;

    public Registru(String[] valori) {
        this.denumire = Procesor.getDenumireMetoda(valori);
        this.valoare = Procesor.getValoareRegistru(valori);
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Registrul " + this.denumire + " are valoarea " + this.valoare);
        return stringBuilder.toString();
    }


}
