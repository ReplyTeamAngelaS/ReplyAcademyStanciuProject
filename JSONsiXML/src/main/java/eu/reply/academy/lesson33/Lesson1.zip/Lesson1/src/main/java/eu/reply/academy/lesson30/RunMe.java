package eu.reply.academy.lesson30;

import java.util.Arrays;

public class RunMe {

    public static void main(String[] args) {

        Functii obiect = new Functii();
        obiect.citesteVector(10);
        System.out.println(Arrays.toString(obiect.vector));
        obiect.stergeNNumere(3);
        System.out.println(Arrays.toString(obiect.vector));
    }
}
