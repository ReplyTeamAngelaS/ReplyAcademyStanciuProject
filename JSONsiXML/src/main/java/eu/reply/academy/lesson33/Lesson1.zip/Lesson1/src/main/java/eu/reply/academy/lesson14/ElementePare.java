package eu.reply.academy.lesson14;

import java.util.Arrays;
import java.util.Scanner;

public class ElementePare {

    public static void main(String[] args) {
        int n = ElementePare.daNumarN();
        int[] vector = ElementePare.citireSir(n);
        ElementePare.afiseazaRezultatul2(vector);
    }

    public static int daNumarN() {
        Scanner scan = new Scanner(System.in);
        System.out.print("Numarul natural reprezentand dimensiunea sirului este: ");
        int n = scan.nextInt();
        if (!((n >= 1) && (n <= 100))) {
            System.out.println("Numarul trebuie sa fie in intervalul 1 si 100.");
            return daNumarN();
        }
        return n;
    }

    public static int daNumarSir() {
        Scanner scan = new Scanner(System.in);
        System.out.print("Scrie un numar natural: ");
        int n = scan.nextInt();
        if (!(n <= 10000)) {
            System.out.println("Numarul trebuie sa fie mai mic decat 10.000");
            return daNumarSir();
        }
        return n;
    }

    public static int[] citireSir(int n) {
        int[] vector = new int[n];
        for (int i = 0; i < vector.length; i++) {
            vector[i] = ValoareaAbsoluta.daNumarSir();
        }
        System.out.println("-----------------------------------------------");
        System.out.println("Numerele din sir sunt: " + Arrays.toString(vector));
        return vector;
    }

    public static void afiseazaRezultatul(int[] vector) {
        System.out.println("Rezultatul este: ");
        int countPar = vector.length;
        int countVector = 0;
        for (int i = 0; i < vector.length; i++) {
            if (vector[i] % 2 == 0) {
                countVector++;
            }
        }
        if (countPar == countVector) {
            System.out.println("DA");
        } else {
            System.out.println("NU");
        }
    }

    public static void afiseazaRezultatul2(int[] vector) {
        System.out.println("Rezultatul este: ");
        boolean bol = true;
        for (int i = 0; i < vector.length && bol; i++) {
            if (vector[i] % 2 != 0) {
                bol = false;
            }
        }
        if (bol) {
            System.out.println("DA");
        } else {
            System.out.println("NU");
        }
    }
}
