package eu.reply.academy.ACADEMIA_JAVA.sss;

public class A extends B{


    public A(String a) {
        super(a);
    }

    public static void main(String[] args) {

    }
}
