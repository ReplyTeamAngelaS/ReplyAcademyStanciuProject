package eu.reply.academy.lesson20;

import java.util.ArrayList;

public abstract class Surgeon extends Doctor {

    public ArrayList<Operatie> listaOperatii=new ArrayList<Operatie>();

    public void addOperatie(Operatie operatie){
        listaOperatii.add(operatie);
    }

    public void removeOperatie(Operatie operatie){
        listaOperatii.remove(operatie);
    }

    public abstract void operatie(Operatie operatie);

    public abstract void tipChirurg();
}
