package eu.reply.academy.lesson4;

import java.lang.reflect.Array;
import java.util.Arrays;

public class Tema3 {

    public static void main(String[] args) {
        //O metoda care primeste ca parametri : un vector cu numere intregi, si inca doi parametri numere intregi
        // si care va intoarce inapoi un vector astfel:
        //Vectorul intors va contine numerele din vecotrul primit ca parametru si va inlocui numarul primit
        // ca al doilea parametru cu numarul primit ca al treilea parametru:
        //Ex : vector = {2,4,5,10,5,12} n=5 m=9 , rezultatul va fi rezultat = {2,4,9,10,9,12}
        int[] vector = new int[]{2, 4, 5, 10, 5, 12};
        int x = 5;
        int y = 9;
        int[] vectorRezultat = Tema3.calculeaza(vector, x, y);
    }

    public static int[] calculeaza(int[] vector, int x, int y) {
        int[] vectorRezultat = null;
        try {
            vectorRezultat = new int[vector.length];
            /*for (int i = 0; i < vector.length; i++) {
                if (x == vector[i]) {
                    vectorRezultat[i] = y;
                } else {
                    vectorRezultat[i] = vector[i];
                }
            }*/
            int i = 0;
            while (i < vector.length) {
                if (x == vector[i]) {
                    vectorRezultat[i] = y;
                } else {
                    vectorRezultat[i] = vector[i];
                }
                i++;
            }
            System.out.println("Vectorul dat este: " + Arrays.toString(vector));
            System.out.println("Numarul " + x + " " + "va fi inlocuit cu " + y);
            System.out.println("Vectourl rezultat va arata in felul urmator: " + Arrays.toString(vectorRezultat));
        } catch (NullPointerException e) {
            System.out.println("NullPointerException");
            vectorRezultat = new int[]{0};
            System.out.println(Arrays.toString(vectorRezultat));
        }
        return vectorRezultat;
    }
}
