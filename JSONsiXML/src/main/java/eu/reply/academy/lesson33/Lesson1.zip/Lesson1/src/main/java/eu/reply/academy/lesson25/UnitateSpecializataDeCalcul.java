package eu.reply.academy.lesson25;

public class UnitateSpecializataDeCalcul {


    public Registru put(String[] valori) {
        Registru registru = new Registru(valori);
        return registru;
    }

    public void add(Registru registru, int valoare) {
        registru.valoare += valoare;
    }

    public void mul(Registru registru, int valoare) {

        registru.valoare *= valoare;
    }

    public void div(Registru registru, int valoare) {
        registru.valoare /= valoare;
    }

    public void mov(Registru registru, int valoare) {
        registru.valoare += valoare;
    }

    public void sub(Registru registru, int valoare) {
        registru.valoare -= valoare;
    }
}
