package eu.reply.academy.lesson14;

import java.util.Arrays;
import java.util.Scanner;

public class ValoareaAbsoluta {

    public static void main(String[] args) {
        int n = ValoareaAbsoluta.daNumarN();
        int[] vector = ValoareaAbsoluta.citireSir(n);
        ValoareaAbsoluta.calculeazaValoareaAbsoluta(vector);
    }

    public static int daNumarN() {
        Scanner scan = new Scanner(System.in);
        System.out.print("Numarul natural reprezentand dimensiunea sirului este: ");
        int n = scan.nextInt();
        if (!((n >= 1) && (n <= 1000))) {
            System.out.println("Numarul trebuie sa fie in intervalul 1 si 1000.");
            return daNumarN();
        }
        return n;
    }

    public static int daNumarSir() {
        Scanner scan = new Scanner(System.in);
        System.out.print("Scrie un numar natural: ");
        int n = scan.nextInt();
        if (!(n <= 1000000000)) {
            System.out.println("Numarul trebuie sa fie mai mic decat 1.000.000.000");
            return daNumarSir();
        }
        return n;
    }

    public static int[] citireSir(int n) {
        int[] vector = new int[n];
        for (int i = 0; i < vector.length; i++) {
            vector[i] = ValoareaAbsoluta.daNumarSir();
        }
        System.out.println("-----------------------------------------------");
        System.out.println("Numerele din sir sunt: " + Arrays.toString(vector));
        return vector;
    }

    public static void calculeazaValoareaAbsoluta(int[] vector) {
        int countPar = 0;
        int countImpar = 0;
        for (int i = 0; i < vector.length; i++) {
            if (vector[i] % 2 == 0) {
                countPar++;
            } else {
                countImpar++;
            }
        }
        int diferenta = Math.abs(countPar - countImpar);
        System.out.println("Valoarea absoluta este: " + diferenta);
    }

}
