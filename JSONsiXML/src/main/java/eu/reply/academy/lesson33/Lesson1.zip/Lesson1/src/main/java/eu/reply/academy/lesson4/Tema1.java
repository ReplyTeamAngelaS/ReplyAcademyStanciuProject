package eu.reply.academy.lesson4;

public class Tema1 {
//O metoda care verifica daca doi vectori de String sunt egali . Metoda o sa intoarca true sau false

    public static void main(String[] args) {
        String[] string1 = new String[]{"1", "2", "3"};
        String[] string2 = new String[]{"1", "2", "3"};
        boolean result = Tema1.comparaString(string1, string2);
        System.out.println(result);
    }

    public static boolean comparaString(String[] string1, String[] string2) {
        boolean result = false;
        try {
            if (string1.length == string2.length) {
                System.out.println("Lungimea e egala.");
                int i = 0;
                int contor = 0;
                while (i < string1.length) {
                    if (string1[i] == string2[i]) {
                        contor += 0;
                    } else {
                        contor += 1;
                    }
                    i++;
                }
            /*for (int j = 0; j < string1.length; j++) {
                if (string1[j] == string2[j]) {
                    contor += 0;
                } else {
                    contor += 1;
                }
            }*/
                if (contor == 0) {
                    System.out.println("Au aceleasi elemente.");
                    result = true;
                } else {
                    System.out.println("Nu au aceleasi elemente.");
                    result = false;
                }
            } else {
                System.out.println("Lungimea nu e egala. Nu au aceleasi elemente.");
                result = false;
            }
        } catch (NullPointerException e) {
            System.out.println("NullPointerException");
        }
        return result;
    }

}
