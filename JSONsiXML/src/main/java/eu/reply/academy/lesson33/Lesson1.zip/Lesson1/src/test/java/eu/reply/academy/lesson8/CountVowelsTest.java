package eu.reply.academy.lesson8;

import junit.framework.TestCase;
import org.junit.Assert;
import org.junit.Test;

public class CountVowelsTest extends TestCase {

    @Test
    public void test01(){Assert.assertEquals(2,CountVowels.calculeazaVocaleRecursiv("apple"));}

    @Test
    public void test02(){Assert.assertEquals(5,CountVowels.calculeazaVocaleRecursiv("cheesecake"));}

    @Test
    public void test03(){Assert.assertEquals(3,CountVowels.calculeazaVocaleRecursiv("martini"));}

    @Test
    public void test04(){Assert.assertEquals(0,CountVowels.calculeazaVocaleRecursiv("rhythm"));}

    @Test
    public void test05(){Assert.assertEquals(0,CountVowels.calculeazaVocaleRecursiv(""));}

    @Test
    public void test06(){Assert.assertEquals(0,CountVowels.calculeazaVocaleRecursiv("b"));}

    @Test
    public void test07(){Assert.assertEquals(1,CountVowels.calculeazaVocaleRecursiv("a"));}

    @Test
    public void test08(){Assert.assertEquals(0,CountVowels.calculeazaVocaleRecursiv("bbbbbb"));}

    @Test
    public void test09(){Assert.assertEquals(1,CountVowels.calculeazaVocaleRecursiv("bbbbba"));}

    @Test
    public void test10(){Assert.assertEquals(1,CountVowels.calculeazaVocaleRecursiv("abbbb"));}

    @Test
    public void test11(){Assert.assertEquals(1,CountVowels.calculeazaVocaleRecursiv("bbbab"));}

    @Test
    public void test12(){Assert.assertEquals(2,CountVowels.calculeazaVocaleRecursiv("bbaab"));}

    @Test
    public void test13(){Assert.assertEquals(3,CountVowels.calculeazaVocaleRecursiv("baabab"));}


}