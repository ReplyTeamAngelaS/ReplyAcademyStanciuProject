package eu.reply.academy.lesson28.Main;

public class Utilitar {

    private static final String UNKNOWN = "Unknown";

    public static String getKey(String linie) {
        String rezultat = Utilitar.UNKNOWN;
        if (linie == null) {
            return rezultat;
        } else {
            int poz = linie.indexOf("=");
            if (poz > -1) {
                rezultat = linie.substring(0, poz);
            }
            return rezultat;
        }
    }

    public static String getValue(String linie) {
        String rezultat = Utilitar.UNKNOWN;
        if (linie == null) {
            return rezultat;
        } else {
            int poz = linie.indexOf("=");
            if (poz > -1) {
                rezultat = linie.substring(poz + 1);
            }
            return rezultat;
        }
    }
}
