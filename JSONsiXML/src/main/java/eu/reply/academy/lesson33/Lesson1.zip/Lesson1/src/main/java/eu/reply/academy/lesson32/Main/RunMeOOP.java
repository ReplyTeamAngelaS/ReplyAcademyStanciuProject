/*
package eu.reply.academy.lesson32.Main;

import eu.reply.academy.lesson32.Model.FactoryMenuJSON;
import eu.reply.academy.lesson32.Model.FactoryMenuXML;
import eu.reply.academy.lesson32.Model.Menu;
import eu.reply.academy.lesson32.Model.MenuItem;

import java.util.List;

import static eu.reply.academy.lesson32.Model.FactoryMenu.*;


public class RunMeOOP {

    public static final String NAME_FILE = "menu";

    public static void main(String[] args) {
        //CREARE OBIECTE
        Menu menuItem = new Menu(new FactoryMenuXML(PATH, NAME_FILE));

//        MehodFactory.createMenu( PATH, NAME_FILE, "JSON");
//
//        Menu menuItem=null;
//        if( type.equls("JSON")) {
//            menuItem = new Menu(new FactoryMenuJSON(PATH, NAME_FILE));
//        }
//        if( type.equls("XML")) {
//           menuItem = new Menu(new FactoryMenuXML(PATH, NAME_FILE));
//        }
//        return menuItem;
        }
}
*/
