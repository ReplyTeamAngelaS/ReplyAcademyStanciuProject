package eu.reply.academy.lesson18;

public class RunMe {

    public static void main(String[] args) {
        Chirurg ch = new Chirurg();
        ch.areOperatie();
    }
}
