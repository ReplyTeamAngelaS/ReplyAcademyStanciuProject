package eu.reply.academy.lesson20;

public abstract class Doctor {


}
