package eu.reply.academy.lesson5;

import java.util.Arrays;

public class Challenge {

    public static void main(String[] args) {
        int[] vector = new int[] {12, 90, 75};
        int rezultat = Challenge.warOfNumbers(vector);
    }

    public static int warOfNumbers(int[] vector) {
        int sumaTotala=0;
        try {
            int[] vectorPar = new int[vector.length];
            int[] vectorImpar = new int[vector.length];
            int c1 = 0;
            int c2 = 0;
            int suma1 = 0;
            int suma2 = 0;
            int i = 0;
            while (i < vector.length) {
                if (vector[i] % 2 == 0) {
                    vectorPar[c1] = vector[i];
                    c1++;
                    suma1 += vector[i];
                } else {
                    vectorImpar[c2] = vector[i];
                    c2++;
                    suma2 += vector[i];
                }
                i++;
            }
            System.out.println("Vectorul cu elementele pare este:" + Arrays.toString(vectorPar));
            System.out.println("Suma elementelor pare este:" + suma1);
            System.out.println("Vectorul cu elementele impare este:" + Arrays.toString(vectorImpar));
            System.out.println("Suma elementelor impare este:" + suma2);
            if (suma1 > suma2) {
                sumaTotala = suma1 - suma2;
                System.out.println("Suma elementelor pare este mai mare.");
                System.out.println("Diferenta sumelor este:" + sumaTotala);
            } else if (suma2 > suma1) {
                sumaTotala = suma2 - suma1;
                System.out.println("Suma elementelor impare este mai mare.");
                System.out.println("Diferenta sumelor este:" + sumaTotala);
            } else {
                System.out.println("Cele doua sume sunt egale");
                System.out.println("In cazul asta suma este:" + sumaTotala);
            }
        } catch (NullPointerException e) {
            System.out.println("Vectorul este null.");
        }
        return sumaTotala;
    }
}
