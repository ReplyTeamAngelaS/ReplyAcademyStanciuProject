package eu.reply.academy.lesson23.beans;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Orase {

    public static List<Oras> listaOrase = new ArrayList<>();
    public final static String SEPARATOR = ",";

    public static void load(String calea, String numeFisier) {
        try {
            String caleaAbsoluta = calea + "\\" + numeFisier;
            FileReader file = new FileReader(caleaAbsoluta);
            BufferedReader br = new BufferedReader(file);
            String linie;
            String numeColoane = br.readLine();
            while ((linie = br.readLine()) != null) {
                String[] valori = linie.split(SEPARATOR);
                Oras oras = new Oras(valori);
                listaOrase.add(oras);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static ArrayList<Oras> gasesteOrasulCuPopulatiaMare() {
        long maxim = 0;
        ArrayList<Oras> lista = new ArrayList<>();
        for (Oras oras : listaOrase) {
            if (maxim < oras.populatie) {
                maxim = oras.populatie;
            }
        }
        for (Oras oras : listaOrase) {
            if (maxim == oras.populatie)
                lista.add(oras);
        }
        return lista;
    }

    public static ArrayList<Oras> creeazaListaOrasePopulatieZero() {
        ArrayList<Oras> listaOrase0 = new ArrayList<>();
        for (Oras oras : listaOrase) {
            if (oras.populatie == 0) {
                listaOrase0.add(oras);
            }
        }
        return listaOrase0;
    }

    public static long calculeazaMediaPopulatiei() {
        long suma = 0;
        long nrElemente = listaOrase.size();
        for (Oras oras : listaOrase) {
            suma += oras.populatie;
        }
        long medie = suma / nrElemente;
        return medie;
    }

    public static void citesteLista(ArrayList<Oras> lista) {
        for (Oras oras : lista) {
            System.out.print(oras.toString());
        }
    }

    public static ArrayList<Oras> selectionSortDupaPopulatie() {
        ArrayList<Oras> lista = new ArrayList<>(listaOrase);
        for (int i = 0; i < lista.size() - 1; i++) {
            long minim = lista.get(i).populatie;
            int index = i;
            for (int j = i + 1; j < lista.size(); j++) {
                if (lista.get(index).populatie > lista.get(j).populatie) {
                    minim = lista.get(j).populatie;
                    index = j;
                }
            }
            Oras orasaux = lista.get(index);
            lista.set(index, lista.get(i));
            lista.set(i, orasaux);
        }
        return lista;
    }

    public static void save(ArrayList<Oras> lista, String calea, String numeFisier) {
        try {
            String caleaAbsoluta = calea + "\\" + numeFisier;
            FileWriter file = new FileWriter(caleaAbsoluta);
            BufferedWriter bw = new BufferedWriter(file);
            StringBuilder str = new StringBuilder();
            str.append(Orase.creeazaStringBuilderHeader());
            bw.write(str.toString());
            str.delete(0, str.length());
            for (Oras oras : lista) {
                str.append(Orase.creeazaStringBuilderOras(oras));
                bw.write(str.toString());
                str.delete(0, str.length());
            }
            bw.close();
        } catch (Exception e) {

        }
    }

    public static String creeazaStringBuilderHeader() {
        StringBuilder str = new StringBuilder();
        str.append("X" + SEPARATOR + "Y" + SEPARATOR + "NUME" + SEPARATOR + "JUDET" + SEPARATOR
                + "JUDET AUTO" + SEPARATOR + "POPULATIE (in 2002)"
                + SEPARATOR + "REGIUNE" + '\n');
        return str.toString();
    }

    public static String creeazaStringBuilderOras(Oras oras) {
        StringBuilder str = new StringBuilder();
        str.append(oras.X + SEPARATOR + oras.Y + SEPARATOR + oras.nume + SEPARATOR + oras.judet
                + SEPARATOR + oras.judetauto + SEPARATOR
                + oras.populatie + SEPARATOR + oras.regiune + '\n');
        return str.toString();
    }

}
