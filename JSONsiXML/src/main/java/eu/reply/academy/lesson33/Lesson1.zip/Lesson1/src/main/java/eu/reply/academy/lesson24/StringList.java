package eu.reply.academy.lesson24;

import eu.reply.academy.lesson24.ManagerDeListe;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class StringList extends ManagerDeListe<String> {

    public List<String> listaOrdonataDeStringuri = new ArrayList<>();


    @Override
    protected void adaugareElement(String valoare) {
        if (this.listaOrdonataDeStringuri.isEmpty()) {
            this.listaOrdonataDeStringuri.add(valoare);
        } else {
            this.listaOrdonataDeStringuri.add(valoare);
            Collections.sort(this.listaOrdonataDeStringuri);
        }
        System.out.println("S-a adaugat cu succes elementul!");
    }

    @Override
    protected void stergerePrimulElementCuValoareaData(String valoare) {
        if (this.listaOrdonataDeStringuri.isEmpty()) {
            System.out.println("Lista De String-uri este goala!");
        } else {
            boolean bol = this.listaOrdonataDeStringuri.remove(valoare);
            if (bol == false) {
                System.out.println("Nu exista valoarea data in lista!");
            } else {
                Collections.sort(this.listaOrdonataDeStringuri);
                System.out.println("S-a sters cu succes elementul dat!");
            }
        }
    }

    @Override
    protected void stergereElementCuIndexulDat(int index) {
        if (this.listaOrdonataDeStringuri.isEmpty()) {
            System.out.println("Lista de String-uri este goala!");
        } else {
            if (index < this.listaOrdonataDeStringuri.size()) {
                this.listaOrdonataDeStringuri.remove(index);
            } else {
                System.out.println("Indexul este mult prea mare!");
            }
        }
    }

    @Override
    protected void listareElemente() {
        if (!this.listaOrdonataDeStringuri.isEmpty()) {
            System.out.print("Lista de String-uri este urmatoarea:");
            for (String val : this.listaOrdonataDeStringuri) {
                System.out.print(val + " ");
            }
        }
        System.out.println(" ");
    }

    @Override
    protected void comparareDouaListe(ManagerDeListe obiect2) {
        long suma1 = this.calculareSumaElemente();
        long suma2 = obiect2.calculareSumaElemente();
        if (suma1 > 0 && suma2 > 0) {
            System.out.println("Suma pentru prima lista este: " + suma1);
            System.out.println("Suma pentru a doua lista este: " + suma2);
            if (suma1 == suma2) {
                System.out.println("Cele doua liste sunt egale!");
            } else if (suma1 > suma2) {
                System.out.println("Prima lista este mai mare!");
            } else {
                System.out.println("A doua lista este mai mare!");
            }
        } else {
            System.out.println("Listele sunt goale!");
        }
    }

    @Override
    protected long calculareSumaElemente() {
        long suma = 0;
        if (!this.listaOrdonataDeStringuri.isEmpty()) {
            for (String val : this.listaOrdonataDeStringuri) {
                suma += val.length();
            }
        }
        return suma;
    }
}
