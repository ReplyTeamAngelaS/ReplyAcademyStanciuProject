package eu.reply.academy.lesson6;

import java.lang.reflect.Array;
import java.util.Arrays;

public class Problem {

    public static void main(String[] args) {

        int nr = 1234;
        int[] vector = Problem.calculeaza(nr);
        System.out.println(Arrays.toString(vector));
    }

    public static int[] calculeaza(int nr) {
        int[] vector = new int[10];
        for (int i = 0; i < vector.length; i++) {
            if (nr != 0) {
                vector[i] = nr % 10;
                nr = nr / 10;
            }
        }
        return vector;
    }
}
