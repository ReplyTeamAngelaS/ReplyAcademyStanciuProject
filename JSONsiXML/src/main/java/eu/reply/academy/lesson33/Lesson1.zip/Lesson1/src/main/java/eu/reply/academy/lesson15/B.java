package eu.reply.academy.lesson15;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class B extends A{


   // public  void afisareMesaj(){
   //     System.out.println("Ana are pere");
  //  }
    public static void main(String[] args) {

        A a=new B();
        a.afisareMesaj();
        C c=new C();
        c.afisareMesaj2();
        List<Integer> lista=Arrays.asList(0,3,4);
        System.out.println(lista);
        final List<Integer> lista2=new ArrayList<>(lista);
        System.out.println(lista2);
        lista2.add(5);
        System.out.println(lista2);
    }
}
