package eu.reply.academy.ACADEMIA_JAVA.OCA.CAPITOLUL4;

import java.lang.annotation.AnnotationFormatError;
import java.net.PortUnreachableException;
import java.util.ArrayList;
import java.util.List;

public class Overloading {

    //OVERLOADING-UL ESTE REALIZAT IN TREI CAZURI:

    //1) CAND AVEM UN NUMAR DIFERIT DE PARAMETRII

    //EXEMPLE:
    //1.1)
    public void citeste(int nr) {}  //DIN 1.1) => NU CONTEAZA SPECIFICATORII, CONTEAZA SEMNATURA!!
    public static void citeste(int nr, int minute) {}

    //1.2)
    protected int returneazaInt(int valoare) {return 0;} //DIN 1.2) => NU CONTEAZA MODIFICATORII DE ACCES, SPECIFICATORII, TIPUL DE RETURNARE...
    private static double returneazaInt(int valoare, int multiplicare) {return 0;}//..., CONTEAZA SEMNATURA!!

    //2) CAND AVEM TIPUL DE DATA AL PARAMETRULUI DIFERIT

    //EXEMPLE:
    //2.1)
    public void mananca(int nrFeluri) {} //DIN 2.1) => NU CONTEAZA CA E LA FEL MODIFICATORUL DE ACCES SI TIPUL DE RETURNARE...
    public void mananca(double nrFeluri) {}//..., CONTEAZA SEMNATURA!!

    //2.2)
    protected int bea(int nrDoze) {return 0;}//DIN 2.2) => NU CONTEAZA CA MODIFICATORUL DE ACCES ESTE DIFERIT SI CA O METODA ARUNCA O EXCEPTIE...
    private double bea(double nrDoze) throws Exception {return 0;}//..., CONTEAZA SEMNATURA!!

    //3) CAND AVEM ORDINEA PARAMETRILOR DIFERITA

    //EXEMPLE:
    //3.1)
    public void doarme(int ore, int minute, double secunde) {} //NU CONTEAZA CA ESTE LA FEL, CONTEAZA SEMNATURA!!!
    public void doarme(int minute, double secunde, int ore) {}
    //3.2)
    // public int doarme(int ore, int minute){return 0;} //NU CONTEAZA CA TIPUL DE RETURNARE ESTE DIFERIT...
    // public void doarme(int minute, int ore){}//...ATATA TIMP CAT SEMNATURA COINCIDE, NE VA EROARE DE COMPILARE

    //------------------------------------------------------------------------------------------------------------------
    //--------------------------------------------------------------------------------------------------------------------

    //FOLOSIRE VARARGS
    //EXEMPLU
    // public void lucreaza(int[] nrHartiiPeOra){} //PENTRU CA VARARGS SE COMPORTA CA UN VECTOR => SEMNATURA ESTE ACEEASI...
    // public void lucreaza(int... nrHartiiPeOra){}//...NE VA DA EROARE DE COMPILARE

    //------------------------------------------------------------------------------------------------------------------
    //--------------------------------------------------------------------------------------------------------------------

    // AUTOBOXING
    // CONVERTIRE INT -> INTERGER
    //EXEMPLU:
    public static void ssh(int valoare) {
        System.out.println("tip primitiv");
    }
    public static void ssh(Integer valoare) {System.out.println("tip referinta");}

    //------------------------------------------------------------------------------------------------------------------
    //--------------------------------------------------------------------------------------------------------------------

    //OVERLOADING CU UN PARAMETRU DE TIP REFERINTA
    //EXEMPLU:
    //public static void mes(List<Integer> list){} //OVERLOADING-UL NU MERGE CU LIST, CHIAR DACA TIPUL E DIFERIT.NE VA DA EROARE DE COMPILARE!!
    //public static void mes(ArrayList<Integer> list){} //OVERLOADING-UL NU MERGE CU ARRAYLIST, CHIAR DACA TIPUL E DIFERIT.NE VA DA EROARE DE COMPILARE!!
    //OVERLOADING-UL AR FI MERS DACA AVEM O METODA CU UN PARAMETRU LIST<INTEGER> SI ALTA CU ARRAYLIST<INTEGER>
    public static void mesaj(Integer valoare) {
        System.out.println("Integer");
    }
    public static void mesaj(Long valoare) {
        System.out.println("Long");
    }
    public static void mesaj(Object valoare){System.out.println("Obiect");}
    //EXEMPLU PENTRU A VEDEA REGULILE OVERLOADING-ULUI IN APLICARE PE O REFERINTA - UTILIZAREA CLASELOR WRAPPER
    public static void afiseaza(Double valoare){System.out.println("Double");}
    //EXPLICATII IN APELAREA METODEI:
    // EXPLICATIA 1): DACA AVEM UN INT (PRIMITIV) SI APELAM CU ACEASTA, NE VA DA EROARE DE COMPILARE. DE CE?
    //RASPUNS: JAVA CAUTA METODA CU PARAMETRUL DE TIP PRIMITIV PRIMA DATA. NU GASESTE. JAVA APOI CAUTA METODA CARE PRIMESTE CA PARAMETRU
    //UN TIP MAI LARG (PRIMITIV). NU GASESTE. JAVA APOI FACE AUTOBOXING, ADICA INT-> INTEGER. JAVA CAUTA O METODA CU INTEGER.
    //NU GASESTE...IN SCHIMB AVEM DOUBLE. DOUBLE SI INTEGER SUNT DOUA OBIECTE DE TIPURI DIFERITE...CA SA MEARGA TREBUIA SA APELAM
    //METODA DOUBLE.VALUEOF(); CONVERTIM EXPLICIT
    //EXPLICATIA 2): DACA AVEM UN INTEGER SI DORIM APELAREA METODEI, NE VA DA EROARE DE COMPILARE. DE CE?
    //RASPUNS: CLASA INTEGER SI CLASA DOUBLE SUNT DOUA INSTANTE DIFERITE CARE NU SE MOSTENESC!! TREBUIE O CONVERSIE EXPLICITA
    //FOLOSIND DOUBLE.VALUEOF()...DESI DACA ERA PRIMITIV, ADICA INT DOUBLE AR FI MERS...NOI AVEM REFERINTE DE DATA ACEASTA !!

    //------------------------------------------------------------------------------------------------------------------
    //--------------------------------------------------------------------------------------------------------------------

    //OVERLOADING CU UN PARAMETRU DE TIP PRIMITIV
    public static void afiseazaPrimitiv(double valoare){System.out.println("double");}
    //EXPLICATII IN APELAREA METODEI:
    //EXPLICATIA 1): DACA AVEM UN INT (PRIMITIV) SI APELAM CU ACEASTA, JAVA PRIMA DATA VA CAUTA O METODA CARE SA PRIMEASCA TIPUL
    //EXACT DE DATA. NU GASESTE. JAVA APOI CAUTA METODA CARE PRIMESTE PARAMETRUL CU TIPUL DE DATA MAI LARG. SI E VALID.

    public static void main(String[] args) {
        int valoare = 5;
        Integer valoareInteger = 10;
        Long valoareLong = 30L;
        Double valoareDouble=40.50;
        Short valoareShort=10;
        ssh(valoare); //IA TIPUL DE DATA EXACT, ADICA INT VALOARE
        ssh(valoareInteger); //IA TIPUL DE DATA EXACT, ADICA INTEGER CA VALOARE
        ssh(20);//IA TIPUL DE DATA EXACT, ADICA INT CA VALOARE
        mesaj(valoareInteger); //IA TIPUL DE DATA EXACT, ADICA INTEGER CA VALOARE
        mesaj(valoareLong);//IA TIPUL DE DATA EXACT, ADICA LONG CA VALOARE
        mesaj(valoareDouble);//PENTRU CA NU EXISTA O METODA CARE SA PRIMEASCA O CLASA DOUBLE, JAVA CAUTA O REFERINTA MAI LARGA, ADICA OBJECT
        afiseazaPrimitiv(valoare);//DESI AVEM TIPUL DOUBLE, NOI FOLOSIM CU TIPUL DE DATA INT. ESTE VALID. IA TIPUL DE DATA MAI LARG.

    }


}
