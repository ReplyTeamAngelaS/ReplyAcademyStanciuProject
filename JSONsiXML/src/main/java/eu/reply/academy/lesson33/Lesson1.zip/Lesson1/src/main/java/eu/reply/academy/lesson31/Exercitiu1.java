package eu.reply.academy.lesson31;

public class Exercitiu1 {

    public String findStringMic(String nume, String nume2) {
        if (nume.length() < nume2.length())
            return nume;
        else
            return nume2;
    }
}
