package eu.reply.academy.lesson13;

import java.util.Scanner;

public class Piramida {

    public static void main(String[] args) {
        int n = Piramida.daNumarulN();
        System.out.println("Piramida rezultata este: ");
        Piramida.afiseazaPiramida(n);
    }

    public static int daNumarulN() {
        Scanner scan = new Scanner(System.in);
        System.out.print("Scrie un numar natural: ");
        int n = scan.nextInt();
        if (!((n >= 1) && (n <= 20))) {
            System.out.println("Numarul trebuie sa fie in intervalul 1 si 20");
            return daNumarulN();
        }
        return n;
    }

    public static void afiseazaPiramida(int n) {
        int linie = 1;
        int numar = 1;
        while (linie <= n) {
            while (numar <= linie) {
                System.out.print(numar + " ");
                numar++;
            }
            numar = 1;
            System.out.print("\n");
            linie++;
        }
    }
}
