package eu.reply.academy.lesson28;

import eu.reply.academy.lesson16.Switcharoo;
import eu.reply.academy.lesson28.Main.Utilitar;
import junit.framework.TestCase;
import org.junit.Assert;
import org.junit.Test;

public class UtilitarTest extends TestCase {

    @Test
    public void test01() {
        Assert.assertEquals("Unknown", Utilitar.getKey(null));
    }

    @Test
    public void test02() {
        Assert.assertEquals("Unknown", Utilitar.getKey("adfafa"));
    }

    @Test
    public void test03() {
        Assert.assertEquals("nume", Utilitar.getKey("nume=Windows"));
    }

    @Test
    public void test04() {
        Assert.assertEquals("Unknown", Utilitar.getValue(null));
    }

    @Test
    public void test05() {
        Assert.assertEquals("Unknown", Utilitar.getValue("adfafa"));
    }

    @Test
    public void test06() {
        Assert.assertEquals("Windows", Utilitar.getValue("nume=Windows"));
    }
}
