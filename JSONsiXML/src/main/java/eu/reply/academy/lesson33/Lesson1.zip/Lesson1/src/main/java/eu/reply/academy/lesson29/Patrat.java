package eu.reply.academy.lesson29;

public class Patrat extends Patrulater {

    protected Patrat(double latura) {
        super(latura, latura);
    }

    protected Patrat() {

    }

    @Override
    protected double calculeazaAria() {
        double arie = this.getLungime() * this.getLatime();
        return arie;
    }

}
