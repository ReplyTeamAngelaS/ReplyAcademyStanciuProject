package eu.reply.academy.lesson31;

public class RunMe {

    public static void main(String[] args) {
        Exercitiu1 obiect = new Exercitiu1();
        System.out.println(obiect.findStringMic("1234", "123"));
        StringMic<String, String, String> obiectInterface = (a, b) -> {
            if (a.length() < b.length()) return a;
            else return b;
        };
        System.out.println(obiectInterface.findStringMic("1234", "123"));
        System.out.println("--------------------------------------------------------");
        Exercitiu2 obiect2 = new Exercitiu2();
        System.out.println(obiect2.printSubstring(3, "Angela"));
        Substring<Integer, String, String> obiectInterface2 = (a, b) -> b.substring(0, a);
        System.out.println(obiectInterface2.printSubstrig(3, "Angela"));
        System.out.println("---------------------------------------------------------");
    }
}
