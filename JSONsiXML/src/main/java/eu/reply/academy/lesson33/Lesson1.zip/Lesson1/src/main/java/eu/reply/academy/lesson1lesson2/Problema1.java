package eu.reply.academy.lesson1lesson2;

import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

public class Problema1 {
    // O metoda care primeste un numarul int ca parametru si intoarce inapoi un vector care contine toate numerele mai mici
    // sau egale cu n care sunt divizibile cu 3 sau 5
    public static void main (String[] args)
    {
        int[] vector=numereDiv(13);
        Afiseaza(vector);
    }

    @Contract(pure = true)
    public static int @NotNull [] numereDiv(int number)
    {
        int[] vector=new int[number];
        int c=0;
        for(int i=1; i<=number; i++)
        {
            if((i%3==0) || (i%5==0))
            {
                vector[c] = i;
                c++;
            }
        }
        return vector;
    }

    public static void Afiseaza(int @NotNull [] vector)
    {
        for(int i=0; i< vector.length; i++)
        {
            if(vector[i]!=0)
            {
                System.out.println(vector[i]);
            }
        }
    }
}
