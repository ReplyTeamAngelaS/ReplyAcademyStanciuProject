package eu.reply.academy.classes.grandparent;

public class GrandParent {

    private String privateAge = "Private Age Grand Parent";
    String defaultAge = "Default Age Grand Parent";
    protected String protectedAge = "Protected Age Grand Parent";
    public String publicAge = "Public Age Grand Parent";

    private String getPrivateAge() {
        return this.privateAge;
    }

    String getDefaultAge() {
        return this.defaultAge;
    }

    protected String getProtectedAge() {
        return  this.protectedAge;
    }

    public String getPublicAge() {
        return this.publicAge;
    }

    public String getPublicAge(int age) {
        return privateAge + " " + age;
    }

    public String getPublicAge(int age1, int age2) {
        return privateAge + " " + age1 + " " + age2;
    }

}
