package eu.reply.academy.lesson20;

import java.util.ArrayList;
import java.util.Objects;

public class HeartSurgeon extends Surgeon {

    public ArrayList<Operatie> listaOperatiiPeInima=new ArrayList<Operatie>();

    @Override
    public void operatie(Operatie operatie) {
        for (Operatie operatie1 : listaOperatii) {
            if (operatie == operatie1) {
                operatie.operatie();
            }
        }
    }

    @Override
    public void tipChirurg() {
        System.out.println("Chirurgul este specialist pe inima.");
    }
}
