package eu.reply.academy.lesson4;

import java.util.Arrays;

public class Ex1 {

    public static void main(String[] args) {
        int[] vector = { 2, 5, 6, 2, 5, 7, 1, 0, 7, 1};
        float resultat=calculeaza(vector);
        System.out.println(resultat);
    }

    public static float calculeaza(int[] vector)
    {
        int[] vectorDiv3=new int[vector.length];
        int[] vectorImp3Egal1=new int[vector.length];
        int[] vectorImp3Egal2=new int[vector.length];
        int c1=0;
        int c2=0;
        int c3=0;
        int i=0;
        while(i<vector.length) {
            if(vector[i]%3==0) {
                vectorDiv3[c1]=vector[i];
                c1++;
            }
            else if(vector[i]%3==1) {
                vectorImp3Egal1[c2]=vector[i];
                c2++;
            }
            else if(vector[i]%3==2) {
                vectorImp3Egal2[c3]=vector[i];
                c3++;
            }
            i++;
        }
        float resultat=0;
        //int max - o alta abordare (c1,c2,c3)
        if((c1>=c2) && (c1>=c3))  {
            System.out.println("Primul vector este mai mare");
            System.out.println("Are un numar de elemente:" + c1);
            int suma=0;
            int j=0;
            while(j<c1) {
                suma+=vectorDiv3[j];
                j++;
            }
            resultat=suma;
            System.out.println("Suma elementelor (in afara de zerouri) este:"+ resultat);
        }
        if((c2>=c1) && (c2>=c3)) {
            System.out.println("Al doilea vector este mai mare");
            System.out.println("Are un numar de elemente:" + c2);
            int minim=vectorImp3Egal1[0];
            int k=1;
            while(k<c2) {
                if(vectorImp3Egal1[k]<minim) {
                    minim=vectorImp3Egal1[k];
                }
                k++;
            }
            resultat=minim;
            System.out.println("Minimul este (in afara de zerouri):"+ resultat);
        }
        if ((c3>=c1) && (c3>=c2)) {
            System.out.println("Al treilea vector este mai mare");
            System.out.println("Are un numar de elemente:" + c3);
            int mijloc=c3/2;
            if(c3%2!=0) {
                System.out.println("Vectorul are numar impar de elemente");
                resultat=vectorImp3Egal2[mijloc];
                System.out.println("Mijlocul - pozitia i (se porneste de la zero) este:" + mijloc);
                System.out.println("Mijlocul este:"+ resultat);
            } else {
                System.out.println("Vectorul are numar par de elemente");
                System.out.println("V[1]=" + vectorImp3Egal2[mijloc]);
                System.out.println("V[2]=" + vectorImp3Egal2[mijloc-1]);
                float medie = (float)(vectorImp3Egal2[mijloc]+vectorImp3Egal2[mijloc-1])/2;
                //float medie2= (5+2)/2;
                resultat=medie;
                System.out.println("Media este:"+ resultat);
            }
        }
        System.out.println("Primul vector div 3 = 0:"+ Arrays.toString(vectorDiv3));
        System.out.println("Al doilea vector div 3 = 1"+ Arrays.toString(vectorImp3Egal1));
        System.out.println("Al treilea vector div 3 = 2:"+ Arrays.toString(vectorImp3Egal2));
        return resultat;
    }
}
