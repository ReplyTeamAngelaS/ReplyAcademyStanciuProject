package eu.reply.academy.lesson28.Main;

import eu.reply.academy.lesson26.LinuxOS;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class VirtualMachine {

    protected int priorityNumber;
    protected String osName;
    protected int cpuNumber;
    protected List<String> listAplications;
    protected String type;
    protected List<Core> listCore;

    protected VirtualMachine(String osName, int cpuNumber, List<String> listAplications, String type) {
        this.copyListAplications(listAplications);
        this.cpuNumber = cpuNumber;
        this.type = type;
        this.osName = osName;
    }

    protected VirtualMachine() {
        this.setListCoreIfNull();
    }

    protected void copyListOfCore(List<Core> listCore) {
        if (this.listCore == null) {
            this.listCore = new ArrayList<>();
        }
        for (Core core : this.listCore) {
            this.listCore.add(core);
        }
    }

    protected void setListCoreIfNull() {
        if (this.listCore == null) {
            this.listCore = new ArrayList<>();
        }
    }

    protected void setListCore(Core core) {
        if (this.listCore == null) {
            this.listCore = new ArrayList<>();
        }
        this.listCore.add(core);
    }

    protected void copyListAplications(List<String> list) {
        if (this.listAplications == null) {
            this.listAplications = new ArrayList<>();
        }
        for (String element : list) {
            this.listAplications.add(element);
        }
    }

    protected void setPriorityNumber(int priorityNumber) {
        boolean isUnic = true;
        if (priorityNumber == 0) {
            isUnic = false;
        } else {
            if (!Hypervisor.listVMachineCreated.isEmpty()) {
                for (VirtualMachine virtualMachine : Hypervisor.listVMachineCreated) {
                    if (virtualMachine.priorityNumber == priorityNumber) {
                        isUnic = false;
                    }
                }
            }
        }
        if (!isUnic) {
            System.out.println("Dati alta valoare la prioritate.");
        } else {
            this.priorityNumber = priorityNumber;
        }
    }

    protected void setOsName(String name) {
        if (name == null) {
            System.out.println("Numele este null.");
        } else {
            this.osName = name;
        }
    }

    protected void setCpuNumber(String number) {
        if (number == null) {
            System.out.println("Numarul este null.");
        } else {
            this.cpuNumber = Integer.parseInt(number);
        }
    }

    /*protected void setListAplications(String list) {
        this.listAplications = new ArrayList<>();
        if (list == null) {
            System.out.println("Lista e null.");
        } else {
            List<String> list2 = Arrays.asList(list.split(", "));
            this.listAplications.addAll(list2);
        }
    }*/

    protected void setListAplications(String value) {
        if (this.listAplications == null) {
            this.listAplications = new ArrayList<>();
        }
        if (value == null) {
            System.out.println("Valoarea este null.");
        } else {
            this.listAplications.add(value);
        }
    }

    protected void addListApplications(String... vector) {
        if (vector == null) {
            System.out.println("Valoarea este null.");
        } else {
            List<String> list = Arrays.asList(vector);
            this.listAplications.addAll(list);
        }
    }

    protected void addListApplication(String name) {
        if (name == null) {
            System.out.println("Valoarea este null.");
        } else {
            this.listAplications.add(name);
        }
    }

    protected void setType(String type) {
        if (type == null) {
            System.out.println("Tipul este null.");
        } else {
            this.type = type;
        }
    }

    protected int getPriorityNumber() {
        return this.priorityNumber;
    }

    protected String getOsName() {
        return this.osName;
    }

    protected int getCpuNumber() {
        return this.cpuNumber;
    }

    protected List<String> getListAplications() {
        return this.listAplications;
    }

    protected String getType() {
        return this.type;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(" Masina Virtuala\n Nume SO- " + this.osName
                + ";\n Tip SO- " + this.type
                + ";\n Numar procesoare necesare- " + this.cpuNumber
                + ";\n Numar Prioritate- " + this.priorityNumber + ";\n Lista Aplicatii- "
                + Arrays.toString(this.listAplications.toArray()).replace('[', ' ')
                .replace(']', ' ').trim() + "; \n");
        return stringBuilder.toString();
    }

}
