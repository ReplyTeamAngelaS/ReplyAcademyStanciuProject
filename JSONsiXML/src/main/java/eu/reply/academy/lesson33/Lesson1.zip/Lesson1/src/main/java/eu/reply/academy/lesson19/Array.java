package eu.reply.academy.lesson19;

public class Array {

    public int[] vector;

    public void adaugaElement(int nr) {
        if (vector == null) {
            vector = new int[1];
            vector[0] = nr;
        } else {
            int[] vectorTemporar = vector;
            vector = new int[vectorTemporar.length + 1];
            for (int i = 0; i < vectorTemporar.length; i++) {
                vector[i] = vectorTemporar[i];
            }
            vector[vector.length - 1] = nr;
        }
    }

    public int cautaElementFirst(int nr) {
        if (vector == null) {
            return -1;
        } else {
            for (int i = 0; i < vector.length; i++) {
                if (vector[i] == nr) {
                    return i;
                }
            }
            return -1;
        }
    }

    public void stergeElement(int pozitie) {
        if (vector != null) {
            for (int i = 0; i < vector.length - 1; i++) {
                if (i >= pozitie) {
                    vector[i] = vector[i + 1];
                }
            }
            int[] vectorTemporar = vector;
            vector = new int[vectorTemporar.length - 1];
            for (int i = 0; i < vector.length; i++) {
                vector[i] = vectorTemporar[i];
            }
        }
    }
}
