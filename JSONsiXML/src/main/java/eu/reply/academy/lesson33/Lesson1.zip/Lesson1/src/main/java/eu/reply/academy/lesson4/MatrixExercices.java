package eu.reply.academy.lesson4;

import java.util.Arrays;

public class MatrixExercices {

    public static void main(String[] args) {
        String[][] matrix1; // declarare = o numim
        String[][] matrix = new String[3][5]; // declarare + instantiere = am alocat memorie pentru variabila
        String[][] matrix2 = new String[][] {{"2", "5"},{"3"},{"5", "7", "a", "c"}, {"8"}}; // declarare + instantiere + initializare = am dat si valori in memorie pentru variabila
        // matrix2[0] = {2 5}
        // matrix2[1] = {3}
        // matrix2[2] = {5 7 a c}
        // matrix2[3] = {8}
        //System.out.println(Arrays.toString(matrix2[2]));
        //System.out.println(matrix2.length);
        //1. Dimensiunea ultimului array din matrix2
        //System.out.println(matrix2[matrix2.length-1].length);
        //2. Cate elemente contine un array bidimensional
//        int sum = 0;
//        for (int i=0; i<matrix2.length; i++){
//            sum = sum + matrix2[i].length;
//        }
//        System.out.println(sum);
        //3. O metoda care primeste ca parametru un array bidimensional de float
        // si returneaza un array care contine suma elementelor de pe fiecare linie
        // float[][] matrice = {{ 2.5, 4.3, 5.5}, {2.2, 1.1}, {4.3}};
        // rezultat: { 12.3, 3.3, 4.3};
        float[][] matrice = new float[][]{{ 2.5F, 4.3F, 5.5F}, {2.2F, 1.1F}, {4.3F}};
        float[] vector=calculeazaSumaElemente(matrice);
        System.out.println(Arrays.toString(vector));

    }

    public static float[] calculeazaSumaElemente(float[][] matrice) {
        float[] rezultat=new float[matrice.length];
        for(int i=0; i<matrice.length; i++) {
            float sumaLinie=0;
            float[] vector=matrice[i];
            for(int j=0; j<vector.length;j++) {
                sumaLinie+=vector[j];
            }
            rezultat[i]=sumaLinie;
        }
        return  rezultat;
    }


}
