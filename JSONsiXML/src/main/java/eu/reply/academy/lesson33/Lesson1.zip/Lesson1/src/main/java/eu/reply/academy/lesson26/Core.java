package eu.reply.academy.lesson26;

public abstract class Core {

    protected long ID;
    private static final long contor = 37;
    private static long numarRandom = 222;
    protected static int NumarTotalSubclase = CoreDisk.CONTOR_CORE + CoreScreen.CONTOR_CORE;

    protected void setID() {
        this.ID = Core.numarRandom + Core.contor;
        Core.numarRandom += Core.contor;
    }


}
