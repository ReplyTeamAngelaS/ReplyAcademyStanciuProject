package eu.reply.academy.lesson23.beans;

public class TipContact {

    public int id;
    public String tip;
}
