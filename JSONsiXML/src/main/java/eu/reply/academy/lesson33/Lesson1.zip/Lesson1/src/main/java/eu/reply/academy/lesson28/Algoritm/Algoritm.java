package eu.reply.academy.lesson28.Algoritm;

import java.util.Arrays;

public class Algoritm {

    public static void main(String[] args) {
        char[][] matrice = new char[4][10];
        for (int i = 0; i < matrice.length; i++) {
            char[] vector = new char[matrice[i].length];
            for (int j = 0; j < vector.length; j++) {
                if (i % 2 == 0) {
                    if (j % 2 == 0) {
                        matrice[i][j] = 'j';
                    } else {
                        matrice[i][j] = 'a';
                    }
                } else {
                    if (j % 2 == 0) {
                        matrice[i][j] = 'a';
                    } else {
                        matrice[i][j] = 'j';
                    }
                }
            }

        }
        System.out.println(Arrays.deepToString(matrice));
    }
}
