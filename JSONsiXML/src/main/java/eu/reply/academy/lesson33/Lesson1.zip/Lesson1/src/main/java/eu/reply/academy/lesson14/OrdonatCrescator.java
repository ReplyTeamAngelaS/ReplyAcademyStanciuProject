package eu.reply.academy.lesson14;

import java.util.Arrays;
import java.util.Scanner;

public class OrdonatCrescator {

    public static void main(String[] args) {
        int n = OrdonatCrescator.daNumarN();
        int[] vector = OrdonatCrescator.citireSir(n);
        OrdonatCrescator.afiseazaRezultatul(vector);
    }

    public static int daNumarN() {
        Scanner scan = new Scanner(System.in);
        System.out.print("Numarul natural reprezentand dimensiunea sirului este: ");
        int n = scan.nextInt();
        if (!((n >= 1) && (n <= 500))) {
            System.out.println("Numarul trebuie sa fie in intervalul 1 si 500.");
            return daNumarN();
        }
        return n;
    }

    public static int daNumarSir() {
        Scanner scan = new Scanner(System.in);
        System.out.print("Scrie un numar natural: ");
        int n = scan.nextInt();
        if (!(n <= 9999)) {
            System.out.println("Numarul trebuie sa fie mai mic decat 9999");
            return daNumarSir();
        }
        return n;
    }

    public static int[] citireSir(int n) {
        int[] vector = new int[n];
        for (int i = 0; i < vector.length; i++) {
            vector[i] = ValoareaAbsoluta.daNumarSir();
        }
        System.out.println("-----------------------------------------------");
        System.out.println("Numerele din sir sunt: " + Arrays.toString(vector));
        return vector;
    }

    public static void afiseazaRezultatul(int[] vector) {
        boolean bol = true;
        int ultimulIndice = vector.length - 1;
        for (int i = 0; i < ultimulIndice && bol; i++) {
            if (vector[i] > vector[i + 1]) {
                bol = false;
            }
        }
        if (bol) {
            System.out.println("DA");
        } else {
            System.out.println("NU");
        }
    }

}
