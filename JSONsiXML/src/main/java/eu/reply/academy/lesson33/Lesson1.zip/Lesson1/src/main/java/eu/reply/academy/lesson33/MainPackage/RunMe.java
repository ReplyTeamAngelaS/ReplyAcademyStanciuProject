package eu.reply.academy.lesson33.MainPackage;

public class RunMe {

    public static void main(String[] args) {

    }
}
