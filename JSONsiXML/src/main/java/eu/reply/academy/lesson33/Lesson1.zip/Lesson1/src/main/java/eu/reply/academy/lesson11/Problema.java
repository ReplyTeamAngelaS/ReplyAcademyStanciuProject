package eu.reply.academy.lesson11;

import java.util.Arrays;
import java.util.Random;

public class Problema {
    public static void main(String[] args) {
        int[] vector = {1, 3, 5, 7, 9, 8, 6, 4};
        int n = 6;
        /*int[] vectorRezultat = Problema.scrieVectorulCuNNumere(vector, n);
        System.out.println(Arrays.toString(vectorRezultat));
        System.out.println(Problema.esteVectorulUnic(vectorRezultat));*/
        int[] vectorRezultat = Problema.scrieVectorulCuNNumere(vector, n);
        System.out.println(Arrays.toString(vectorRezultat));
        /*Random st = new Random();
        int numar = st.nextInt(n);
        System.out.println(numar);*/
    }

    public static int[] metodaPrincipala(int[] vector, int n) {
        int[] vectorRezultat = Problema.scrieVectorulCuNNumere(vector, n);
        while (!esteVectorulUnic(vectorRezultat)) {
            vectorRezultat = Problema.scrieVectorulCuNNumere(vector, n);
        }
        return vectorRezultat;
    }

    public static int[] scrieVectorulCuNNumere(int[] vector, int n) {
        int[] vectorRezultat = new int[n];
        int i = 0;
        //int k = 0;
        // Random st = new Random();
        while (i < n) {
            // int j = st.nextInt(vector.length);
            int j = (int) (Math.random() * vector.length);
            // if (j < vector.length) {

            //k++;
            if (vectorContine(vectorRezultat, vector[j]) == false) {
                vectorRezultat[i] = vector[j];
                i++;
            }

            // }
        }
        return vectorRezultat;
    }

    public static boolean vectorContine(int[] vectorRezultat, int numar) {
        boolean bol = false;
        if (vectorRezultat.length == 0) {
            return false;
        } else {
            for (int i = 0; i < vectorRezultat.length; i++) {
                if (vectorRezultat[i] == numar) {
                    return true;
                }
            }
            return bol;
        }
    }

    public static boolean esteVectorulUnic(int[] vectorRezultat) {
        //outerloop:
        for (int i = 0; i < vectorRezultat.length; i++) {
            int j = i + 1;
            while (j < vectorRezultat.length) {
                if (vectorRezultat[i] != vectorRezultat[j]) {
                    j++;
                    //continue;
                } else {
                    //boolean bol=false;
                    // break outerloop;
                    return false;
                }
            }
        }
        return true;
    }

}
