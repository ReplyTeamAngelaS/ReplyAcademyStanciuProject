package eu.reply.academy.lesson28.Main;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Processor {

    private static int RANDOM_NUMBER = 5252;
    private static final int COUNTER = 59;

    protected int Id;
    protected List<Core> listCore;

    protected Processor(Core... vector) {
        this.createUniqueId();
        List<Core> list = Arrays.asList(vector);
        this.listCore = list;
    }

    protected Processor() {
        this.createUniqueId();
        if (this.listCore == null) {
            this.listCore = new ArrayList<>();
        }
    }

    protected void addCore(Core core) {
        this.listCore.add(core);
    }

    protected void createUniqueId() {
        this.Id = Processor.RANDOM_NUMBER + Processor.COUNTER;
        Processor.RANDOM_NUMBER += Processor.COUNTER;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Procesor fizic: \n ID- #" + this.Id
                + ";\n Lista Core:\n "
                + Arrays.toString(this.listCore.toArray()).replace('[', ' ').replace(']', ' ')
                .replace(',', ' '));
        return stringBuilder.toString();
    }
}
