package eu.reply.academy.lesson25;

import java.util.List;

public class Exceptii {


    public static boolean tratareRegistriiNeinitializati(List<Registru> lista, String denumireRegistru) {
        boolean esteRegistrulInitializat = false;
        if (lista.isEmpty()) {
            System.out.println("Registrul nu este initializat!");
            return esteRegistrulInitializat;
        } else {
            for (Registru reg : lista) {
                if (reg.denumire.equals(denumireRegistru)) {
                    esteRegistrulInitializat = true;
                }
            }
            if (esteRegistrulInitializat) {
                return esteRegistrulInitializat;
            } else {
                System.out.println("Registrul nu este initializat!");
                return esteRegistrulInitializat;
            }
        }
    }
}
