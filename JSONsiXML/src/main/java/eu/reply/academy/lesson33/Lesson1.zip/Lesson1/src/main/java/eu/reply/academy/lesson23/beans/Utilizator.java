package eu.reply.academy.lesson23.beans;

public class Utilizator {

    public int id;
    public String username;
    public String password;
}
