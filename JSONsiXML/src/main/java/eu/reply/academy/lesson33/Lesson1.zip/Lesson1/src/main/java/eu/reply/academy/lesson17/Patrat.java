package eu.reply.academy.lesson17;

public class Patrat extends Paralelogram {

    public Punct origine;
    public int latura;

    public Patrat(Punct origine, int latura) {
        this.origine = origine;
        this.latura = latura;
        double jumalatura = (double) latura / 2;
        int maximX;
        int minimX;
        int maximY;
        int minimY;
        maximX = (int) (origine.x + jumalatura);
        maximY = (int) (origine.y + jumalatura);
        minimX = maximX - latura;
        minimY = maximY - latura;
        this.a = new Punct(minimX, minimY);
        this.b = new Punct(maximX, minimY);
        this.c = new Punct(maximX, maximY);
        this.d = new Punct(minimX, maximY);
    }

    @Override
    public String toString() {
        StringBuilder str = new StringBuilder();
        str.append("Patratul are latura " + latura + " cu originea punctului " + origine + " .Astfel, punctele rezultate sunt: "
                + a + "," + b + "," + c + "," + d);
        return str.toString();
    }

    public int calculeazaPerimetrul() {
        int perimetru = 4 * this.latura;
        return perimetru;
    }
}
