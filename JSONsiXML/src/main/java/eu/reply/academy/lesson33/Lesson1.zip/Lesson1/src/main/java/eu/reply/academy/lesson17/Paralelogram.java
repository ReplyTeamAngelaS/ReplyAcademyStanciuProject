package eu.reply.academy.lesson17;

public class Paralelogram extends Patrulater{

    public Paralelogram(Punct a, Punct b, Punct c, Punct d) {
        super(a, b, c, d);
    }

    public Paralelogram(){

    }
}
