package eu.reply.academy.lesson23.beans;

public class Contact {

    public int id;
    public String valoare;
    public int idTipContact;
    public int idPersoana;
}
