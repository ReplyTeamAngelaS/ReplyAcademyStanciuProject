package eu.reply.academy.lesson17;

public class Dreptunghi extends Paralelogram {

    public Punct origine;
    public int lungime;
    public int latime;

    public Dreptunghi(Punct origine, int lungime, int latime) {
        this.origine = origine;
        this.lungime = lungime;
        this.latime = latime;
        double jumaLatime = (double) latime / 2;
        double jumaLungime = (double) lungime / 2;
        int maximX;
        int maximY;
        int minimX;
        int minimY;
        if (origine.x > origine.y) {
            maximX = (int) (origine.x + jumaLungime);
            maximY = (int) (origine.y + jumaLatime);
            minimX = maximX - lungime;
            minimY = maximY - latime;
        } else {
            maximX = (int) (origine.x + jumaLatime);
            maximY = (int) (origine.y + jumaLungime);
            minimX = maximX - latime;
            minimY = maximY - lungime;
        }
        this.a = new Punct(minimX, minimY);
        this.b = new Punct(maximX, minimY);
        this.c = new Punct(maximX, maximY);
        this.d = new Punct(minimX, maximY);
    }

    @Override
    public String toString() {
        StringBuilder str = new StringBuilder();
        str.append("Dreptunghiul are lungimea " + lungime + " si latimea " + latime + ", cu originea punctului " + origine + "."
                + "Astfel, punctele rezultate sunt: " + a + "," + b + "," + c + "," + d);
        return str.toString();
    }

    public int calculeazaPerimetrul() {
        int perimetru = 2 * this.lungime + 2 * this.latime;
        return perimetru;
    }

   /* public Dreptunghi(Punct a, Punct b, Punct c, Punct d) {
        super(a, b, c, d);
        int minimX = calculeazaMinim(a.x, b.x, c.x, d.x);
        int minimY = calculeazaMinim(a.y, b.y, c.y, d.y);
        int maximX = calculeazaMaxim(a.x, b.x, c.x, d.x);
        int maximY = calculeazaMaxim(a.y, b.y, c.y, d.y);
        int diferenta1 = maximX - minimX;
        int diferenta2 = maximY - minimY;
        if (diferenta1 > diferenta2) {
            lungime = diferenta1;
            latime = diferenta2;
        } else {
            lungime = diferenta2;
            latime = diferenta1;
        }
    }

    public int calculeazaMinim(int a, int b, int c, int d) {
        int minim = a;
        if (a > b) {
            minim = b;
        }
        if (a > c) {
            minim = c;
        }
        if (a > d) {
            minim = d;
        }
        return minim;
    }

    public int calculeazaMaxim(int a, int b, int c, int d) {
        int maxim = a;
        if (a < b) {
            maxim = b;
        }
        if (a < c) {
            maxim = c;
        }
        if (a < d) {
            maxim = d;
        }
        return maxim;
    }*/


}
