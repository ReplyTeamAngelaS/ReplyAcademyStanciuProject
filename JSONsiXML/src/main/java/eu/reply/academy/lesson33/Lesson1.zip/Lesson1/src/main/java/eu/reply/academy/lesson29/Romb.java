package eu.reply.academy.lesson29;

public class Romb extends Patrulater {

    protected Romb(double diagonala1, double diagonala2) {
        super(diagonala1, diagonala2);
    }

    protected Romb() {

    }

    @Override
    protected double calculeazaAria() {
        double arie = (this.getLungime() * this.getLatime()) / 2;
        return arie;
    }
}
