/*
package eu.reply.academy.lesson32.Model;

import org.w3c.dom.Node;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public abstract class FactoryMenu {

    public static final String PATH = "C:\\Users\\Angela Stanciu\\IdeaProjects\\Lesson1\\src\\main\\java\\eu\\reply\\academy\\lesson32\\Files";


    protected abstract Menu createObjectMenu(Node node);


    protected StringBuilder readFileText(String path, String fileName) {
        StringBuilder stringBuilder = new StringBuilder();
        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(path + "\\" + fileName))) {
            String linie;
            while ((linie = bufferedReader.readLine()) != null) {
                stringBuilder.append(linie);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return stringBuilder;
    }
}
*/
