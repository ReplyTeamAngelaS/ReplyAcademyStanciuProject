package eu.reply.academy.lesson26;

import java.util.ArrayList;
import java.util.List;

public abstract class VirtualMachine {

    protected static int IdUnic = 0;
    protected static int NR_VM = 1;
    private static long numarRandom = 57236;
    private static final long contor = 99;
    protected long ID;
    protected List<ProcesorVirtual> listaProcesoareAlocate = new ArrayList<>();
    protected int numarPrioritate;
    protected String numeOS;
    protected int numarVirtualCPU;
    protected List<String> listaAplicatii = new ArrayList<>();
    protected final static String CALE_FISIER = "C:\\Users\\Angela Stanciu\\IdeaProjects\\Lesson1\\src\\main\\java\\eu\\reply\\academy\\lesson26";

    protected void setID() {
        this.ID = VirtualMachine.numarRandom + VirtualMachine.contor;
        VirtualMachine.numarRandom += VirtualMachine.contor;
    }


}
