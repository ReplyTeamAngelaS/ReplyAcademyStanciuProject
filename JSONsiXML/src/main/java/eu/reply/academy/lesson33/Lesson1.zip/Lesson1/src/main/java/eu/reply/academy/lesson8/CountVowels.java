package eu.reply.academy.lesson8;

public class CountVowels {

    public static void main(String[] args) {

        int rezultat = CountVowels.calculeazaVocale("abc   e f");
        System.out.println(rezultat);
    }

    public static int calculeazaVocale(String cuvant) {
        String[] vectorLitere = cuvant.split("");
        if (cuvant == null) {
            return 0;
        }
        if (vectorLitere.equals("")) {
            System.out.println("Rezultatul este: " + 0);
            return 0;
        } else {
            int count = 0;
            for (int i = 0; i < vectorLitere.length; i++) {
                if (vectorLitere[i].equals("a")) {
                    count++;
                } else if (vectorLitere[i].equals("e")) {
                    count++;
                } else if (vectorLitere[i].equals("i")) {
                    count++;
                } else if (vectorLitere[i].equals("o")) {
                    count++;
                } else if (vectorLitere[i].equals("u")) {
                    count++;
                }
            }
            System.out.println("Rezultatul este: " + count);
            return count;
        }
    }

    private static String vocale = "aeiou";

    public static int calculeazaVocaleRecursiv(String cuvant) {
        if (cuvant == null || cuvant.length() == 0) {
            return 0;
        } else {
            if (vocale.contains(String.valueOf(cuvant.substring(0, 1)))) {
                return 1 + calculeazaVocaleRecursiv(cuvant.substring(1));
            } else {
                return calculeazaVocaleRecursiv(cuvant.substring(1));
            }
        }

    }
}
