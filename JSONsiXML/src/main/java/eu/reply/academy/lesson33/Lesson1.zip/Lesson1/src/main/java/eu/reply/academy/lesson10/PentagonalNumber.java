package eu.reply.academy.lesson10;

public class PentagonalNumber {

    public static void main(String[] args) {
        int rezultat = PentagonalNumber.calculeazaPentagonulRecursiv(4);
        System.out.print(rezultat);
    }

    public static int calculeazaPentagonul(int number) {
        if (number == 0) {
            return 0;
        } else if (number == 1) {
            return 1;
        } else {
            int[] vector = new int[number + 1];
            vector[0] = 0;
            vector[1] = 1;
            for (int i = 2; i <= number; i++) {
                vector[i] = vector[i - 1] + 5 * (i - 1);
            }
            return vector[number];
        }
    }

    public static int calculeazaPentagonulRecursiv(int number) {
        if (number == 0) {
            return 0;
        }
        if (number == 1) {
            return 1;
        }
        return calculeazaPentagonulRecursiv(number - 1) + 5 * (number - 1);
    }
}
