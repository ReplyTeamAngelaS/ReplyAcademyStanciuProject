package eu.reply.academy.lesson33.Factory;

import eu.reply.academy.lesson33.Model.MenuItem;

import java.util.List;

public class FactoryMethod {

    public static List<MenuItem> createMenu(String path, String fileName,String extensie){
        return null;
    }
}
