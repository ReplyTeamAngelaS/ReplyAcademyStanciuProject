package eu.reply.academy.lesson23.beans;

public class Adresa {

    public int id;
    public int idOras;
    public int sector;
    public String strada;
    public String nr;
    public String bloc;
    public String scara;
    public int etaj;
    public String apartament;

}
