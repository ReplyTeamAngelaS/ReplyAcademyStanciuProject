package eu.reply.academy.lesson14;

import java.util.Scanner;

public class NumarMaximArray {

    public static void main(String[] args) {
        int[] vector = NumarMaximArray.citesteTreiNumere();
        NumarMaximArray.afiseazaNumerele(vector);
    }

    public static int daNumar() {
        Scanner scan = new Scanner(System.in);
        System.out.print("Scrie un numar natural: ");
        int n = scan.nextInt();
        if (!((n >= 10) && (n <= 99))) {
            System.out.println("Numarul trebuie sa fie in intervalul 10 si 99");
            return daNumar();
        }
        return n;
    }

    public static int[] citesteTreiNumere() {
        int[] vector = new int[3];
        int i = 0;
        while (i < vector.length) {
            vector[i] = NumarMaximArray.daNumar();
            i++;
        }
        return vector;
    }

    public static void afiseazaNumerele(int[] vector) {
        int[] suma = new int[vector.length];
        for (int i = 0; i < vector.length; i++) {
            suma[i] = vector[i] % 10 + vector[i] / 10;
        }
        int maxim = suma[0];
        for (int i = 1; i < suma.length; i++) {
            if (maxim < suma[i]) {
                maxim = suma[i];
            }
        }
        System.out.println("Rezultatul corect este: ");
        for (int i = 0; i < suma.length; i++) {
            if (maxim == suma[i]) {
                System.out.print(vector[i] + " ");
            }
        }
    }
}
