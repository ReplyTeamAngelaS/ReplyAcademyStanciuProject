package eu.reply.academy.lesson8;

import junit.framework.TestCase;
import org.junit.Assert;
import org.junit.Test;

public class SumaCifrelorTest extends TestCase {

    @Test
    public void test01(){Assert.assertEquals(3,SumaCifrelor.calculeazaSumaCifrelor(111));}

    @Test
    public void test02(){Assert.assertEquals(6,SumaCifrelor.calculeazaSumaCifrelor(222));}

    @Test
    public void test03(){Assert.assertEquals(9,SumaCifrelor.calculeazaSumaCifrelor(333));}

    @Test
    public void test04(){Assert.assertEquals(12,SumaCifrelor.calculeazaSumaCifrelor(444));}

    @Test
    public void test05(){Assert.assertEquals(15,SumaCifrelor.calculeazaSumaCifrelor(555));}

    @Test
    public void test06(){Assert.assertEquals(18,SumaCifrelor.calculeazaSumaCifrelor(666));}

    @Test
    public void test07(){Assert.assertEquals(21,SumaCifrelor.calculeazaSumaCifrelor(777));}

    @Test
    public void test08(){Assert.assertEquals(24,SumaCifrelor.calculeazaSumaCifrelor(888));}

    @Test
    public void test09(){Assert.assertEquals(27,SumaCifrelor.calculeazaSumaCifrelor(999));}

    @Test
    public void test10(){Assert.assertEquals(4,SumaCifrelor.calculeazaSumaCifrelor(1111));}

    @Test
    public void test11(){Assert.assertEquals(3,SumaCifrelor.calculeazaSumaCifrelorRecursiv(111));}

    @Test
    public void test12(){Assert.assertEquals(6,SumaCifrelor.calculeazaSumaCifrelorRecursiv(222));}

    @Test
    public void test13(){Assert.assertEquals(9,SumaCifrelor.calculeazaSumaCifrelorRecursiv(333));}

    @Test
    public void test14(){Assert.assertEquals(12,SumaCifrelor.calculeazaSumaCifrelorRecursiv(444));}

    @Test
    public void test15(){Assert.assertEquals(15,SumaCifrelor.calculeazaSumaCifrelorRecursiv(555));}

    @Test
    public void test16(){Assert.assertEquals(18,SumaCifrelor.calculeazaSumaCifrelorRecursiv(666));}

    @Test
    public void test17(){Assert.assertEquals(21,SumaCifrelor.calculeazaSumaCifrelorRecursiv(777));}

    @Test
    public void test18(){Assert.assertEquals(24,SumaCifrelor.calculeazaSumaCifrelorRecursiv(888));}

    @Test
    public void test19(){Assert.assertEquals(27,SumaCifrelor.calculeazaSumaCifrelorRecursiv(999));}

    @Test
    public void test20(){Assert.assertEquals(4,SumaCifrelor.calculeazaSumaCifrelorRecursiv(1111));}

}