package eu.reply.academy.lesson12;

public class Test {

    public static void main(String[] args) {
        Person eu = new Person();
        System.out.println(eu.toString());

    }
}
