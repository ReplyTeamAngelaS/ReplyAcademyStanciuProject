package eu.reply.academy.lesson10;

public class DigitsSumRoot {

    public static void main(String[] args) {

        long rezultat = DigitsSumRoot.calculeazaSumRootRecursiv(999999999999999999L);
        System.out.print(rezultat);
    }

    public static long calculeazaSumRoot(long number) {
        long sum = DigitsSumRoot.calculeazaSumaCifrelor(number);
        /*int sum2 = 0;
        for (int i = 0; i < 10; i++) {

            while (sum / 10 != 0) {
                sum2 += sum % 10;
                sum = sum / 10;
            }
            sum2 += sum;
            sum = sum2;
            sum2 = 0;
        }*/
        while (sum > 9) {
            sum = DigitsSumRoot.calculeazaSumaCifrelor(sum);
        }
        System.out.print("Rezultatul este: " + sum + "\n");
        return sum;
    }

    public static long calculeazaSumRootRecursiv(long number) {
        if (number < 10) {
            return number;
        } else {
            long sum = 0 + number % 10;
            number = number / 10;
            return calculeazaSumRootRecursiv(sum);
        }
    }

    public static int calculeazaSumaCifrelor(long number) {
        int sum = 0;
        while (number / 10 != 0) {
            sum += number % 10;
            number = number / 10;
        }
        sum += number;
        return sum;
    }
}
