package eu.reply.academy.lesson15;

import java.lang.reflect.Array;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.*;

import static java.util.Arrays.*;

public class Cap3 {
    public final int pppppp = 5;
   // public final int CAPACITATE;
    public static int COUNTER = 0;
  //  public static final double PIII;
    public int X = 0;
    private static final int NR;

    static {
        NR=5;
    }


    public Cap3(int nr, double PII) {
     //   this.CAPACITATE = nr;
     //   PIII=PII;
    }

    public Cap3(){}

    public static void main(String[] args) {
        Cap3 sss = new Cap3();
        System.out.println(sss.pppppp);
        int[] vector = new int[]{};
        System.out.println(sss.E(vector));
        Integer i1 = Integer.valueOf(7); //integer foloseste un design pattern numit flyweight
        Integer i2 = Integer.valueOf(7); //de asta la 7 e true si la 1071 e false
        System.out.println(i1 == i2);

        Integer i3 = Integer.valueOf(1071);
        Integer i4 = Integer.valueOf(1071);
        System.out.println(i3 == i4);

        String s1 = "Nume";
        String s2 = "Nume";
        String s3 = new String("Nume");
        System.out.println(s1 == s2); //string pool => true
        System.out.println(s1 == s3); // obiect => o alta referinta => false

        String string = "animals";
        System.out.println(string.toUpperCase());
        System.out.println(string);
        System.out.println(string.contains("als"));

        System.out.println("  abc  ".trim());
        String result = "AniMaL ".trim().toLowerCase().replace('a', 'A');
        System.out.println(result);

        String a = "abc";
        String b = a.toUpperCase();
        b = b.replace("B", "2").replace('C', '3');
        System.out.println("a=" + a);
        System.out.println("b=" + b);

        String alpha = "";
        for (char current = 'a'; current <= 'z'; current++)
            alpha += current;
        System.out.println(alpha);

        StringBuilder al = new StringBuilder();
        for (char current = 'a'; current <= 'z'; current++)
            al.append(current);
        System.out.println(al);

        StringBuilder d = new StringBuilder("abc");
        StringBuilder e = d.append("de");
        e = e.append("f").append("g");
        System.out.println("a=" + d);
        System.out.println("b=" + e);

        StringBuilder sb1 = new StringBuilder();
        StringBuilder sb2 = new StringBuilder("animal");
        StringBuilder sb3 = new StringBuilder(10);
        System.out.println(sb1);
        System.out.println(sb2);
        System.out.println(sb3);
        sb1.append("asfsgegsgesgwegesg");
        sb3.append("afaffsafafavdvsvvsdv");
        System.out.println(sb1);
        System.out.println(sb2);
        System.out.println(sb3);

        StringBuilder str1 = new StringBuilder("animals");

        String x = "Hello World";
        String z = " Hello World";
        String h = "Hello World";
        System.out.println(z);
        System.out.println(h);

        String[] nume1 = new String[]{"a", "b", "c"};
        int[] nume2 = new int[]{1, 2, 3};
        System.out.println(nume1);
        System.out.println(Arrays.toString(nume1));
        System.out.println(nume2);
        System.out.println(Arrays.toString(nume2));

        String[] strings = {"stringValue"};
        Object[] objects = strings;
        String[] againStrings = (String[]) objects;
        System.out.println(Arrays.toString(objects));
        System.out.println(objects[0].getClass());
        // againStrings[0] = new StringBuilder(); // DOES NOT COMPILE
        //objects[0] = new StringBuilder();
        //System.out.println(objects[0].getClass());
        int[] v = new int[]{2, 4, 6};
        String[] n = new String[]{"123", "119", "888", "abc", "Bbc"};
        Arrays.sort(v);
        Arrays.sort(n);
        System.out.println(Arrays.toString(v));
        System.out.println(Arrays.toString(n));

        int[] numbers = new int[]{3, 2, 4, 1, 5};
        System.out.println(Arrays.binarySearch(numbers, 1));
        System.out.println(Arrays.binarySearch(numbers, 2));
        System.out.println(Arrays.binarySearch(numbers, 3));
        System.out.println(Arrays.binarySearch(numbers, 9));
        System.out.println(Arrays.binarySearch(numbers, 4));
        System.out.println(Arrays.binarySearch(numbers, 0));
        Arrays.sort(numbers);
        System.out.println(Arrays.toString(numbers));
        System.out.println(Arrays.binarySearch(numbers, 2));
        System.out.println(Arrays.binarySearch(numbers, 3));
        System.out.println(Arrays.binarySearch(numbers, 4));
        System.out.println(Arrays.binarySearch(numbers, 5));

        int[][] matrice = new int[3][2];
        System.out.println("----------");
        System.out.println(matrice.length);//linii
        System.out.println(matrice[0].length);
        System.out.println("-------------");

        ArrayList list1 = new ArrayList();
        System.out.println(list1.toString());
        ArrayList list2 = new ArrayList();
        System.out.println(list2.toString());
        ArrayList list3 = new ArrayList(list2);
        System.out.println(list3.toString());
        System.out.println(list2.equals(list3));
        System.out.println(list2 == list3);
        ArrayList<String> list4 = new ArrayList<String>();
        System.out.println(list4.toArray());
        ArrayList<String> list5 = new ArrayList<>(5);
        System.out.println(list5.toArray());
        List list6 = new ArrayList(3);
        System.out.println(list6.toArray());
        List<String> list7 = new ArrayList<String>(4);
        System.out.println(list7.toArray());

        ArrayList lista1 = new ArrayList(10);
        lista1.add(Boolean.FALSE);
        System.out.println(lista1.add("hawk"));
        lista1.add(0, "aaa");
        lista1.add(0, "bbb");
        System.out.println(lista1);
        ArrayList lista2 = new ArrayList(lista1);
        System.out.println(lista1.remove("aaa"));
        System.out.println(lista1);
        System.out.println(lista1.remove("bb"));
        System.out.println(lista1);
        lista1.remove(0);
        System.out.println(lista1);
        System.out.println(lista1.remove(0));
        System.out.println(lista1);
        System.out.println("-------------");
        System.out.println(lista2);
        lista2.set(0, "cc");
        System.out.println(lista2);
        System.out.println(lista2.set(0, "dd"));
        System.out.println(lista2);

        ArrayList lista3 = new ArrayList();
        System.out.println(lista3.isEmpty());
        lista3.add("a");
        System.out.println(lista3.isEmpty());

        StringBuilder stringBuilder = new StringBuilder(10);
        System.out.println(stringBuilder.length());

        System.out.println("----------");
        String s = "sss";
        String f = "ssd";
        System.out.println(s.equals(f));

        StringBuilder m = new StringBuilder();
        m.append("ddd");
        StringBuilder p = new StringBuilder();
        p.append("dds");
        System.out.println(m.equals(p));

        ArrayList ss = new ArrayList();
        ss.add("dd");
        ArrayList dd = new ArrayList(ss);
        System.out.println(ss.equals(dd));

        Boolean bol = true;
        System.out.println(bol);

        Byte bb = (byte) 1000;
        System.out.println(bb);
        Byte bbb = new Byte((byte) 1);

        Short fff = (short) 110000;

        float dddd = 10.0f;
        Float ffff = new Float(10.0);

        System.out.println("-------------");

        List<Integer> list = new ArrayList<Integer>();
        list.add(1);
        list.add(2);
        Object[] obiecte = list.toArray();
        System.out.println(Arrays.toString(obiecte));
        Integer[] vector3 = list.toArray(new Integer[0]);
        System.out.println(Arrays.toString(vector));
        Integer[] vec = {2, 4, 6};
        List<Integer> lis = Arrays.asList(2, 4, 3);
        System.out.println(lis);
        List<Integer> lis4 = Arrays.asList(vec);
        System.out.println(lis4);
        //lis4.add(9); lis4 si vec
        System.out.println(Arrays.toString(vec));
        int[] vect = Cap3.E(new int[]{1, 2, 3});
        System.out.println("-----------");
        vec[1] = 5;
        System.out.println(Arrays.toString(vec));
        System.out.println(lis4);
        System.out.println("-------");
        lis4.set(2, 7);
        System.out.println(Arrays.toString(vec));
        System.out.println(lis4);
        System.out.println("--------");
        vec = new Integer[]{2, 5, 7, 9, 8};
        System.out.println(Arrays.toString(vec));
        System.out.println(lis4);
        System.out.println("----------");
        Arrays.sort(vec);
        System.out.println(Arrays.toString(vec));
        System.out.println("-------------");
        List<String> lis8 = new ArrayList<>();
        lis8.add("1bc");
        lis8.add("1aa");
        lis8.add("bbb");
        lis8.add("aaa");
        System.out.println(lis8);
        Collections.sort(lis8);
        System.out.println(lis8);
        System.out.println("----------");
        System.out.println(LocalDate.now());
        System.out.println(LocalTime.now());
        System.out.println(LocalDateTime.now());
        System.out.println("-----------");
        LocalDate lll = LocalDate.of(2020, 11, 21);
        lll = lll.plusDays(2);
        long ddddd = lll.toEpochDay();
        System.out.println(lll);
        System.out.println(ddddd);
        LocalDateTime ddd = LocalDateTime.now();
        ZoneOffset offset = ZoneOffset.MIN;
        long fffff = ddd.toEpochSecond(offset);
        System.out.println(fffff);
        DateTimeFormatter gg = DateTimeFormatter.ofLocalizedDateTime(FormatStyle.SHORT);
        LocalDate date = LocalDate.now();
        LocalTime time = LocalTime.now();
        LocalDateTime datetime = LocalDateTime.now();
        System.out.println(datetime.format(gg));
        System.out.println(Byte.MAX_VALUE);
        System.out.println(Byte.MIN_VALUE);
        Date date2 = new Date();
        System.out.println(date2);
        System.out.println(date2.getDate());
        System.out.println(date2.getHours());

        int[] vector4 = new int[3];
        System.out.println(vector3.length);
        Cap3 eu = new Cap3();
        System.out.println(eu.toString());
        String str = "hello.";
        System.out.println(str.length());
        Cap3.sNume(5, null);
        System.out.println();
        System.out.println(NR);

    }

    public static int[] E(int[] v) {

        Cap3 e = new Cap3();
        e.X = 10;
        return v;
    }

    public void numeS() {
        int j;
        int x;
        if (true) {
            j = 5;
        } else {
            j = 10;
            x = 7;
        }
        System.out.println(j);
        this.COUNTER++;
        this.X++;
      //  int y = Cap3.pppppp;
        Cap3.COUNTER++;
        int[] vector = new int[]{};
        this.E(vector);
    }

    public static void sNume(int nume, String... num) {
        num = new String[]{"1", "2", "3"};
        System.out.println("nume:" + nume);
        System.out.println("num:" + Arrays.toString(num));
        System.out.println("length:" + num.length);
        Cap3.COUNTER++;
      //  int x = Cap3.pppppp;

    }


}
