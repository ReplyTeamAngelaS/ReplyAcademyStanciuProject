package eu.reply.academy.lesson15;

import java.util.ArrayList;
import java.util.List;

public class java {

    public final int PI;
    public final List<String> lista;
    public final String ss;
    public final static int S=10;
    public final StringBuilder b=new StringBuilder("app");
    public final int n;
    public static int x;

    {
        this.n=10;
    }





    public java(int nr){
        this.PI=nr;
        this.ss="sss";
        this.lista=new ArrayList<>();
        b.append("s");

    }

    public java(){
        this.PI=5;
        this.ss="sss";
        this.lista=new ArrayList<>();


    }

    public static void main(String[] args) {
        java s=new java();
        System.out.println(s.ss);
      //  System.out.println(s.ss=null);

    }
}
