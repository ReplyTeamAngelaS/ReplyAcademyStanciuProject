package eu.reply.academy.lesson13;

import java.util.Scanner;

public class NumereNaturale {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Numarul natural dat de la tastatura este: ");
        int n = scan.nextInt();
        System.out.print("Numerele naturale consecutive luate in mod descrescator sunt urmatoarele: ");
        NumereNaturale.AfiseazaPrimeleNNumereNaturale(n);

    }

    public static void AfiseazaPrimeleNNumereNaturale(int n) {
        for (int i = n; i > 0; i--) {
            System.out.print(i + " ");
        }
    }
}
